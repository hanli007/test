package com.doudou.kids.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LicenseCodecTest {
    // 与 tools/license/gen_code.py 的输出对拍：两边算法必须一致
    @Test fun matchesPythonTool() {
        assertEquals("D5NF-D6QH-QYTV-TRZ0", LicenseCodec.activationCode("DEV-ONLY-CHANGE-ME", "ABCDE-12345"))
        assertEquals("WGRZ-9BXX-FNSX-AJW5", LicenseCodec.activationCode("test-secret-123", "ABCDE-12345"))
        assertEquals("WATZH-R6TH9", LicenseCodec.deviceCode("test-android-id"))
    }

    @Test fun verifyIgnoresCaseSeparatorsAndLookalikes() {
        val code = LicenseCodec.activationCode("s", "ABCDE-12345")
        assertTrue(LicenseCodec.verify("s", "abcde12345", code.lowercase().replace("-", " ")))
        assertEquals("0111", LicenseCodec.normalize("oIl1"))
        assertFalse(LicenseCodec.verify("other", "ABCDE-12345", code))
        assertFalse(LicenseCodec.verify("s", "ABCDE-12345", code.dropLast(1)))
    }

    @Test fun formats() {
        assertEquals(11, LicenseCodec.deviceCode("x").length)
        assertEquals(19, LicenseCodec.activationCode("s", "x").length)
    }
}

class PinTest {
    @Test fun hashAndVerify() {
        val salt = PinHasher.newSalt()
        val h = PinHasher.hash("1234", salt)
        assertTrue(PinHasher.verify("1234", salt, h))
        assertFalse(PinHasher.verify("1235", salt, h))
        assertEquals("abc", PinHasher.normalizeAnswer("  A b C "))
    }

    @Test fun lockoutDoublesAfterFiveFailures() {
        var s = LockoutState()
        repeat(4) { s = PinLockout.onFailure(s, 0) }
        assertEquals(1, PinLockout.remainingAttempts(s))
        s = PinLockout.onFailure(s, 1000)
        assertTrue(PinLockout.isLocked(s, 1000 + 59_000))
        assertFalse(PinLockout.isLocked(s, 1000 + 60_000))
        repeat(5) { s = PinLockout.onFailure(s, 100_000) }
        assertEquals(100_000 + 120_000, s.lockedUntil)
        assertEquals(LockoutState(), PinLockout.onSuccess())
    }
}

class TimeRulesTest {
    private val rule = TimeRule(60, 90, 20, 5, 8 * 60, 21 * 60)

    private fun eval(used: Long = 0, session: Long = 0, minute: Int = 600, extra: Int = 0, override: Boolean = false, rest: Boolean = false, weekend: Boolean = false) =
        TimeRules.evaluate(rule, minute, weekend, used, session, extra, override, rest)

    @Test fun normalAndWarning() {
        assertEquals(Block.NONE, eval().block)
        assertFalse(eval(used = 50 * 60).warnSoon)
        assertTrue(eval(used = 56 * 60).warnSoon)
    }

    @Test fun timeUpAndExtension() {
        assertEquals(Block.TIME_UP, eval(used = 60 * 60).block)
        assertEquals(Block.NONE, eval(used = 60 * 60, extra = 15).block)
        assertEquals(Block.NONE, eval(used = 60 * 60, weekend = true).block)
    }

    @Test fun windowAndRest() {
        assertEquals(Block.OUT_OF_WINDOW, eval(minute = 22 * 60).block)
        assertEquals(Block.NONE, eval(minute = 22 * 60, override = true).block)
        assertEquals(Block.REST, eval(session = 20 * 60).block)
        assertEquals(Block.REST, eval(rest = true).block)
    }

    @Test fun windowAcrossMidnight() {
        val night = rule.copy(windowStartMin = 20 * 60, windowEndMin = 2 * 60)
        assertTrue(TimeRules.inWindow(night, 23 * 60))
        assertTrue(TimeRules.inWindow(night, 60))
        assertFalse(TimeRules.inWindow(night, 12 * 60))
        assertTrue(TimeRules.inWindow(rule.copy(windowStartMin = 0, windowEndMin = 0), 3))
    }

    @Test fun tiers() {
        assertEquals(Tier.QM, Tier.forAge(0))
        assertEquals(Tier.TQ, Tier.forAge(6))
        assertEquals(Tier.SN, Tier.forAge(12))
        assertEquals(20, TimeDefaults.forAge(2).dailyWeekdayMin)
    }
}

class FilterEngineTest {
    private val cfg = FilterConfig(setOf("科普"), FilterEngine.DEFAULT_BLACKLIST, childAge = 7)

    @Test fun fiveLayers() {
        assertTrue(FilterEngine.isVisible("科普", "太阳系", null, null, ItemStatus.APPROVED, cfg))
        assertFalse(FilterEngine.isVisible("动作片", "太阳系", null, null, ItemStatus.APPROVED, cfg))
        assertFalse(FilterEngine.isVisible("科普", "恐怖的黑洞", null, null, ItemStatus.APPROVED, cfg))
        assertFalse(FilterEngine.isVisible("科普", "太阳系", 9, null, ItemStatus.APPROVED, cfg))
        assertFalse(FilterEngine.isVisible("科普", "太阳系", null, 6, ItemStatus.APPROVED, cfg))
        assertFalse(FilterEngine.isVisible("科普", "太阳系", null, null, ItemStatus.PENDING, cfg))
        assertFalse(FilterEngine.isVisible("科普", "太阳系", null, null, ItemStatus.BLOCKED, cfg))
    }

    @Test fun helpers() {
        assertTrue(FilterEngine.looksLearning("少儿英语"))
        assertFalse(FilterEngine.looksLearning("电影"))
        assertEquals(ItemStatus.PENDING, FilterEngine.initialStatus(true))
        assertEquals(listOf("A", "b"), FilterEngine.dedupeByTitle(listOf("A", " a", "b")) { it })
    }
}

class SourceParserTest {
    @Test fun json() {
        val s = SourceParser.parse(
            """{"name":"示例","categories":[{"id":"sci","name":"科普","ageMin":6,"ageMax":15}],
              "items":[{"id":"v1","title":"行星","type":"video","url":"https://e.com/a.mp4","categoryId":"sci","duration":360},
                       {"title":"无地址"},
                       {"title":"网页","type":"webpage","url":"https://e.com/p","category":"其他","ageMin":3}]}""",
        )
        assertEquals("示例", s.name)
        assertEquals(2, s.items.size)
        val a = s.items[0]
        assertEquals("科普", a.category)
        assertEquals(6, a.ageMin)
        assertEquals(360, a.durationSec)
        assertEquals("webpage", s.items[1].type)
        assertEquals(3, s.items[1].ageMin)
    }

    @Test fun m3u() {
        val s = SourceParser.parse(
            "#EXTM3U\n#EXTINF:-1 tvg-logo=\"https://e.com/l.png\" group-title=\"儿歌\",小星星\nhttps://e.com/1.m3u8\nhttps://e.com/2.mp4\n",
        )
        assertEquals(2, s.items.size)
        assertEquals("儿歌", s.items[0].category)
        assertEquals("小星星", s.items[0].title)
        assertEquals("未分类", s.items[1].category)
        assertEquals("2.mp4", s.items[1].title)
    }
}

class GuardRulesTest {
    @Test fun keyFilter() {
        // Android 11 及以下锁定时一直过滤
        assertTrue(KeyFilterRules.wanted(locked = true, screenOn = true, sdk = 30, selfInFront = false, gamepadOrMouse = false))
        // Android 12+ 只在豆豆乐园在前台时过滤
        assertFalse(KeyFilterRules.wanted(true, true, 31, selfInFront = false, gamepadOrMouse = false))
        assertTrue(KeyFilterRules.wanted(true, true, 31, selfInFront = true, gamepadOrMouse = false))
        // 接了手柄或鼠标、屏幕关了、没锁定：不过滤
        assertFalse(KeyFilterRules.wanted(true, true, 28, true, gamepadOrMouse = true))
        assertFalse(KeyFilterRules.wanted(true, false, 28, true, false))
        assertFalse(KeyFilterRules.wanted(false, true, 28, true, false))
    }

    @Test fun home() {
        assertTrue(KeyFilterRules.takeHome(locked = true, isDefaultHome = false))
        assertFalse(KeyFilterRules.takeHome(locked = true, isDefaultHome = true))
        assertTrue(KeyFilterRules.isHome(3, 0, false))
        assertTrue(KeyFilterRules.isHome(122, 102, false))
        assertFalse(KeyFilterRules.isHome(122, 102, alphabeticKeyboard = true))
        assertTrue(KeyFilterRules.isHome(0, 172, false))
        assertFalse(KeyFilterRules.isHome(0, 30, false))
        assertFalse(KeyFilterRules.isHome(23, 0, false))
    }

    @Test fun gamepads() {
        assertTrue(InputDeviceRules.isPhysicalGamepad("Xbox Wireless Controller", false, true, 0x045e, 0x0b13, false))
        assertFalse(InputDeviceRules.isPhysicalGamepad("aml_keypad", false, true, 0x0001, 0x0001, false))
        assertFalse(InputDeviceRules.isPhysicalGamepad("virtual-search", false, true, 1, 2, false))
        assertFalse(InputDeviceRules.isPhysicalGamepad("sim-kb", false, true, 1, 2, alphabetic = true))
        assertFalse(InputDeviceRules.isPhysicalGamepad("小米蓝牙语音遥控器", false, true, 0x2717, 0x32b8, false))
        assertFalse(InputDeviceRules.isExternalMouse(isExternal = false, isVirtual = false, supportsMouse = true))
        assertTrue(InputDeviceRules.isExternalMouse(true, false, true))
    }

    @Test fun pullBack() {
        assertTrue(PullBackRules.allowed(screenOn = true, tvPowerMode = null))
        assertFalse(PullBackRules.allowed(screenOn = false, tvPowerMode = null))
        assertFalse(PullBackRules.allowed(screenOn = true, tvPowerMode = "QUICK"))
        assertTrue(PullBackRules.viaPendingIntent(27))
        assertFalse(PullBackRules.viaPendingIntent(28))
    }
}

class UsageClockTest {
    @Test fun countsOnlyActiveTimeAndCapsGaps() {
        val c = UsageClock(maxStepMs = 5_000)
        assertEquals(0, c.tick(1_000, true)) // 第一次只记时间点
        assertEquals(1, c.tick(2_000, true))
        assertEquals(0, c.tick(2_500, true))
        assertEquals(1, c.tick(3_000, true)) // 两个半秒合成一秒
        assertEquals(0, c.tick(10_000, false))
        assertEquals(5, c.tick(60_000, true)) // 休眠后的大间隔封顶 5 秒
        assertEquals(0, c.tick(59_000, true)) // 时间倒退不计
    }
}

class EyeCareTest {
    @Test fun filterSchedule() {
        assertTrue(EyeCare.filterOn(enabled = true, nightAuto = false, minuteOfDay = 600))
        assertFalse(EyeCare.filterOn(false, true, 600))
        assertTrue(EyeCare.filterOn(false, true, 21 * 60))
        assertTrue(EyeCare.filterOn(false, true, 6 * 60))
        assertEquals(0.8f, EyeCare.filterAlpha(200), 0.001f)
    }

    @Test fun distanceHysteresis() {
        val j = DistanceJudge(nearRatio = 0.4f, farRatio = 0.3f, holdMs = 1_000)
        assertFalse(j.update(0.5f, 0))
        assertFalse(j.update(0.5f, 500))
        assertTrue(j.update(0.5f, 1_000))
        assertTrue(j.tooClose)
        // 在两个阈值之间仍算太近
        assertFalse(j.update(0.35f, 2_000))
        assertTrue(j.tooClose)
        assertFalse(j.update(null, 3_000))
        assertTrue(j.update(null, 4_000))
        assertFalse(j.tooClose)
    }
}

class GameCatalogTest {
    @Test fun parseAndFilter() {
        val list = GameCatalog.parseMeta(
            "drag",
            """{"games":[{"id":"drag-train","title":"小火车","ageMin":3,"ageMax":6,"input":["touch"],"entry":"index.html?set=train"},
                         {"id":"memory","title":"翻牌","ageMin":3,"ageMax":12,"input":["touch","dpad"]},
                         {"title":"没有 id"}]}""",
        )
        assertEquals(2, list.size)
        assertEquals("https://appassets.androidplatform.net/assets/games/drag/index.html?set=train", list[0].url)
        assertEquals(listOf("drag-train", "memory"), GameCatalog.visible(list, 4, isTv = false).map { it.id })
        // 电视上隐藏只支持触屏的游戏
        assertEquals(listOf("memory"), GameCatalog.visible(list, 4, isTv = true).map { it.id })
        assertEquals(emptyList<String>(), GameCatalog.visible(list, 13, isTv = false).map { it.id })
    }

    /** 检查打包的全部游戏 meta.json 都能解析（单元测试的工作目录是 app/） */
    @Test fun bundledGames() {
        val root = java.io.File("src/main/assets/games")
        if (!root.isDirectory) return
        val all = root.listFiles().orEmpty().filter { it.isDirectory && !it.name.startsWith("_") }.flatMap { dir ->
            val meta = java.io.File(dir, "meta.json")
            assertTrue("缺少 ${meta.path}", meta.exists())
            GameCatalog.parseMeta(dir.name, meta.readText())
        }
        assertTrue("游戏入口太少：${all.size}", all.size >= 30)
        assertEquals("游戏 id 重复", all.size, all.map { it.id }.toSet().size)
        for (g in all) {
            assertTrue("${g.id} 没有声明输入方式", g.touch || g.dpad)
            assertTrue("${g.id} 入口文件不存在", java.io.File(root, "${g.dir}/${g.entry.substringBefore('?')}").exists())
        }
    }
}

class UrlRulesTest {
    @Test fun domains() {
        val d = setOf("phet.colorado.edu", "smartedu.cn")
        assertTrue(UrlRules.allowed("https://phet.colorado.edu/sims/x.html", d))
        assertTrue(UrlRules.allowed("https://basic.smartedu.cn/", d))
        assertFalse(UrlRules.allowed("https://evil-smartedu.cn/", d))
        assertFalse(UrlRules.allowed("https://smartedu.cn.evil.com/", d))
        assertFalse(UrlRules.allowed("intent://smartedu.cn", d))
        assertFalse(UrlRules.allowed("https://user@evil.com/", setOf("evil.com.cn")))
        assertEquals("example.com", UrlRules.domainFromInput("www.example.com/path"))
        assertNull(UrlRules.domainFromInput("  "))
    }
}
