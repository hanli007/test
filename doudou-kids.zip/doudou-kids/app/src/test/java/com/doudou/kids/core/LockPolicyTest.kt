package com.doudou.kids.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LockPolicyTest {
    private val policy = LockPolicy(
        self = "com.doudou.kids",
        allowedApps = setOf("com.example.math"),
        imePackages = setOf("com.sohu.inputmethod.sogou"),
    )

    @Test fun unlockedAllowsEverything() {
        assertEquals(LockAction.ALLOW, policy.onWindow(false, "com.android.settings", null))
    }

    @Test fun lockedAllowsSelfWhitelistAndIme() {
        assertEquals(LockAction.ALLOW, policy.onWindow(true, "com.doudou.kids", "com.doudou.kids.MainActivity"))
        assertEquals(LockAction.ALLOW, policy.onWindow(true, "com.example.math", null))
        assertEquals(LockAction.ALLOW, policy.onWindow(true, "com.sohu.inputmethod.sogou", null))
    }

    @Test fun lockedPullsBackOtherApps() {
        assertEquals(LockAction.PULL_BACK, policy.onWindow(true, "com.android.settings", null))
        assertEquals(LockAction.PULL_BACK, policy.onWindow(true, "com.android.tv.settings", null))
        assertEquals(LockAction.PULL_BACK, policy.onWindow(true, "com.google.android.tvlauncher", null))
    }

    @Test fun systemUiIsCollapsedNotPulled() {
        assertEquals(LockAction.COLLAPSE, policy.onWindow(true, "com.android.systemui", "android.widget.FrameLayout"))
    }

    @Test fun androidPackageOnlyPullsResolver() {
        assertEquals(LockAction.PULL_BACK, policy.onWindow(true, "android", "com.android.internal.app.ResolverActivity"))
        assertEquals(LockAction.PULL_BACK, policy.onWindow(true, "android", "com.android.internal.app.ChooserActivity"))
        assertEquals(LockAction.ALLOW, policy.onWindow(true, "android", "android.app.AlertDialog"))
    }

    @Test fun permissionDialogAllowed() {
        assertEquals(LockAction.ALLOW, policy.onWindow(true, "com.google.android.permissioncontroller", null))
    }

    @Test fun missingPackageIgnored() {
        assertEquals(LockAction.ALLOW, policy.onWindow(true, null, null))
        assertEquals(LockAction.ALLOW, policy.onWindow(true, "", null))
    }
}

class LockKeysTest {
    @Test fun blocksSystemKeysOnlyWhenLocked() {
        assertTrue(LockKeys.shouldBlock(true, LockKeys.KEYCODE_SETTINGS))
        assertTrue(LockKeys.shouldBlock(true, LockKeys.KEYCODE_TV_INPUT))
        assertTrue(LockKeys.shouldBlock(true, 243)) // HDMI 1
        assertTrue(LockKeys.shouldBlock(true, 251)) // VGA 1
        assertFalse(LockKeys.shouldBlock(false, LockKeys.KEYCODE_SETTINGS))
    }

    @Test fun keepsNavigationKeys() {
        // 方向键、确认、返回、Home、音量必须放行
        for (code in listOf(19, 20, 21, 22, 23, 66, 4, 3, 24, 25)) {
            assertFalse("keyCode $code", LockKeys.shouldBlock(true, code))
        }
        assertFalse(LockKeys.shouldBlock(true, 252)) // 音频描述键，不是信源键
    }
}

class HomePickerTest {
    private val self = "com.doudou.kids"
    private val fallback = HomeCandidate("com.android.settings", "com.android.settings.FallbackHome", -1000, true)
    private val tvLauncher = HomeCandidate("com.google.android.tvlauncher", "com.google.android.tvlauncher.MainActivity", 2, true)
    private val vendor = HomeCandidate("com.mitv.tvhome", "com.mitv.tvhome.HomeActivity", 1, true)
    private val thirdParty = HomeCandidate("com.example.launcher", "com.example.launcher.Home", 5, false)
    private val us = HomeCandidate(self, "com.doudou.kids.lock.HomeActivity", 0, false)

    @Test fun skipsSelfAndFallback() {
        assertNull(HomePicker.pick(listOf(us, fallback), self, null))
    }

    @Test fun prefersSystemThenPriority() {
        assertEquals(tvLauncher, HomePicker.pick(listOf(us, fallback, thirdParty, vendor, tvLauncher), self, null))
    }

    @Test fun rememberedWins() {
        val r = "${vendor.pkg}/${vendor.cls}"
        assertEquals(vendor, HomePicker.pick(listOf(us, tvLauncher, vendor), self, r))
    }

    @Test fun rememberedButUninstalledFallsBack() {
        assertEquals(tvLauncher, HomePicker.pick(listOf(us, tvLauncher), self, "gone.pkg/gone.Home"))
    }
}
