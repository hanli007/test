package com.doudou.kids.ui.lock

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.graphics.drawable.toBitmap
import com.doudou.kids.App
import com.doudou.kids.core.HomeCandidate
import com.doudou.kids.lock.LockManager
import com.doudou.kids.parent.ParentPin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/* ---------- 数字键盘（遥控器可用） ---------- */

@Composable
fun PinPad(entered: Int, onDigit: (Char) -> Unit, onClear: () -> Unit, onOk: () -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(6) { i ->
                Box(
                    Modifier.size(14.dp).background(
                        if (i < entered) MaterialTheme.colorScheme.primary else Color(0x22000000),
                        CircleShape,
                    ),
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        val rows = listOf("123", "456", "789", "C0✓")
        for (row in rows) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 5.dp)) {
                for (ch in row) {
                    val m = Modifier.size(width = 72.dp, height = 56.dp).let { if (ch == '1') it.focusRequester(first) else it }
                    Button(
                        onClick = {
                            when (ch) {
                                'C' -> onClear()
                                '✓' -> onOk()
                                else -> onDigit(ch)
                            }
                        },
                        modifier = m,
                        contentPadding = PaddingValues(0.dp),
                    ) { Text(if (ch == 'C') "清除" else ch.toString(), fontSize = 20.sp) }
                }
            }
        }
    }
}

@Composable
fun PinSetupScreen(onDone: (String) -> Unit) {
    var first by remember { mutableStateOf<String?>(null) }
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(if (first == null) "设置家长密码（4–6 位数字）" else "再输入一次", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(msg, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(8.dp))
        PinPad(
            entered = input.length,
            onDigit = { if (input.length < 6) input += it },
            onClear = { input = "" },
            onOk = {
                val f = first
                when {
                    !ParentPin.isValid(input) -> msg = "请输入 4–6 位数字"
                    f == null -> { first = input; input = ""; msg = "" }
                    f == input -> onDone(input)
                    else -> { first = null; input = ""; msg = "两次输入不一致，请重新设置" }
                }
            },
        )
    }
}

@Composable
fun PinPadDialog(title: String, pin: ParentPin, onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 6.dp))
                PinPad(
                    entered = input.length,
                    onDigit = { if (input.length < 6) input += it },
                    onClear = { input = "" },
                    onOk = {
                        when (val r = pin.check(input)) {
                            ParentPin.Result.Ok -> onSuccess()
                            is ParentPin.Result.Wrong -> msg = "密码不对，还能试 ${r.attemptsLeft} 次"
                            is ParentPin.Result.LockedOut ->
                                msg = "输错太多次，请在 ${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(r.untilMillis))} 后再试"
                        }
                        input = ""
                    },
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onDismiss) { Text("取消") }
            }
        }
    }
}

/* ---------- 家长：锁定设置 ---------- */

private data class Perm(val title: String, val ok: Boolean, val hint: String, val fix: () -> Unit)

@Composable
fun ParentConsole(activity: Activity, isTv: Boolean, resumeTick: Int) {
    val ctx = LocalContext.current
    val prefs = App.instance.prefs
    var allowed by remember { mutableStateOf(prefs.allowedApps) }
    var prevHome by remember { mutableStateOf(prefs.previousHome) }
    val guardOn = remember(resumeTick) { LockManager.isGuardEnabled(ctx) }
    val perms = remember(resumeTick) {
        listOf(
            Perm("设为默认桌面", LockManager.isDefaultHome(ctx), "按 Home 键回到豆豆乐园；未锁定时自动转到原来的桌面") {
                if (prefs.previousHome == null) LockManager.previousHome(ctx)?.let(LockManager::rememberPreviousHome)
                LockManager.openHomeSettings(activity)
            },
            Perm("悬浮窗", LockManager.canDrawOverlays(ctx), "允许从后台把豆豆乐园拉回前台") { LockManager.openOverlaySettings(activity) },
            Perm("防卸载（设备管理器）", LockManager.isAdminActive(ctx), "孩子不能直接卸载") { LockManager.requestAdmin(activity) },
            Perm("电池优化白名单（建议）", LockManager.ignoresBatteryOptimizations(ctx), "国产系统还要在手机管家里允许自启动，否则后台会被杀") {
                LockManager.openBatterySettings(activity)
            },
        )
    }
    val missing = remember(resumeTick) { LockManager.missingRequired(ctx) }
    val homes = remember(resumeTick) { LockManager.homeCandidates(ctx).filter { it.pkg != ctx.packageName && it.priority > -1000 } }
    val apps by produceState(emptyList<LockManager.LaunchableApp>()) {
        value = withContext(Dispatchers.IO) { LockManager.launchableApps(ctx) }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = if (isTv) 48.dp else 16.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("设备锁定（试验）", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { SectionTitle("1. 权限") }
        items(perms) { p -> PermRow(p) }
        item {
            PermRow(
                Perm(
                    "无障碍服务", guardOn,
                    "检测孩子打开了别的 app 并拉回。点「锁定」时会自动引导开启；解锁后自动关闭，不影响银行、支付 app",
                ) { LockManager.openAccessibilitySettings(activity) },
            )
        }
        if (!guardOn && LockManager.needsRestrictedSettingsHint) {
            item {
                Hint("Android 13 及以上：如果无障碍里豆豆乐园是灰色的，先到「应用信息 → 右上角菜单 → 允许受限制的设置」。") {
                    LockManager.openAppDetails(activity)
                }
            }
        }
        item {
            val adbOk = LockManager.canWriteSecureSettings(ctx)
            Text(
                if (adbOk) "已通过 adb 授权：锁定、解锁时自动开关无障碍服务，不用进设置。"
                else "进阶（可选）：电脑执行 adb shell pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS，" +
                    "之后锁定、解锁一键完成。电视不能改默认桌面时，可试 adb shell cmd package set-home-activity ${ctx.packageName}/.lock.HomeActivity",
                fontSize = 13.sp,
                color = Color.Gray,
            )
        }

        item { SectionTitle("2. 原来的桌面（解锁时按 Home 键去这里）") }
        items(homes) { h ->
            val key = "${h.pkg}/${h.cls}"
            val selected = prevHome == key || (prevHome == null && h == LockManager.previousHome(ctx))
            SelectRow(text = homeLabel(ctx, h), selected = selected) {
                LockManager.rememberPreviousHome(h)
                prevHome = key
            }
        }

        item { SectionTitle("3. 白名单 app（锁定后孩子可以打开）") }
        items(apps, key = { it.pkg }) { a ->
            CheckRow(text = a.label, checked = a.pkg in allowed) {
                allowed = if (a.pkg in allowed) allowed - a.pkg else allowed + a.pkg
                prefs.allowedApps = allowed
            }
        }
        item { Text("提醒：关闭这些 app 的免密支付，打开它们自带的家长锁。", fontSize = 13.sp, color = Color.Gray) }

        item {
            Spacer(Modifier.height(12.dp))
            if (missing.isNotEmpty()) Text("还需要开启：${missing.joinToString("、")}", color = MaterialTheme.colorScheme.error)
            Button(
                enabled = missing.isEmpty(),
                onClick = {
                    if (LockManager.lock(activity) == LockManager.LockResult.WAITING_FOR_SERVICE) {
                        Toast.makeText(ctx, "请开启「豆豆乐园」无障碍服务，开启后自动锁定", Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) { Text("锁定", fontSize = 20.sp) }
        }
        item {
            OutlinedButton(onClick = { LockManager.retire(activity) }, modifier = Modifier.fillMaxWidth()) {
                Text("不再使用：取消防卸载并改回原来的桌面")
            }
        }
    }
}

private fun homeLabel(ctx: android.content.Context, h: HomeCandidate): String =
    runCatching { ctx.packageManager.getApplicationInfo(h.pkg, 0).loadLabel(ctx.packageManager).toString() }
        .getOrDefault(h.pkg) + "（${h.pkg}）"

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
    HorizontalDivider()
}

@Composable
private fun PermRow(p: Perm) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text((if (p.ok) "✅ " else "⬜ ") + p.title, fontSize = 16.sp)
            Text(p.hint, fontSize = 13.sp, color = Color.Gray)
        }
        if (!p.ok) OutlinedButton(onClick = p.fix) { Text("去开启") }
    }
}

@Composable
private fun Hint(text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = onClick) { Text("应用信息") }
    }
}

@Composable
private fun SelectRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = null)
        Text(text)
    }
}

@Composable
private fun CheckRow(text: String, checked: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = null)
        Text(text)
    }
}

/* ---------- 孩子：锁定后的首页（内容页待接入） ---------- */

private data class AppTile(val pkg: String, val label: String, val icon: ImageBitmap?)

@Composable
fun KidHome(isTv: Boolean, onHiddenUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val tiles by produceState(emptyList<AppTile>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            App.instance.prefs.allowedApps.mapNotNull { pkg ->
                val ai = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull() ?: return@mapNotNull null
                val icon = runCatching { pm.getApplicationIcon(ai).toBitmap(128, 128).asImageBitmap() }.getOrNull()
                AppTile(pkg, ai.loadLabel(pm).toString(), icon)
            }.sortedBy { it.label }
        }
    }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize().padding(if (isTv) 48.dp else 20.dp)) {
            Text("豆豆乐园", fontSize = if (isTv) 40.sp else 30.sp, fontWeight = FontWeight.Bold)
            Text("视频、游戏、绘本马上就来～", color = Color.Gray)
            Spacer(Modifier.height(24.dp))
            if (tiles.isEmpty()) {
                Text("家长还没有添加可以打开的 app")
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (isTv) 180.dp else 110.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    items(tiles, key = { it.pkg }) { t ->
                        AppTileCard(t, isTv) { LockManager.launchApp(ctx, t.pkg, preferTv = isTv) }
                    }
                }
            }
        }
        // 手机：长按右上角 3 秒弹出家长密码。不显示任何提示，免得孩子发现
        Box(
            Modifier.align(Alignment.TopEnd).size(72.dp).pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    val up = withTimeoutOrNull(HIDDEN_HOLD_MS) { waitForUpOrCancellation() }
                    if (up == null) onHiddenUnlock()
                }
            },
        )
    }
}

private const val HIDDEN_HOLD_MS = 3_000L

@Composable
private fun AppTileCard(t: AppTile, isTv: Boolean, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Card(
        onClick = onClick,
        interactionSource = source,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = if (focused) BorderStroke(4.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val size = if (isTv) 96.dp else 64.dp
            if (t.icon != null) Image(t.icon, contentDescription = null, modifier = Modifier.size(size))
            else Box(Modifier.size(size).background(Color(0x22000000), RoundedCornerShape(12.dp)))
            Spacer(Modifier.height(8.dp))
            Text(t.label, fontSize = if (isTv) 20.sp else 15.sp, maxLines = 1)
        }
    }
}
