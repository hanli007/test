package com.doudou.kids.core

/** 一个孩子档案的时间规则，单位均为分钟；可用时段用"当天第几分钟"表示。 */
data class TimeRule(
    val dailyWeekdayMin: Int,
    val dailyWeekendMin: Int,
    val sessionMin: Int,
    val restMin: Int,
    val windowStartMin: Int,
    val windowEndMin: Int,
)

enum class Block {
    NONE,
    /** 不在可用时段内 */
    OUT_OF_WINDOW,
    /** 今天的时长用完 */
    TIME_UP,
    /** 连续使用到时，强制休息 */
    REST,
}

data class TimeStatus(
    val block: Block,
    /** 今天还剩多少秒（已包含家长临时延长的时间） */
    val remainingSec: Long,
    /** 剩余不足 5 分钟，需要提醒 */
    val warnSoon: Boolean,
)

object TimeRules {
    const val WARN_BEFORE_SEC = 5 * 60L

    fun dailyLimitSec(rule: TimeRule, weekend: Boolean, extraMin: Int): Long =
        ((if (weekend) rule.dailyWeekendMin else rule.dailyWeekdayMin) + extraMin) * 60L

    /** 起止相同表示不限时段；起点晚于终点表示跨过午夜。 */
    fun inWindow(rule: TimeRule, minuteOfDay: Int): Boolean {
        val s = rule.windowStartMin
        val e = rule.windowEndMin
        return when {
            s == e -> true
            s < e -> minuteOfDay in s until e
            else -> minuteOfDay >= s || minuteOfDay < e
        }
    }

    /**
     * @param usedTodaySec 今天已用秒数
     * @param sessionSec 本次连续使用秒数（休息后清零）
     * @param extraMin 家长今天临时延长的分钟数
     * @param windowOverride 家长今天允许在时段外使用
     * @param restActive 正在强制休息
     */
    fun evaluate(
        rule: TimeRule,
        minuteOfDay: Int,
        weekend: Boolean,
        usedTodaySec: Long,
        sessionSec: Long,
        extraMin: Int,
        windowOverride: Boolean,
        restActive: Boolean,
    ): TimeStatus {
        val remaining = (dailyLimitSec(rule, weekend, extraMin) - usedTodaySec).coerceAtLeast(0)
        val block = when {
            restActive -> Block.REST
            !windowOverride && !inWindow(rule, minuteOfDay) -> Block.OUT_OF_WINDOW
            remaining <= 0 -> Block.TIME_UP
            rule.sessionMin > 0 && sessionSec >= rule.sessionMin * 60L -> Block.REST
            else -> Block.NONE
        }
        return TimeStatus(block, remaining, block == Block.NONE && remaining <= WARN_BEFORE_SEC)
    }
}
