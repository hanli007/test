package com.doudou.kids.parent

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import com.doudou.kids.BuildConfig
import com.doudou.kids.core.LicenseCodec
import com.doudou.kids.data.Prefs

/** 离线激活（方案 3.10）。调试包跳过激活。 */
class Activation(private val context: Context, private val prefs: Prefs) {

    /** 设备码，格式 XXXXX-XXXXX，家长发给作者换激活码 */
    val deviceCode: String by lazy {
        @SuppressLint("HardwareIds")
        val raw = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        LicenseCodec.deviceCode(raw)
    }

    val required: Boolean get() = BuildConfig.REQUIRE_ACTIVATION

    val isActivated: Boolean
        get() = !required || prefs.activationCode?.let { LicenseCodec.verify(BuildConfig.LICENSE_SECRET, deviceCode, it) } == true

    fun activate(code: String): Boolean {
        if (!LicenseCodec.verify(BuildConfig.LICENSE_SECRET, deviceCode, code)) return false
        prefs.activationCode = LicenseCodec.group(LicenseCodec.normalize(code), 4)
        return true
    }
}
