package com.doudou.kids.core

/** 前台窗口变化后，守护服务要做的事。 */
enum class LockAction {
    /** 放行 */
    ALLOW,
    /** 收起通知栏、最近任务等系统面板（不发返回键，免得把孩子正在用的页面也退掉） */
    COLLAPSE,
    /** 拉回豆豆乐园 */
    PULL_BACK,
}

/**
 * 锁定时的放行规则（方案第 3.1.2 节）。不依赖 Android，方便单元测试。
 *
 * @param self 豆豆乐园自己的包名
 * @param allowedApps 家长勾选的白名单 app
 * @param imePackages 已启用的输入法：输入法窗口必须放行，否则白名单 app 里没法打字
 */
class LockPolicy(
    private val self: String,
    private val allowedApps: Set<String>,
    val imePackages: Set<String>,
) {
    fun onWindow(locked: Boolean, pkg: String?, cls: String?): LockAction {
        if (!locked || pkg.isNullOrEmpty()) return LockAction.ALLOW
        if (pkg == self || pkg in allowedApps || pkg in imePackages) return LockAction.ALLOW
        if (pkg in SYSTEM_UI) return LockAction.COLLAPSE
        // 「android」包里大多是关机菜单、应用无响应之类的系统对话框，拦了反而卡住；
        // 但选择桌面、选择打开方式的弹窗能跳去别的 app，要拉回
        if (pkg == "android") return if (cls != null && RESOLVER.any { cls.startsWith(it) }) LockAction.PULL_BACK else LockAction.ALLOW
        // 豆豆乐园自己申请相机权限时会弹出系统授权框
        if (pkg in PERMISSION_UI) return LockAction.ALLOW
        return LockAction.PULL_BACK
    }

    companion object {
        val SYSTEM_UI = setOf("com.android.systemui")
        val PERMISSION_UI = setOf(
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
        )
        private val RESOLVER = listOf(
            "com.android.internal.app.ResolverActivity",
            "com.android.internal.app.ChooserActivity",
        )
    }
}

/** 锁定时要吞掉的遥控器和手机按键。其余按键必须放行，否则遥控器会失灵。 */
object LockKeys {
    // 直接写数值，避免依赖 android.view.KeyEvent（单元测试里取不到常量）
    const val KEYCODE_SEARCH = 84
    const val KEYCODE_SETTINGS = 176
    const val KEYCODE_TV_INPUT = 178
    const val KEYCODE_TV = 170
    const val KEYCODE_GUIDE = 172
    const val KEYCODE_APP_SWITCH = 187
    const val KEYCODE_ASSIST = 219
    const val KEYCODE_VOICE_ASSIST = 231
    /** TV_INPUT_HDMI_1 … TV_INPUT_VGA_1 */
    val KEYCODE_TV_INPUT_RANGE = 243..251
    const val KEYCODE_ALL_APPS = 284
    const val KEYCODE_NOTIFICATION = 83

    fun shouldBlock(locked: Boolean, keyCode: Int): Boolean {
        if (!locked) return false
        return when (keyCode) {
            KEYCODE_SEARCH, KEYCODE_SETTINGS, KEYCODE_TV_INPUT, KEYCODE_TV, KEYCODE_GUIDE,
            KEYCODE_APP_SWITCH, KEYCODE_ASSIST, KEYCODE_VOICE_ASSIST, KEYCODE_ALL_APPS, KEYCODE_NOTIFICATION -> true
            in KEYCODE_TV_INPUT_RANGE -> true
            else -> false
        }
    }
}

/** 一个可以当桌面的 Activity（来自 HOME 查询结果）。 */
data class HomeCandidate(val pkg: String, val cls: String, val priority: Int, val system: Boolean)

object HomePicker {
    /**
     * 解锁后按 Home 键要转去的「原来的桌面」：排除自己和系统的兜底桌面（FallbackHome 优先级是 -1000），
     * 优先家长记下的那个，否则取系统 app 里优先级最高的。
     */
    fun pick(candidates: List<HomeCandidate>, self: String, remembered: String?): HomeCandidate? {
        val usable = candidates.filter { it.pkg != self && it.priority > -1000 && !it.cls.endsWith("FallbackHome") }
        remembered?.let { r -> usable.firstOrNull { "${it.pkg}/${it.cls}" == r }?.let { return it } }
        return usable.sortedWith(compareByDescending<HomeCandidate> { it.system }.thenByDescending { it.priority }).firstOrNull()
    }
}
