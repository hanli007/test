package com.doudou.kids.eyecare

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.doudou.kids.core.DistanceJudge
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors

/**
 * 距离提醒（方案 3.8）：前置摄像头 + ML Kit 离线人脸检测，离屏幕太近时暂停内容并提示坐远。
 * 所有处理在本机完成，不保存、不上传任何图像。只在豆豆乐园处于前台时运行（跟随传入的 LifecycleOwner）。
 */
class DistanceMonitor(private val context: Context) {
    private val _tooClose = MutableStateFlow(false)
    val tooClose: StateFlow<Boolean> = _tooClose.asStateFlow()

    private val judge = DistanceJudge()
    private val executor = Executors.newSingleThreadExecutor()
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setMinFaceSize(0.1f)
            .build(),
    )
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    private var lastFrameAt = 0L

    fun hasCamera(): Boolean = context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    // ImageProxy.image 需要声明使用 CameraX 的实验接口
    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    fun start(owner: LifecycleOwner) {
        if (analysis != null || !hasCamera() || !hasPermission()) return
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val p = runCatching { future.get() }.getOrNull() ?: return@addListener
            provider = p
            val a = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            a.setAnalyzer(executor) { proxy ->
                val now = SystemClock.uptimeMillis()
                val media = proxy.image
                // 每秒分析两帧就够，省电
                if (media == null || now - lastFrameAt < FRAME_GAP_MS) {
                    proxy.close()
                    return@setAnalyzer
                }
                lastFrameAt = now
                val rotation = proxy.imageInfo.rotationDegrees
                val width = if (rotation == 90 || rotation == 270) proxy.height else proxy.width
                detector.process(InputImage.fromMediaImage(media, rotation))
                    .addOnSuccessListener { faces ->
                        val ratio = faces.maxOfOrNull { it.boundingBox.width() }?.let { it.toFloat() / width }
                        if (judge.update(ratio, SystemClock.uptimeMillis())) _tooClose.value = judge.tooClose
                    }
                    .addOnCompleteListener { proxy.close() }
            }
            runCatching {
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, a)
                analysis = a
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stop() {
        analysis?.clearAnalyzer()
        runCatching { provider?.unbindAll() }
        analysis = null
        _tooClose.value = false
    }

    private companion object {
        const val FRAME_GAP_MS = 500L
    }
}
