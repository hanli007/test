package com.doudou.kids.data

import android.content.Context
import android.content.SharedPreferences
import com.doudou.kids.core.FilterEngine
import com.doudou.kids.core.LockoutState
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 设置项与锁定状态。列表类数据放在 Room（见 Db.kt）。 */
class Prefs(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("doudou", Context.MODE_PRIVATE)

    private fun str(k: String) = sp.getString(k, null)
    private fun put(k: String, v: String?) = sp.edit().putString(k, v).apply()
    private fun putB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun putI(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun putL(k: String, v: Long) = sp.edit().putLong(k, v).apply()

    /* ---------- 家长密码 ---------- */
    var pinHash: String? get() = str("pin_hash"); set(v) = put("pin_hash", v)
    var pinSalt: String? get() = str("pin_salt"); set(v) = put("pin_salt", v)
    var securityQuestion: String? get() = str("sec_q"); set(v) = put("sec_q", v)
    var securityAnswerHash: String? get() = str("sec_a_hash"); set(v) = put("sec_a_hash", v)
    var securityAnswerSalt: String? get() = str("sec_a_salt"); set(v) = put("sec_a_salt", v)

    var lockout: LockoutState
        get() = LockoutState(sp.getInt("lo_fails", 0), sp.getInt("lo_count", 0), sp.getLong("lo_until", 0))
        set(v) = sp.edit().putInt("lo_fails", v.fails).putInt("lo_count", v.lockouts).putLong("lo_until", v.lockedUntil).apply()

    /* ---------- 档案 ---------- */
    /** 当前使用的孩子档案 */
    var currentProfileId: Long get() = sp.getLong("current_profile", 0); set(v) = putL("current_profile", v)
    var setupDone: Boolean get() = sp.getBoolean("setup_done", false); set(v) = putB("setup_done", v)

    /* ---------- 设备锁定（方案第 3.1 节） ---------- */
    /** 同步写入：刚锁定就断电重启，也要保持锁定 */
    var locked: Boolean
        get() = sp.getBoolean("locked", false)
        set(v) { sp.edit().putBoolean("locked", v).commit() }
    /** 家长点了锁定，但无障碍服务还没开；服务连上后自动完成锁定 */
    var lockPending: Boolean get() = sp.getBoolean("lock_pending", false); set(v) = putB("lock_pending", v)
    /** 原来的系统桌面，格式 包名/类名；解锁时按 Home 键转去这里 */
    var previousHome: String? get() = str("prev_home"); set(v) = put("prev_home", v)
    /** 白名单 app 包名 */
    var allowedApps: Set<String>
        get() = sp.getStringSet("allowed_apps", emptySet())!!.toSet()
        set(v) = sp.edit().putStringSet("allowed_apps", v).apply()

    /* ---------- 护眼 ---------- */
    var restEnabled: Boolean get() = sp.getBoolean("eye_rest", true); set(v) = putB("eye_rest", v)
    var filterEnabled: Boolean get() = sp.getBoolean("eye_filter", false); set(v) = putB("eye_filter", v)
    /** 滤镜强度 0–80 */
    var filterStrength: Int get() = sp.getInt("eye_filter_strength", 30); set(v) = putI("eye_filter_strength", v)
    var filterNightAuto: Boolean get() = sp.getBoolean("eye_filter_night", true); set(v) = putB("eye_filter_night", v)
    var distanceEnabled: Boolean get() = sp.getBoolean("eye_distance", false); set(v) = putB("eye_distance", v)

    /* ---------- 语音 ---------- */
    var englishVoice: Boolean get() = sp.getBoolean("voice_en", true); set(v) = putB("voice_en", v)
    var soundEnabled: Boolean get() = sp.getBoolean("sound", true); set(v) = putB("sound", v)

    /* ---------- 激活 ---------- */
    var activationCode: String? get() = str("activation"); set(v) = put("activation", v)

    /* ---------- 视频源过滤 ---------- */
    var keywordBlacklist: List<String>
        get() = str("blacklist")?.split('\n')?.filter { it.isNotBlank() } ?: FilterEngine.DEFAULT_BLACKLIST
        set(v) = put("blacklist", v.joinToString("\n"))

    /* ---------- 计时（按天） ---------- */
    fun extraMinutes(day: String): Int = if (str("extra_day") == day) sp.getInt("extra_min", 0) else 0
    fun addExtraMinutes(day: String, min: Int) {
        val cur = extraMinutes(day)
        sp.edit().putString("extra_day", day).putInt("extra_min", cur + min).apply()
    }
    fun windowOverride(day: String): Boolean = str("window_override_day") == day
    fun setWindowOverride(day: String) = put("window_override_day", day)

    /** 连续使用秒数（休息后清零） */
    var sessionSec: Long get() = sp.getLong("session_sec", 0); set(v) = putL("session_sec", v)
    /** 休息结束时间（System.currentTimeMillis），0 表示不在休息 */
    var restUntil: Long get() = sp.getLong("rest_until", 0); set(v) = putL("rest_until", v)

    /** 当天的小统计（时间用完页展示）：videos / games / books */
    fun bumpStat(day: String, key: String) {
        val o = statsJson(day)
        o.put(key, o.optInt(key) + 1)
        sp.edit().putString("stats_day", day).putString("stats", o.toString()).apply()
    }
    fun stat(day: String, key: String): Int = statsJson(day).optInt(key)
    private fun statsJson(day: String): JSONObject =
        if (str("stats_day") == day) runCatching { JSONObject(str("stats") ?: "{}") }.getOrDefault(JSONObject()) else JSONObject()

    companion object {
        fun dayKey(millis: Long = System.currentTimeMillis()): String =
            SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(millis))
    }
}
