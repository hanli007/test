package com.doudou.kids.lock

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import com.doudou.kids.App

/**
 * 守护服务被固件杀掉后把它找回来（方案 3.1.6）。
 *
 * 小米等电视待机时会强制停止所有第三方 app，Android 随之把被停 app 的无障碍服务从启用列表里永久删掉。
 * 通知监听服务的授权不会被删，进程死后系统还会重新绑定它——这是被杀之后唯一可靠的「复活」时机。
 * 被绑定后检查守护服务：不在列表里就写回去，在列表里但没绑定就重新绑定（都需要 adb 授予 WRITE_SECURE_SETTINGS）。
 * 不读取、不处理任何通知。做法来自 PlanYourTV 的 RevivalListener（MIT）。
 */
class RevivalListener : NotificationListenerService() {
    private val handler = Handler(Looper.getMainLooper())
    private var attempt = 0
    private val check = Runnable { checkGuard() }

    override fun onListenerConnected() {
        attempt = 0
        handler.removeCallbacks(check)
        handler.postDelayed(check, RETRY_DELAYS_MS[0])
    }

    private fun checkGuard() {
        if (GuardService.instance != null || !App.instance.prefs.locked) return
        if (!LockManager.ensureGuardEnabled(this)) LockManager.rebindIfStalled(this)
        attempt++
        if (attempt < RETRY_DELAYS_MS.size) handler.postDelayed(check, RETRY_DELAYS_MS[attempt])
    }

    override fun onListenerDisconnected() {
        handler.removeCallbacks(check)
    }

    override fun onDestroy() {
        handler.removeCallbacks(check)
        super.onDestroy()
    }

    private companion object {
        /** 大约两分钟内重试几次，不做常驻的看门狗 */
        val RETRY_DELAYS_MS = longArrayOf(2_000, 5_000, 10_000, 15_000, 30_000, 60_000)
    }
}

/** 开机：锁定中就把守护服务写回去（如果被删了），并把豆豆乐园拉到前台。 */
class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // 导出只为接收开机广播，其他来源一律忽略，免得被拿来把豆豆乐园拉到前台
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!App.instance.prefs.locked) return
        LockManager.ensureGuardEnabled(context)
        // Android 10+ 从广播里启动界面需要悬浮窗权限，锁定前已要求开启
        LockManager.bringToFront(context)
    }
}
