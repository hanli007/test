package com.doudou.kids.lock

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.input.InputManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import com.doudou.kids.App
import com.doudou.kids.core.InputDeviceRules
import com.doudou.kids.core.KeyFilterRules
import com.doudou.kids.core.LockAction
import com.doudou.kids.core.LockKeys
import com.doudou.kids.core.LockPolicy
import com.doudou.kids.core.PullBackRules

/**
 * 锁定守护：只监听前台窗口变化和按键，不读取窗口内容、不开触摸浏览，不影响点击。
 * 发现前台不是豆豆乐园或白名单 app，立刻拉回。
 *
 * 不是默认桌面时（guard 变体，或固件不让换桌面），也靠它把厂商桌面挡回去：
 * 厂商桌面出现在前台、或系统发出 Home 键的 "homekey" 广播时拉回。
 * 电视固件上的处理参考 PlanYourTV 的 HomeGuardService（MIT），见 core/GuardRules.kt。
 */
class GuardService : AccessibilityService() {
    private val prefs get() = App.instance.prefs
    private lateinit var policy: LockPolicy
    private val handler = Handler(Looper.getMainLooper())
    private var lastPullAt = 0L
    private var screenOn = true
    private var gamepadOrMouse = false
    private var overlay: GuardOverlay? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> screenOn = false
                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    // 有的电视唤醒时直接显示厂商桌面，不发窗口变化事件
                    handler.postDelayed({ pullBackIfOutside() }, SETTLE_MS)
                }
            }
            updateKeyFilter()
        }
    }

    /** 不过滤按键时，Home 键靠系统的 "homekey" 广播得知 */
    private val homeKeyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getStringExtra("reason") != "homekey") return
            if (!LockManager.locked.value || LockManager.isDefaultHome(this@GuardService)) return
            handler.postDelayed({ pullBack() }, 300)
        }
    }

    private val inputListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = scanInputDevices()
        override fun onInputDeviceRemoved(deviceId: Int) = scanInputDevices()
        override fun onInputDeviceChanged(deviceId: Int) = scanInputDevices()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        LockManager.reportGuardRunning(true)
        screenOn = getSystemService(PowerManager::class.java)?.isInteractive != false
        refresh()
        val screenFilter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        ContextCompat.registerReceiver(this, screenReceiver, screenFilter, ContextCompat.RECEIVER_EXPORTED)
        @Suppress("DEPRECATION")
        val homeFilter = IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
        ContextCompat.registerReceiver(this, homeKeyReceiver, homeFilter, ContextCompat.RECEIVER_EXPORTED)
        getSystemService(InputManager::class.java)?.registerInputDeviceListener(inputListener, handler)
        scanInputDevices()
        overlay = GuardOverlay(this)

        if (prefs.lockPending) {
            prefs.lockPending = false
            LockManager.setLocked(true)
            LockManager.bringToFront(this)
        } else if (prefs.locked) {
            // 开机或被固件杀掉后重新连上：前台是什么不知道，锁定中就拉回。
            // 有的固件开机后会晚一点再把自己的桌面盖上来，开机 3 分钟内再补查两次
            pullBackIfOutside()
            if (SystemClock.elapsedRealtime() < BOOT_WINDOW_MS) {
                for (d in BOOT_RECHECKS_MS) handler.postDelayed({ pullBackIfOutside() }, d)
            }
        }
        updateKeyFilter()
    }

    /** 白名单变化或重新锁定时调用。 */
    fun refresh() {
        val imes = getSystemService(InputMethodManager::class.java)?.enabledInputMethodList
            ?.map { it.packageName }?.toSet().orEmpty()
        policy = LockPolicy(packageName, prefs.allowedApps, imes)
    }

    /** 锁定状态、豆豆乐园是否在前台变化时由 LockManager 调用。 */
    fun onStateChanged() {
        handler.post {
            updateKeyFilter()
            overlay?.refresh()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val action = policy.onWindow(LockManager.locked.value, pkg, event.className?.toString())
        // 系统界面和输入法不算「前台 app」，免得计时把它们当成离开了豆豆乐园
        if (action != LockAction.COLLAPSE && pkg !in policy.imePackages && pkg !in LockPolicy.PERMISSION_UI) {
            LockManager.reportForeground(pkg)
            overlay?.refresh()
        }
        when (action) {
            LockAction.ALLOW -> Unit
            LockAction.COLLAPSE -> collapseSystemPanels()
            LockAction.PULL_BACK -> pullBack()
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!LockManager.locked.value) return false
        val alphabetic = event.device?.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
        if (KeyFilterRules.isHome(event.keyCode, event.scanCode, alphabetic)) {
            if (!KeyFilterRules.takeHome(true, LockManager.isDefaultHome(this))) return false
            // 截下 Home 键，系统看不到，也就没有 Android 11 及以下的 5 秒限制
            if (event.action == KeyEvent.ACTION_UP && !event.isCanceled) pullBack(force = true)
            return true
        }
        return LockKeys.shouldBlock(true, event.keyCode)
    }

    /** 豆豆乐园或白名单 app 以外的东西在前台时拉回。前台未知时也拉回（锁定中孩子本该在豆豆乐园里）。 */
    fun pullBackIfOutside() {
        if (!LockManager.locked.value) return
        val front = LockManager.foreground.value
        if (front == null || policy.onWindow(true, front, null) == LockAction.PULL_BACK) pullBack()
    }

    /** 计时：时间用完或该休息时，把孩子从白名单 app 里带回豆豆乐园显示提示页。 */
    fun pullBackFromApp() {
        handler.post {
            if (LockManager.locked.value && !LockManager.appResumed.value) pullBack(force = true)
        }
    }

    fun showBanner(text: String) {
        handler.post { overlay?.banner(text) }
    }

    private fun pullBack(force: Boolean = false) {
        val tvPowerMode = runCatching { Settings.Global.getString(contentResolver, "tv_power_mode") }.getOrNull()
        if (!PullBackRules.allowed(screenOn, tvPowerMode)) return
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastPullAt < PULL_DEBOUNCE_MS) return
        lastPullAt = now
        val intent = LockManager.bringToFrontIntent(this)
        if (PullBackRules.viaPendingIntent(Build.VERSION.SDK_INT) && sendPending(intent)) return
        // 是默认桌面时用 Home 动作最稳：不受后台启动界面的限制，HomeActivity 会转到孩子首页
        if (LockManager.isDefaultHome(this)) performGlobalAction(GLOBAL_ACTION_HOME)
        else runCatching { startActivity(intent) }
    }

    /** Android 5–8.1 上 Home 键之后 5 秒内 app 自己启动界面会被压住；PendingIntent 由系统发出，不受这个限制。 */
    private fun sendPending(intent: Intent): Boolean = runCatching {
        PendingIntent.getActivity(this, PULL_REQUEST, intent, PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE).send()
    }.isSuccess

    private fun collapseSystemPanels() {
        if (Build.VERSION.SDK_INT >= 31) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } else {
            @Suppress("DEPRECATION")
            sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
        }
    }

    /** 按需开关按键过滤，规则见 KeyFilterRules。 */
    private fun updateKeyFilter() {
        val info = serviceInfo ?: return
        val flag = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        val want = KeyFilterRules.wanted(
            locked = LockManager.locked.value,
            screenOn = screenOn,
            sdk = Build.VERSION.SDK_INT,
            selfInFront = LockManager.appResumed.value,
            gamepadOrMouse = gamepadOrMouse,
        )
        val flags = if (want) info.flags or flag else info.flags and flag.inv()
        if (flags == info.flags) return
        info.flags = flags
        serviceInfo = info
    }

    private fun scanInputDevices() {
        gamepadOrMouse = runCatching {
            InputDevice.getDeviceIds().any { id ->
                val d = InputDevice.getDevice(id) ?: return@any false
                val pad = InputDeviceRules.isPhysicalGamepad(
                    name = d.name,
                    isVirtual = d.isVirtual,
                    supportsGamepad = d.supportsSource(InputDevice.SOURCE_GAMEPAD),
                    vendorId = d.vendorId,
                    productId = d.productId,
                    alphabetic = d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC,
                )
                val mouse = Build.VERSION.SDK_INT >= 29 &&
                    InputDeviceRules.isExternalMouse(d.isExternal, d.isVirtual, d.supportsSource(InputDevice.SOURCE_MOUSE))
                pad || mouse
            }
        }.getOrDefault(false)
        updateKeyFilter()
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        if (instance !== this) return
        instance = null
        LockManager.reportGuardRunning(false)
        handler.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(screenReceiver) }
        runCatching { unregisterReceiver(homeKeyReceiver) }
        runCatching { getSystemService(InputManager::class.java)?.unregisterInputDeviceListener(inputListener) }
        overlay?.remove()
        overlay = null
    }

    companion object {
        private const val PULL_DEBOUNCE_MS = 400L
        private const val PULL_REQUEST = 933
        private const val SETTLE_MS = 1_500L
        private const val BOOT_WINDOW_MS = 3 * 60_000L
        private val BOOT_RECHECKS_MS = listOf(30_000L, 45_000L)

        /** 服务连上时非空 */
        @Volatile
        var instance: GuardService? = null
            private set
    }
}
