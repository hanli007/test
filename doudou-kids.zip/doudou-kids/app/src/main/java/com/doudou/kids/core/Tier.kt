package com.doudou.kids.core

/** 年龄档位：决定界面风格、内容范围和默认时长。 */
enum class Tier(val code: String, val label: String, val ageRange: IntRange) {
    QM("qm", "启蒙版", 0..5),
    TQ("tq", "童趣版", 6..11),
    SN("sn", "少年版", 12..15);

    companion object {
        fun forAge(age: Int): Tier = when {
            age < 6 -> QM
            age < 12 -> TQ
            else -> SN
        }
    }
}

/** 按年龄给出的默认时间规则，家长可以再改。依据见方案文档 3.7。 */
object TimeDefaults {
    const val WINDOW_START = 8 * 60
    const val WINDOW_END = 21 * 60

    fun forAge(age: Int): TimeRule {
        val (weekday, weekend, session) = when {
            age < 3 -> Triple(20, 20, 10)
            age < 6 -> Triple(45, 45, 15)
            age < 12 -> Triple(60, 90, 20)
            else -> Triple(90, 120, 30)
        }
        return TimeRule(
            dailyWeekdayMin = weekday,
            dailyWeekendMin = weekend,
            sessionMin = session,
            restMin = 5,
            windowStartMin = WINDOW_START,
            windowEndMin = WINDOW_END,
        )
    }
}
