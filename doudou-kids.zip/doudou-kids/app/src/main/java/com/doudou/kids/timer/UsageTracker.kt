package com.doudou.kids.timer

import android.os.PowerManager
import android.os.SystemClock
import com.doudou.kids.App
import com.doudou.kids.core.Block
import com.doudou.kids.core.TimeRules
import com.doudou.kids.core.TimeStatus
import com.doudou.kids.core.UsageClock
import com.doudou.kids.data.Prefs
import com.doudou.kids.data.ProfileEntity
import com.doudou.kids.data.UsageEntity
import com.doudou.kids.lock.GuardService
import com.doudou.kids.lock.LockManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

/**
 * 计时（方案 3.7）：手机和电视都由豆豆乐园计时。
 * 锁定时，豆豆乐园或白名单 app 在前台、屏幕亮着才计时；未锁定（家长在用）不计时。
 * 时长用开机后流逝时间累加，不依赖系统时钟；每天 0 点按设备日期重置。
 */
class UsageTracker(private val app: App) {
    private val prefs: Prefs get() = app.prefs
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val clock = UsageClock()

    private val _profile = MutableStateFlow<ProfileEntity?>(null)
    val profile: StateFlow<ProfileEntity?> = _profile.asStateFlow()

    private val _status = MutableStateFlow(TimeStatus(Block.NONE, 0, false))
    val status: StateFlow<TimeStatus> = _status.asStateFlow()

    /** 今天已用秒数 */
    private val _usedSec = MutableStateFlow(0L)
    val usedSec: StateFlow<Long> = _usedSec.asStateFlow()

    private var day = Prefs.dayKey()
    private var unsavedSec = 0L
    private var warned = false

    fun start() {
        scope.launch {
            app.db.profiles().observeAll().collect { list ->
                val cur = list.firstOrNull { it.id == prefs.currentProfileId } ?: list.firstOrNull()
                if (cur?.id != _profile.value?.id) loadUsage(cur)
                _profile.value = cur
                evaluate()
            }
        }
        scope.launch {
            while (true) {
                tick()
                delay(TICK_MS)
            }
        }
    }

    fun selectProfile(id: Long) {
        prefs.currentProfileId = id
        scope.launch {
            val p = withContext(Dispatchers.IO) { app.db.profiles().get(id) } ?: return@launch
            saveUsage()
            loadUsage(p)
            _profile.value = p
            evaluate()
        }
    }

    /** 家长输入密码后延长今天的时间 */
    fun extend(minutes: Int) {
        prefs.addExtraMinutes(Prefs.dayKey(), minutes)
        warned = false
        evaluate()
    }

    /** 家长输入密码后允许今天在可用时段外使用 */
    fun allowOutOfWindowToday() {
        prefs.setWindowOverride(Prefs.dayKey())
        evaluate()
    }

    private suspend fun loadUsage(p: ProfileEntity?) {
        day = Prefs.dayKey()
        _usedSec.value = if (p == null) 0L else withContext(Dispatchers.IO) { app.db.usage().used(p.id, day) } ?: 0L
        unsavedSec = 0
    }

    private suspend fun saveUsage() {
        val p = _profile.value ?: return
        if (unsavedSec == 0L) return
        val row = UsageEntity(p.id, day, _usedSec.value)
        unsavedSec = 0
        withContext(Dispatchers.IO) { app.db.usage().put(row) }
    }

    private suspend fun tick() {
        val today = Prefs.dayKey()
        if (today != day) {
            saveUsage()
            loadUsage(_profile.value)
            prefs.sessionSec = 0
            warned = false
        }
        // 休息结束：连续使用时长清零
        if (prefs.restUntil in 1..System.currentTimeMillis()) {
            prefs.restUntil = 0
            prefs.sessionSec = 0
        }
        val active = isCounting()
        val sec = clock.tick(SystemClock.elapsedRealtime(), active)
        if (sec > 0) {
            _usedSec.value += sec
            prefs.sessionSec += sec
            unsavedSec += sec
            if (unsavedSec >= SAVE_EVERY_SEC) saveUsage()
        }
        evaluate()
    }

    private fun isCounting(): Boolean {
        if (!LockManager.locked.value || _profile.value == null) return false
        if (app.getSystemService(PowerManager::class.java)?.isInteractive == false) return false
        if (_status.value.block != Block.NONE) return false
        if (LockManager.appResumed.value) return true
        val front = LockManager.foreground.value ?: return false
        return front in prefs.allowedApps
    }

    private fun evaluate() {
        val p = _profile.value ?: return
        val cal = Calendar.getInstance()
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val rule = p.timeRule().let { if (prefs.restEnabled) it else it.copy(sessionMin = 0) }
        val now = System.currentTimeMillis()
        val st = TimeRules.evaluate(
            rule = rule,
            minuteOfDay = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE),
            weekend = dow == Calendar.SATURDAY || dow == Calendar.SUNDAY,
            usedTodaySec = _usedSec.value,
            sessionSec = prefs.sessionSec,
            extraMin = prefs.extraMinutes(Prefs.dayKey()),
            windowOverride = prefs.windowOverride(Prefs.dayKey()),
            restActive = prefs.restUntil > now,
        )
        // 连续使用到时：开始强制休息
        if (st.block == Block.REST && prefs.restUntil <= now) prefs.restUntil = now + rule.restMin.coerceAtLeast(1) * 60_000L
        val prev = _status.value
        _status.value = st
        if (st.block != Block.NONE && prev.block == Block.NONE) {
            scope.launch { saveUsage() }
            // 孩子在白名单 app 里：带回豆豆乐园显示提示页
            GuardService.instance?.pullBackFromApp()
        }
        if (st.warnSoon && !warned) {
            warned = true
            if (!LockManager.appResumed.value) GuardService.instance?.showBanner("还剩 5 分钟，准备休息啦")
        }
        if (!st.warnSoon) warned = false
    }

    /** 休息还剩多少毫秒 */
    fun restLeftMs(): Long = (prefs.restUntil - System.currentTimeMillis()).coerceAtLeast(0)

    private companion object {
        const val TICK_MS = 1_000L
        const val SAVE_EVERY_SEC = 10L
    }
}
