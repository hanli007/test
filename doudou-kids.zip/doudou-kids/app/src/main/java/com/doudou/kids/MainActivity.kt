package com.doudou.kids

import android.Manifest
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.doudou.kids.core.Block
import com.doudou.kids.core.GameCatalog
import com.doudou.kids.core.ItemStatus
import com.doudou.kids.data.SourceItemEntity
import com.doudou.kids.eyecare.DistanceMonitor
import com.doudou.kids.games.GameRepository
import com.doudou.kids.lock.LockManager
import com.doudou.kids.ui.DoudouTheme
import com.doudou.kids.ui.Navigator
import com.doudou.kids.ui.PinDialog
import com.doudou.kids.ui.Route
import com.doudou.kids.ui.kid.AppsScreen
import com.doudou.kids.ui.kid.EyeFilterLayer
import com.doudou.kids.ui.kid.GameHall
import com.doudou.kids.ui.kid.GameScreen
import com.doudou.kids.ui.kid.KidData
import com.doudou.kids.ui.kid.KidHome
import com.doudou.kids.ui.kid.LabList
import com.doudou.kids.ui.kid.OutOfWindowScreen
import com.doudou.kids.ui.kid.PlayerScreen
import com.doudou.kids.ui.kid.ProfilePicker
import com.doudou.kids.ui.kid.RestScreen
import com.doudou.kids.ui.kid.SiteList
import com.doudou.kids.ui.kid.TimeUpScreen
import com.doudou.kids.ui.kid.TooCloseOverlay
import com.doudou.kids.ui.kid.VideoList
import com.doudou.kids.ui.kid.WebScreen
import com.doudou.kids.ui.parent.ActivationScreen
import com.doudou.kids.ui.parent.ParentHome
import com.doudou.kids.ui.parent.ParentPageScreen
import com.doudou.kids.ui.parent.SetupWizard
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

/**
 * 唯一的界面入口。状态顺序：未激活 → 首次设置 → 未锁定（家长设置）/ 锁定（孩子端）。
 * 锁定时叠加：休息、时间用完、时段外、距离太近的提示页，以及护眼滤镜。
 */
class MainActivity : ComponentActivity() {
    private val app get() = App.instance

    /** 回到前台时加一，触发权限状态重新检测 */
    private var resumeTick by mutableIntStateOf(0)
    private var showUnlock by mutableStateOf(false)
    private var activated by mutableStateOf(true)
    private var setupDone by mutableStateOf(true)
    private val distance by lazy { DistanceMonitor(this) }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) app.prefs.distanceEnabled = false
        updateDistanceMonitor()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activated = app.activation.isActivated
        setupDone = app.prefs.setupDone && app.pin.isSet
        // 进入时刷新一次视频源列表（只缓存元数据）
        lifecycleScope.launch { app.sources.refreshAll() }
        setContent {
            DoudouTheme {
                when {
                    !activated -> ActivationScreen(app.isTv) { activated = true }
                    !setupDone -> SetupWizard(app.isTv) { setupDone = true }
                    else -> Root()
                }
            }
        }
    }

    @Composable
    private fun Root() {
        val locked by LockManager.locked.collectAsState()
        val nav = remember(locked) { Navigator(if (locked) Route.KidHome else Route.ParentHome) }
        Box(Modifier.fillMaxSize()) {
            if (locked) KidRoot(nav) else ParentRoot(nav)
            if (locked) EyeFilterLayer()
        }
        if (showUnlock) {
            PinDialog("家长密码", app.pin, onDismiss = { showUnlock = false }) {
                showUnlock = false
                LockManager.unlock(this@MainActivity)
            }
        }
    }

    @Composable
    private fun ParentRoot(nav: Navigator) {
        BackHandler(enabled = nav.stack.size > 1) { nav.pop() }
        when (val r = nav.current) {
            is Route.Parent -> ParentPageScreen(r.page, this, app.isTv, resumeTick, nav) { requestCamera() }
            else -> ParentHome(this, app.isTv, nav)
        }
    }

    @Composable
    private fun KidRoot(nav: Navigator) {
        val profiles by app.db.profiles().observeAll().collectAsState(initial = emptyList())
        val profile by app.tracker.profile.collectAsState()
        val status by app.tracker.status.collectAsState()
        val tooClose by distance.tooClose.collectAsState()
        // 每次锁定后，有多个档案时先选人
        var picked by remember { mutableStateOf(false) }
        val p = profile
        val videosFlow = remember { app.sources.visibleItems(app.tracker.profile) }
        val videos by videosFlow.collectAsState(initial = emptyList())
        val sitesFlow = remember(p?.id) { p?.let { app.db.whitelist().observeSites(it.id) } ?: flowOf(emptyList()) }
        val sites by sitesFlow.collectAsState(initial = emptyList())
        var blockTarget by remember { mutableStateOf<SourceItemEntity?>(null) }

        // 锁定时首页按返回键无反应；其他页面返回上一页
        BackHandler { nav.pop() }

        if (p == null) return
        if (profiles.size > 1 && !picked) {
            ProfilePicker(profiles, app.isTv) {
                app.tracker.selectProfile(it.id)
                picked = true
            }
            return
        }
        val games = remember(p.age) { GameCatalog.visible(GameRepository.all(this), p.age, app.isTv) }
        val d = KidData(p, app.isTv, status, games, videos, sites)
        val blocked = status.block != Block.NONE
        val paused = blocked || tooClose || showUnlock
        // 时间用完、时段外的提示页上有按钮；电视上内容页（WebView）会占着焦点，所以先退回首页
        LaunchedEffect(status.block) {
            if (status.block == Block.TIME_UP || status.block == Block.OUT_OF_WINDOW) nav.reset(Route.KidHome)
        }

        when (val r = nav.current) {
            Route.KidHome, Route.ProfilePicker -> KidHome(d, nav) { showUnlock = true }
            Route.Videos -> VideoList(d, nav) { blockTarget = it }
            Route.Games -> GameHall(d, nav)
            Route.Labs -> LabList(d, nav)
            Route.Sites -> SiteList(d, nav)
            Route.Apps -> AppsScreen(d, nav)
            is Route.Game -> GameScreen(d, r.entry, paused) { nav.pop() }
            is Route.Player -> PlayerScreen(d, r.item, paused) { nav.pop() }
            is Route.Web -> WebScreen(d, r.title, r.url, r.domains, r.stat, paused) { nav.pop() }
            else -> KidHome(d, nav) { showUnlock = true }
        }

        when (status.block) {
            Block.REST -> RestScreen(app.isTv)
            Block.TIME_UP -> TimeUpScreen(app.isTv)
            Block.OUT_OF_WINDOW -> OutOfWindowScreen(app.isTv, p.windowStartMin, p.windowEndMin)
            Block.NONE -> if (tooClose) TooCloseOverlay(app.isTv)
        }

        // 长按视频，家长输入密码后屏蔽这一条（过滤第 5 层）
        blockTarget?.let { item ->
            PinDialog("屏蔽「${item.title}」", app.pin, onDismiss = { blockTarget = null }) {
                blockTarget = null
                lifecycleScope.launch { app.sources.setStatus(item.id, ItemStatus.BLOCKED) }
            }
        }
        LaunchedEffect(Unit) { updateDistanceMonitor() }
    }

    private fun requestCamera() {
        if (distance.hasPermission()) updateDistanceMonitor() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    /** 距离提醒只在锁定、家长开启、豆豆乐园在前台时运行 */
    private fun updateDistanceMonitor() {
        if (LockManager.locked.value && app.prefs.distanceEnabled && LockManager.appResumed.value) distance.start(this)
        else distance.stop()
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
        LockManager.setAppResumed(true)
        updateDistanceMonitor()
    }

    override fun onPause() {
        LockManager.setAppResumed(false)
        distance.stop()
        super.onPause()
    }

    /** 电视：锁定时长按遥控器确认键 5 秒，弹出家长密码（方案 3.1.3）。 */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val confirm = event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER ||
            event.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER
        if (confirm && LockManager.locked.value && !showUnlock && event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount > 0 && event.eventTime - event.downTime >= UNLOCK_HOLD_MS
        ) {
            showUnlock = true
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    companion object {
        const val UNLOCK_HOLD_MS = 5_000L
    }
}
