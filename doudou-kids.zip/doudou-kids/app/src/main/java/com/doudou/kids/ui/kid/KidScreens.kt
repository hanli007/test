package com.doudou.kids.ui.kid

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.doudou.kids.App
import com.doudou.kids.content.BuiltinContent
import com.doudou.kids.core.GameEntry
import com.doudou.kids.core.Tier
import com.doudou.kids.core.TimeStatus
import com.doudou.kids.data.ProfileEntity
import com.doudou.kids.data.SourceItemEntity
import com.doudou.kids.data.WhitelistSiteEntity
import com.doudou.kids.lock.LockManager
import com.doudou.kids.ui.BigTile
import com.doudou.kids.ui.ContentCard
import com.doudou.kids.ui.FocusCard
import com.doudou.kids.ui.Navigator
import com.doudou.kids.ui.Route
import com.doudou.kids.ui.ScreenScaffold
import com.doudou.kids.ui.SectionTitle
import com.doudou.kids.ui.TimePill
import com.doudou.kids.ui.hexColor
import com.doudou.kids.ui.tileColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

/** 孩子端页面需要的数据，由 MainActivity 收集后传进来 */
data class KidData(
    val profile: ProfileEntity,
    val isTv: Boolean,
    val status: TimeStatus,
    val games: List<GameEntry>,
    val videos: List<SourceItemEntity>,
    val sites: List<WhitelistSiteEntity>,
) {
    val tier: Tier get() = profile.tier
    val sims: List<BuiltinContent.Sim> get() = BuiltinContent.PHET.filter { profile.age >= it.ageMin }
    val showBooks: Boolean get() = profile.age >= BuiltinContent.STORYWEAVER_AGE_MIN
}

private data class Entry(val label: String, val emoji: String, val route: Route)

fun booksRoute() = Route.Web("看绘本", BuiltinContent.STORYWEAVER_URL, BuiltinContent.STORYWEAVER_DOMAINS, "books")

private fun entries(d: KidData): List<Entry> = buildList {
    val qm = d.tier == Tier.QM
    add(Entry(if (qm) "看动画" else "看视频", "📺", Route.Videos))
    add(Entry("玩游戏", "🎮", Route.Games))
    if (d.showBooks) add(Entry(if (qm) "听故事" else "看绘本", "📖", booksRoute()))
    if (!qm && d.sims.isNotEmpty()) add(Entry("做实验", "🧪", Route.Labs))
    if (!qm && d.sites.isNotEmpty()) add(Entry("学习网站", "🌐", Route.Sites))
    if (App.instance.prefs.allowedApps.isNotEmpty()) add(Entry("我的应用", "🧩", Route.Apps))
}

private fun greeting(name: String): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val part = when (h) {
        in 5..10 -> "早上好"
        in 11..13 -> "中午好"
        in 14..17 -> "下午好"
        else -> "晚上好"
    }
    return "$part，$name"
}

/* ---------- 档案选择 ---------- */

@Composable
fun ProfilePicker(profiles: List<ProfileEntity>, isTv: Boolean, onPick: (ProfileEntity) -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(profiles.size) { runCatching { first.requestFocus() } }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("你是谁呀？", fontSize = if (isTv) 40.sp else 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            profiles.forEachIndexed { i, p ->
                BigTile(
                    label = p.name,
                    emoji = listOf("🐶", "🐱", "🐰", "🐻", "🐼")[i % 5],
                    color = tileColor(i, false),
                    modifier = Modifier.width(if (isTv) 220.dp else 140.dp),
                    height = if (isTv) 220.dp else 150.dp,
                    focusRequester = if (i == 0) first else null,
                ) { onPick(p) }
            }
        }
    }
}

/* ---------- 首页 ---------- */

@Composable
fun KidHome(d: KidData, nav: Navigator, onHiddenUnlock: () -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    val mature = d.tier == Tier.SN
    val list = entries(d)
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = if (d.isTv) 48.dp else 18.dp, vertical = if (d.isTv) 28.dp else 14.dp),
        ) {
            item {
                Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!mature) Text("🐶", fontSize = if (d.isTv) 48.sp else 36.sp)
                    Text(
                        if (d.tier == Tier.QM) "豆豆乐园" else greeting(d.profile.name),
                        fontSize = if (d.isTv) 34.sp else 24.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f).padding(start = 8.dp),
                    )
                    TimePill(d.status.remainingSec, d.status.warnSoon)
                }
            }
            if (d.tier == Tier.QM && !d.isTv) {
                // 启蒙版手机：2×2 超大入口，几乎没有文字
                items(list.chunked(2)) { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                        row.forEachIndexed { i, e ->
                            val idx = list.indexOf(e)
                            BigTile(
                                e.label, e.emoji, tileColor(idx, false), Modifier.weight(1f), height = 172.dp, fontSize = 26,
                                focusRequester = if (idx == 0) first else null,
                            ) { nav.push(e.route) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                        Text("🐶", fontSize = 72.sp)
                        Surface(shape = RoundedCornerShape(20.dp), color = Color.White) {
                            Text("今天想玩什么呀？", fontSize = 20.sp, modifier = Modifier.padding(16.dp))
                        }
                    }
                }
            } else {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(if (d.isTv) 20.dp else 10.dp)) {
                        list.forEachIndexed { i, e ->
                            BigTile(
                                e.label, e.emoji, tileColor(i, mature), Modifier.weight(1f),
                                height = if (d.isTv) 170.dp else 96.dp, fontSize = if (d.isTv) 22 else 14,
                                focusRequester = if (i == 0) first else null,
                            ) { nav.push(e.route) }
                        }
                    }
                }
                homeSections(d, nav)
            }
        }
        // 手机：长按右上角 3 秒弹出家长密码。不显示任何提示，免得孩子发现（电视用长按确认键，见 MainActivity）
        Box(
            Modifier.align(Alignment.TopEnd).size(72.dp).pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    val up = withTimeoutOrNull(HIDDEN_HOLD_MS) { waitForUpOrCancellation() }
                    if (up == null) onHiddenUnlock()
                }
            },
        )
    }
}

private const val HIDDEN_HOLD_MS = 3_000L

/** 首页下面的几行内容，按档位不同（与原型一致） */
private fun androidx.compose.foundation.lazy.LazyListScope.homeSections(d: KidData, nav: Navigator) {
    val w = if (d.isTv) 240.dp else 150.dp
    val games = d.games.take(10)
    val videos = d.videos.take(12)
    fun gameRow(title: String, sub: String) {
        if (games.isEmpty()) return
        item { SectionTitle(title, sub, d.isTv) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
                items(games, key = { it.id }) { g -> ContentCard(g.title, g.desc, hexColor(g.color), gameEmoji(g.icon), w) { nav.push(Route.Game(g)) } }
            }
        }
    }
    fun videoRow(title: String) {
        if (videos.isEmpty()) return
        item { SectionTitle(title, "已按年龄过滤", d.isTv) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
                items(videos, key = { it.id }) { v -> ContentCard(v.title, v.category, Color(0xFF5B7CFA), "🎬", w) { openItem(nav, v) } }
            }
        }
    }
    when (d.tier) {
        Tier.QM -> { gameRow("继续玩", ""); videoRow("看动画") }
        Tier.TQ -> {
            gameRow("今天玩点什么", "${d.games.size} 个游戏")
            if (d.showBooks) {
                item { SectionTitle("绘本", "StoryWeaver 中文绘本", d.isTv) }
                item { ContentCard("打开绘本馆", "按难度分级", Color(0xFF3FBF84), "📚", w) { nav.push(booksRoute()) } }
            }
            videoRow("科普小视频")
        }
        Tier.SN -> {
            if (d.sims.isNotEmpty()) {
                item { SectionTitle("互动实验", "PhET 中文版", d.isTv) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
                        items(d.sims.takeLast(10), key = { it.id }) { s -> ContentCard(s.title, s.subject, Color(0xFF6FA8FF), "🧪", w) { nav.push(labRoute(s)) } }
                    }
                }
            }
            gameRow("逻辑游戏", "进度自动保存")
            videoRow("学科视频")
        }
    }
}

fun labRoute(s: BuiltinContent.Sim) = Route.Web(s.title, s.url, BuiltinContent.PHET_DOMAINS, "labs")

/** 视频源条目：video 用原生播放器，webpage 用受限网页打开（只放行该条目所在域名） */
fun openItem(nav: Navigator, v: SourceItemEntity) {
    if (v.type == "webpage") {
        val host = com.doudou.kids.core.UrlRules.hostOf(v.url) ?: return
        nav.push(Route.Web(v.title, v.url, setOf(host), "videos"))
    } else {
        nav.push(Route.Player(v))
    }
}

fun gameEmoji(icon: String): String = when (icon) {
    "bubble" -> "🫧"; "cards" -> "🃏"; "path" -> "🧭"; "palette" -> "🎨"; "count" -> "🔢"; "train" -> "🚂"
    "stack" -> "🗼"; "grid" -> "🧩"; "calc" -> "➗"; "piano" -> "🎹"; "quiz" -> "❓"; "box" -> "📦"
    "keyboard" -> "⌨️"; "leaf" -> "🍃"; "star" -> "⭐"
    else -> "🎲"
}

/* ---------- 分类页 ---------- */

@Composable
fun GameHall(d: KidData, nav: Navigator) {
    ScreenScaffold("玩游戏", d.isTv, onBack = { nav.pop() }) {
        if (d.games.isEmpty()) {
            Text("还没有适合你的游戏")
            return@ScreenScaffold
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(if (d.isTv) 240.dp else 150.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(8.dp),
        ) {
            items(d.games, key = { it.id }) { g ->
                ContentCard(g.title, g.desc, hexColor(g.color), gameEmoji(g.icon), if (d.isTv) 240.dp else 150.dp) { nav.push(Route.Game(g)) }
            }
        }
    }
}

/**
 * 视频列表：按分类分行，不做推荐信息流，不自动连播，每个分类看到底就结束（方案 4.2）。
 * 长按任意内容可由家长输入密码后屏蔽（过滤第 5 层）。
 */
@Composable
fun VideoList(d: KidData, nav: Navigator, onBlockRequest: (SourceItemEntity) -> Unit) {
    ScreenScaffold(if (d.tier == Tier.QM) "看动画" else "看视频", d.isTv, onBack = { nav.pop() }) {
        if (d.videos.isEmpty()) {
            Text("还没有视频，请家长在「家长设置 → 视频源」里添加", color = Color.Gray)
            return@ScreenScaffold
        }
        val w = if (d.isTv) 260.dp else 160.dp
        LazyColumn {
            d.videos.groupBy { it.category }.forEach { (cat, list) ->
                item { SectionTitle(cat, "${list.size} 个", d.isTv) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
                        items(list, key = { it.id }) { v ->
                            ContentCard(
                                v.title, v.durationSec?.let { "${(it + 59) / 60} 分钟" } ?: "", Color(0xFF5B7CFA),
                                if (v.type == "webpage") "🌐" else "🎬", w, onLongClick = { onBlockRequest(v) },
                            ) { openItem(nav, v) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LabList(d: KidData, nav: Navigator) {
    ScreenScaffold("做实验", d.isTv, onBack = { nav.pop() }) {
        Text("PhET 互动实验（科罗拉多大学，CC BY-NC 4.0）", fontSize = 13.sp, color = Color.Gray)
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            d.sims.groupBy { it.subject }.forEach { (subject, sims) ->
                item { SectionTitle(subject, "", d.isTv) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
                        items(sims, key = { it.id }) { s ->
                            ContentCard(s.title, "${s.ageMin} 岁以上", Color(0xFF6FA8FF), "🧪", if (d.isTv) 240.dp else 150.dp) { nav.push(labRoute(s)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SiteList(d: KidData, nav: Navigator) {
    ScreenScaffold("学习网站", d.isTv, onBack = { nav.pop() }) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(if (d.isTv) 260.dp else 160.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(d.sites, key = { it.id }) { s ->
                ContentCard(s.name, s.domain, Color(0xFF3FBF84), "🌐", if (d.isTv) 260.dp else 160.dp) {
                    nav.push(Route.Web(s.name, s.startUrl, setOf(s.domain), "sites"))
                }
            }
        }
    }
}

/* ---------- 白名单 app ---------- */

private data class AppTile(val pkg: String, val label: String, val icon: ImageBitmap?)

private suspend fun loadTiles(ctx: Context): List<AppTile> = withContext(Dispatchers.IO) {
    val pm = ctx.packageManager
    App.instance.prefs.allowedApps.mapNotNull { pkg ->
        val ai = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull() ?: return@mapNotNull null
        val icon = runCatching { pm.getApplicationIcon(ai).toBitmap(128, 128).asImageBitmap() }.getOrNull()
        AppTile(pkg, ai.loadLabel(pm).toString(), icon)
    }.sortedBy { it.label }
}

@Composable
fun AppsScreen(d: KidData, nav: Navigator) {
    val ctx = LocalContext.current
    val tiles by produceState(emptyList<AppTile>()) { value = loadTiles(ctx) }
    ScreenScaffold("我的应用", d.isTv, onBack = { nav.pop() }) {
        if (tiles.isEmpty()) {
            Text("家长还没有添加可以打开的 app", color = Color.Gray)
            return@ScreenScaffold
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(if (d.isTv) 180.dp else 110.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(tiles, key = { it.pkg }) { t ->
                FocusCard(onClick = { LockManager.launchApp(ctx, t.pkg, preferTv = d.isTv) }) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        val size = if (d.isTv) 96.dp else 64.dp
                        if (t.icon != null) Image(t.icon, contentDescription = null, modifier = Modifier.size(size))
                        else Box(Modifier.size(size).background(Color(0x22000000), RoundedCornerShape(12.dp)))
                        Spacer(Modifier.height(8.dp))
                        Text(t.label, fontSize = if (d.isTv) 20.sp else 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
