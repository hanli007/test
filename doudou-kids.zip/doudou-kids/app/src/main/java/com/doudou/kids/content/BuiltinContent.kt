package com.doudou.kids.content

/** 内置内容（方案 3.5、5.3、5.4）。 */
object BuiltinContent {

    /* ---------- PhET 互动实验（CC BY-NC 4.0，仅限非商业使用） ---------- */

    data class Sim(val id: String, val title: String, val subject: String, val ageMin: Int) {
        /** PhET HTML5 实验的简体中文地址 */
        val url: String get() = "https://phet.colorado.edu/sims/html/$id/latest/${id}_zh_CN.html"
    }

    val PHET_DOMAINS = setOf("phet.colorado.edu")

    // 【未核实】以下每个实验的简体中文版是否都已上线，需在真机上逐个打开确认；打不开的从列表移除
    val PHET = listOf(
        Sim("make-a-ten", "凑十法", "数学", 6),
        Sim("arithmetic", "算术", "数学", 6),
        Sim("fractions-intro", "分数：入门", "数学", 8),
        Sim("area-builder", "面积构建", "数学", 8),
        Sim("number-line-integers", "数轴：整数", "数学", 10),
        Sim("graphing-lines", "直线作图", "数学", 12),
        Sim("balancing-act", "平衡", "物理", 9),
        Sim("forces-and-motion-basics", "力与运动：基础", "物理", 9),
        Sim("friction", "摩擦力", "物理", 9),
        Sim("density", "密度", "物理", 10),
        Sim("energy-skate-park-basics", "能量滑板公园：基础", "物理", 10),
        Sim("gravity-and-orbits", "重力和轨道", "物理", 10),
        Sim("wave-on-a-string", "绳波", "物理", 12),
        Sim("projectile-motion", "抛体运动", "物理", 12),
        Sim("circuit-construction-kit-dc", "电路实验：直流", "物理", 12),
        Sim("color-vision", "色觉", "物理", 9),
        Sim("states-of-matter-basics", "物质状态：基础", "化学", 10),
        Sim("build-an-atom", "构建原子", "化学", 12),
        Sim("ph-scale-basics", "pH 值：基础", "化学", 12),
        Sim("balancing-chemical-equations", "配平化学方程式", "化学", 13),
        Sim("molecule-shapes", "分子形状", "化学", 13),
    )

    /* ---------- StoryWeaver 绘本 ---------- */

    // 【未核实】授权条款（据了解为 CC BY 4.0）与简体中文书目的入口地址，见方案第 9 节待确认事项 4
    const val STORYWEAVER_URL = "https://storyweaver.org.in/zh/stories?language=Chinese%20(Simplified)"
    val STORYWEAVER_DOMAINS = setOf("storyweaver.org.in")
    const val STORYWEAVER_AGE_MIN = 3

    /* ---------- 推荐白名单网站（5.4，【未核实可用性】） ---------- */

    data class Site(val name: String, val url: String, val domain: String)

    val RECOMMENDED_SITES = listOf(
        Site("国家中小学智慧教育平台", "https://basic.smartedu.cn/", "smartedu.cn"),
        Site("央视网少儿频道", "https://tv.cctv.com/cctv14/", "cctv.com"),
        Site("PhET 中文版", "https://phet.colorado.edu/zh_CN/", "phet.colorado.edu"),
        Site("StoryWeaver 中文版", STORYWEAVER_URL, "storyweaver.org.in"),
    )

    /* ---------- 推荐白名单 app（5.3，【未核实】，家长自行安装后勾选） ---------- */

    data class RecommendedApp(val name: String, val ages: String, val note: String)

    val RECOMMENDED_APPS = listOf(
        RecommendedApp("国家中小学智慧教育平台", "6–18 岁", "全学科同步课程，官方免费"),
        RecommendedApp("央视频", "全年龄", "CCTV 少儿、科教、纪录频道"),
        RecommendedApp("中国教育电视台", "6–18 岁", "教育频道、空中课堂"),
        RecommendedApp("学习强国", "6 岁以上", "少儿、科普、传统文化"),
        RecommendedApp("云视听小电视", "9 岁以上", "B 站电视版，知识区科普"),
        RecommendedApp("宝宝巴士", "0–8 岁", "儿歌、动画、认知"),
        RecommendedApp("小伴龙", "2–8 岁", "儿歌、动画、早教"),
        RecommendedApp("洪恩系列", "3–8 岁", "识字、思维数学、英语启蒙"),
        RecommendedApp("凯叔讲故事", "3–12 岁", "故事音频"),
        RecommendedApp("纳米盒", "6–12 岁", "小学教材同步点读"),
        RecommendedApp("洋葱学园", "10–15 岁", "初中数理化动画讲解"),
        RecommendedApp("编程猫", "6–15 岁", "图形化编程"),
        RecommendedApp("GCompris", "2–10 岁", "开源教育活动合集（AGPL-3.0）"),
    )

    /* ---------- 素材授权说明（3.6.5） ---------- */

    val LICENSES = listOf(
        "PhET 互动实验：科罗拉多大学，CC BY-NC 4.0（仅限非商业使用）",
        "StoryWeaver 绘本：Pratham Books，【未核实】CC BY 4.0",
        "图标、图片：OpenMoji（CC BY-SA 4.0）、Twemoji（CC BY 4.0）",
        "音效：游戏内用 WebAudio 合成，不含第三方音频",
        "电视锁定的部分做法参考 PlanYourTV / Aerial（MIT 协议），版权归原作者",
    )
}
