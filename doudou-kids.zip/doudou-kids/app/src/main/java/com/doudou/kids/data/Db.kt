package com.doudou.kids.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import com.doudou.kids.core.Tier
import com.doudou.kids.core.TimeRule
import kotlinx.coroutines.flow.Flow

/* ---------- 实体 ---------- */

@Entity(tableName = "profile")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val age: Int,
    val dailyWeekdayMin: Int,
    val dailyWeekendMin: Int,
    val sessionMin: Int,
    val restMin: Int,
    val windowStartMin: Int,
    val windowEndMin: Int,
) {
    val tier: Tier get() = Tier.forAge(age)

    fun timeRule() = TimeRule(dailyWeekdayMin, dailyWeekendMin, sessionMin, restMin, windowStartMin, windowEndMin)

    fun withRule(r: TimeRule) = copy(
        dailyWeekdayMin = r.dailyWeekdayMin, dailyWeekendMin = r.dailyWeekendMin, sessionMin = r.sessionMin,
        restMin = r.restMin, windowStartMin = r.windowStartMin, windowEndMin = r.windowEndMin,
    )
}

@Entity(tableName = "whitelist_site")
data class WhitelistSiteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val name: String,
    val startUrl: String,
    /** 允许访问的域名，子域名也允许 */
    val domain: String,
)

@Entity(tableName = "video_source")
data class VideoSourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val url: String,
    val enabled: Boolean = true,
    val reviewMode: Boolean = false,
    /** 家长确认保留的分类名，换行分隔 */
    val allowedCategories: String = "",
    /** 源里出现过的全部分类名，换行分隔（给家长选择用） */
    val allCategories: String = "",
    val lastUpdated: Long = 0,
    val lastError: String? = null,
) {
    fun allowedSet(): Set<String> = allowedCategories.split('\n').filter { it.isNotBlank() }.toSet()
    fun allList(): List<String> = allCategories.split('\n').filter { it.isNotBlank() }
}

@Entity(
    tableName = "source_item",
    indices = [Index(value = ["sourceId", "itemKey"], unique = true)],
)
data class SourceItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceId: Long,
    val itemKey: String,
    val title: String,
    val cover: String,
    val type: String,
    val url: String,
    val category: String,
    val ageMin: Int?,
    val ageMax: Int?,
    val durationSec: Int?,
    val status: String,
    val failed: Boolean = false,
)

@Entity(tableName = "usage", primaryKeys = ["profileId", "day"])
data class UsageEntity(val profileId: Long, val day: String, val usedSec: Long)

@Entity(tableName = "game_progress", primaryKeys = ["profileId", "gameId"])
data class GameProgressEntity(val profileId: Long, val gameId: String, val json: String)

/* ---------- DAO ---------- */

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profile ORDER BY id")
    fun observeAll(): Flow<List<ProfileEntity>>

    @Query("SELECT * FROM profile ORDER BY id")
    suspend fun all(): List<ProfileEntity>

    @Query("SELECT * FROM profile WHERE id = :id")
    suspend fun get(id: Long): ProfileEntity?

    @Query("SELECT * FROM profile WHERE id = :id")
    fun observe(id: Long): Flow<ProfileEntity?>

    @Insert
    suspend fun insert(p: ProfileEntity): Long

    @Update
    suspend fun update(p: ProfileEntity)

    @Delete
    suspend fun delete(p: ProfileEntity)
}

@Dao
interface WhitelistDao {
    @Query("SELECT * FROM whitelist_site WHERE profileId = :profileId ORDER BY id")
    fun observeSites(profileId: Long): Flow<List<WhitelistSiteEntity>>

    @Insert
    suspend fun addSite(s: WhitelistSiteEntity): Long

    @Query("DELETE FROM whitelist_site WHERE id = :id")
    suspend fun removeSite(id: Long)

    @Query("DELETE FROM whitelist_site WHERE profileId = :profileId")
    suspend fun clearSites(profileId: Long)
}

@Dao
abstract class SourceDao {
    @Query("SELECT * FROM video_source ORDER BY id")
    abstract fun observeSources(): Flow<List<VideoSourceEntity>>

    @Query("SELECT * FROM video_source ORDER BY id")
    abstract suspend fun sources(): List<VideoSourceEntity>

    @Query("SELECT * FROM video_source WHERE id = :id")
    abstract suspend fun source(id: Long): VideoSourceEntity?

    @Insert
    abstract suspend fun insertSource(s: VideoSourceEntity): Long

    @Update
    abstract suspend fun updateSource(s: VideoSourceEntity)

    @Query("DELETE FROM video_source WHERE id = :id")
    protected abstract suspend fun deleteSourceRow(id: Long)

    @Query("DELETE FROM source_item WHERE sourceId = :sourceId")
    protected abstract suspend fun deleteItemsOf(sourceId: Long)

    @Transaction
    open suspend fun deleteSource(id: Long) {
        deleteItemsOf(id)
        deleteSourceRow(id)
    }

    @Query("SELECT * FROM source_item ORDER BY sourceId, id")
    abstract fun observeItems(): Flow<List<SourceItemEntity>>

    @Query("SELECT * FROM source_item WHERE sourceId = :sourceId")
    abstract suspend fun itemsOf(sourceId: Long): List<SourceItemEntity>

    @Query("SELECT * FROM source_item WHERE status = 'pending' ORDER BY sourceId, id")
    abstract fun observePending(): Flow<List<SourceItemEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    protected abstract suspend fun insertItems(items: List<SourceItemEntity>)

    @Update
    protected abstract suspend fun updateItems(items: List<SourceItemEntity>)

    @Query("DELETE FROM source_item WHERE id IN (:ids)")
    protected abstract suspend fun deleteItems(ids: List<Long>)

    @Query("UPDATE source_item SET status = :status WHERE id = :id")
    abstract suspend fun setStatus(id: Long, status: String)

    @Query("UPDATE source_item SET status = :status WHERE status = 'pending'")
    abstract suspend fun setAllPending(status: String)

    @Query("UPDATE source_item SET failed = 1 WHERE id = :id")
    abstract suspend fun markFailed(id: Long)

    /** 刷新一个源：新条目插入，已有条目更新内容但保留审核状态，消失的条目删除。 */
    @Transaction
    open suspend fun replaceItems(sourceId: Long, fresh: List<SourceItemEntity>) {
        val old = itemsOf(sourceId).associateBy { it.itemKey }
        val freshKeys = fresh.map { it.itemKey }.toSet()
        deleteItems(old.values.filter { it.itemKey !in freshKeys }.map { it.id })
        val (existing, added) = fresh.partition { it.itemKey in old }
        insertItems(added)
        updateItems(existing.map { f ->
            val o = old.getValue(f.itemKey)
            f.copy(id = o.id, status = o.status, failed = false)
        })
    }
}

@Dao
interface UsageDao {
    @Query("SELECT usedSec FROM usage WHERE profileId = :profileId AND day = :day")
    suspend fun used(profileId: Long, day: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(u: UsageEntity)
}

@Dao
interface GameProgressDao {
    // 游戏桥在 WebView 的 JavaBridge 线程调用，不在主线程，可以同步读写
    @Query("SELECT json FROM game_progress WHERE profileId = :profileId AND gameId = :gameId")
    fun get(profileId: Long, gameId: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun put(p: GameProgressEntity)
}

@Database(
    entities = [
        ProfileEntity::class, WhitelistSiteEntity::class,
        VideoSourceEntity::class, SourceItemEntity::class, UsageEntity::class, GameProgressEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profiles(): ProfileDao
    abstract fun whitelist(): WhitelistDao
    abstract fun sources(): SourceDao
    abstract fun usage(): UsageDao
    abstract fun progress(): GameProgressDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "doudou.db").build()
    }
}
