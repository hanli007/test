package com.doudou.kids.parent

import com.doudou.kids.core.PinHasher
import com.doudou.kids.core.PinLockout
import com.doudou.kids.data.Prefs

/** 家长密码：4–6 位数字，加盐哈希保存，连续输错按 PinLockout 规则锁定。 */
class ParentPin(private val prefs: Prefs) {
    val isSet: Boolean get() = prefs.pinHash != null

    fun set(pin: String) {
        require(isValid(pin))
        val salt = PinHasher.newSalt()
        prefs.pinSalt = salt
        prefs.pinHash = PinHasher.hash(pin, salt)
        prefs.lockout = PinLockout.onSuccess()
    }

    sealed interface Result {
        data object Ok : Result
        data class Wrong(val attemptsLeft: Int) : Result
        data class LockedOut(val untilMillis: Long) : Result
    }

    fun check(pin: String, now: Long = System.currentTimeMillis()): Result {
        val state = prefs.lockout
        if (PinLockout.isLocked(state, now)) return Result.LockedOut(state.lockedUntil)
        val ok = PinHasher.verify(pin, prefs.pinSalt ?: return Result.Wrong(0), prefs.pinHash ?: return Result.Wrong(0))
        if (ok) {
            prefs.lockout = PinLockout.onSuccess()
            return Result.Ok
        }
        val next = PinLockout.onFailure(state, now)
        prefs.lockout = next
        return if (PinLockout.isLocked(next, now)) Result.LockedOut(next.lockedUntil) else Result.Wrong(PinLockout.remainingAttempts(next))
    }

    /* ---------- 密保：忘记密码时回答问题重置（方案 3.1.4） ---------- */

    val securityQuestion: String? get() = prefs.securityQuestion

    fun setSecurity(question: String, answer: String) {
        val salt = PinHasher.newSalt()
        prefs.securityQuestion = question.trim()
        prefs.securityAnswerSalt = salt
        prefs.securityAnswerHash = PinHasher.hash(PinHasher.normalizeAnswer(answer), salt)
    }

    /** 回答密保问题，同样受输错锁定规则限制，免得孩子乱猜 */
    fun checkAnswer(answer: String, now: Long = System.currentTimeMillis()): Result {
        val state = prefs.lockout
        if (PinLockout.isLocked(state, now)) return Result.LockedOut(state.lockedUntil)
        val salt = prefs.securityAnswerSalt ?: return Result.Wrong(0)
        val hash = prefs.securityAnswerHash ?: return Result.Wrong(0)
        if (PinHasher.verify(PinHasher.normalizeAnswer(answer), salt, hash)) {
            prefs.lockout = PinLockout.onSuccess()
            return Result.Ok
        }
        val next = PinLockout.onFailure(state, now)
        prefs.lockout = next
        return if (PinLockout.isLocked(next, now)) Result.LockedOut(next.lockedUntil) else Result.Wrong(PinLockout.remainingAttempts(next))
    }

    companion object {
        fun isValid(pin: String) = pin.length in 4..6 && pin.all { it in '0'..'9' }

        val QUESTIONS = listOf(
            "孩子的小名是什么？",
            "您出生的城市是哪里？",
            "您的第一位老师姓什么？",
            "您最喜欢的一本书是什么？",
        )
    }
}
