package com.doudou.kids.core

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** 家长密码与密保答案的加盐哈希。不保存明文。 */
object PinHasher {
    private const val ITERATIONS = 10_000
    private const val KEY_BITS = 256

    fun newSalt(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return Hex.encode(b)
    }

    fun hash(secret: String, saltHex: String): String {
        // PBKDF2WithHmacSHA1 在所有 Android 版本都可用（SHA256 版本需要 Android 8.0+）
        val spec = PBEKeySpec(secret.toCharArray(), Hex.decode(saltHex), ITERATIONS, KEY_BITS)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return Hex.encode(key)
    }

    fun verify(secret: String, saltHex: String, expectedHex: String): Boolean =
        MessageDigest.isEqual(hash(secret, saltHex).toByteArray(), expectedHex.toByteArray())

    /** 密保答案比较时忽略首尾空格、大小写和中间空格。 */
    fun normalizeAnswer(answer: String): String = answer.trim().lowercase().replace(Regex("\\s+"), "")
}

/** 连续输错的锁定规则：5 次锁 1 分钟，之后每次加倍。 */
data class LockoutState(val fails: Int = 0, val lockouts: Int = 0, val lockedUntil: Long = 0)

object PinLockout {
    const val MAX_ATTEMPTS = 5
    const val BASE_LOCK_MS = 60_000L

    fun isLocked(s: LockoutState, now: Long) = now < s.lockedUntil

    fun remainingAttempts(s: LockoutState) = MAX_ATTEMPTS - s.fails

    fun onFailure(s: LockoutState, now: Long): LockoutState {
        val fails = s.fails + 1
        if (fails < MAX_ATTEMPTS) return s.copy(fails = fails)
        val lockouts = s.lockouts + 1
        val ms = BASE_LOCK_MS shl (lockouts - 1).coerceAtMost(10)
        return LockoutState(fails = 0, lockouts = lockouts, lockedUntil = now + ms)
    }

    fun onSuccess(): LockoutState = LockoutState()
}

object Hex {
    private const val DIGITS = "0123456789abcdef"

    fun encode(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) {
            val v = x.toInt() and 0xff
            sb.append(DIGITS[v ushr 4]).append(DIGITS[v and 0x0f])
        }
        return sb.toString()
    }

    fun decode(s: String): ByteArray {
        require(s.length % 2 == 0) { "hex length must be even" }
        return ByteArray(s.length / 2) { i ->
            ((Character.digit(s[2 * i], 16) shl 4) or Character.digit(s[2 * i + 1], 16)).toByte()
        }
    }
}
