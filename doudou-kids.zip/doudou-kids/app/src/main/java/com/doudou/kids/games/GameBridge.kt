package com.doudou.kids.games

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import com.doudou.kids.App
import com.doudou.kids.core.GameCatalog
import com.doudou.kids.core.GameEntry
import com.doudou.kids.data.GameProgressEntity
import org.json.JSONObject

/** 读取 assets/games 下各目录的 meta.json */
object GameRepository {
    @Volatile
    private var cache: List<GameEntry>? = null

    fun all(context: Context): List<GameEntry> = cache ?: load(context).also { cache = it }

    private fun load(context: Context): List<GameEntry> {
        val am = context.assets
        val dirs = am.list("games").orEmpty().filter { !it.startsWith("_") }.sorted()
        return dirs.flatMap { dir ->
            runCatching {
                val json = am.open("games/$dir/meta.json").bufferedReader().use { it.readText() }
                GameCatalog.parseMeta(dir, json)
            }.getOrDefault(emptyList())
        }
    }
}

/**
 * 注入到游戏页面的 window.KidsBridge，接口定义见 assets/games/_shared/kids-game.js 文件开头。
 * 参数和返回值都是字符串。这些方法在 WebView 的 JavaBridge 线程调用，不在主线程。
 * 类名和包名被 proguard-rules.pro 引用，改名时要一起改。
 */
class GameBridge(
    private val gameId: String,
    private val profileId: Long,
    private val profileJson: String,
    private val onExit: () -> Unit,
) {
    private val app get() = App.instance
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun getProfile(): String = profileJson

    @JavascriptInterface
    fun saveProgress(gameId: String, json: String) {
        // 只允许存当前游戏自己的进度
        val id = gameId.ifBlank { this.gameId }
        if (json.length > MAX_PROGRESS_CHARS) return
        app.db.progress().put(GameProgressEntity(profileId, id, json))
    }

    @JavascriptInterface
    fun loadProgress(gameId: String): String = app.db.progress().get(profileId, gameId.ifBlank { this.gameId }).orEmpty()

    @JavascriptInterface
    fun speak(zh: String, en: String) {
        app.speech.speak(zh, if (app.prefs.englishVoice) en else null)
    }

    @JavascriptInterface
    fun stopSpeak() = app.speech.stop()

    @JavascriptInterface
    fun exit() {
        main.post(onExit)
    }

    @JavascriptInterface
    fun log(msg: String) {
        Log.d("KidsGame", msg.take(500))
    }

    companion object {
        private const val MAX_PROGRESS_CHARS = 64 * 1024

        fun profileJson(name: String, tierCode: String, age: Int, isTv: Boolean, englishVoice: Boolean, sound: Boolean): String =
            JSONObject()
                .put("name", name)
                .put("ageTier", tierCode)
                .put("age", age)
                .put("input", if (isTv) "dpad" else "touch")
                .put("englishVoice", englishVoice)
                .put("sound", sound)
                .toString()
    }
}
