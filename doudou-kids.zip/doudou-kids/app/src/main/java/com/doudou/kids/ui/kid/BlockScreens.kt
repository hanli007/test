package com.doudou.kids.ui.kid

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doudou.kids.App
import com.doudou.kids.core.EyeCare
import com.doudou.kids.data.Prefs
import com.doudou.kids.ui.PinDialog
import com.doudou.kids.ui.minuteLabel
import kotlinx.coroutines.delay
import java.util.Calendar

@Composable
private fun BlockPage(bg: Color, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(bg).padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) { content() }
    }
}

private val EYE_TIPS = listOf(
    "看看窗外最远的地方，数到 20",
    "闭上眼睛，转一转眼珠：上、下、左、右",
    "站起来伸个懒腰，喝口水吧",
    "用力眨眨眼睛，眨 10 下",
)

/** 休息页：倒计时结束前不能跳过（方案 3.8） */
@Composable
fun RestScreen(isTv: Boolean) {
    val tracker = App.instance.tracker
    val totalMs = remember { tracker.restLeftMs().coerceAtLeast(1) }
    val left by produceState(tracker.restLeftMs()) {
        while (true) {
            value = tracker.restLeftMs()
            delay(500)
        }
    }
    val tip = remember { EYE_TIPS.random() }
    BlockPage(Color(0xFFE8F6EF)) {
        Text("😴", fontSize = 96.sp)
        Text("休息一下，让眼睛放松", fontSize = if (isTv) 36.sp else 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(tip, fontSize = if (isTv) 26.sp else 20.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        val sec = (left + 999) / 1000
        Text("%d:%02d".format(sec / 60, sec % 60), fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2A9E69))
        LinearProgressIndicator(
            progress = { 1f - left.toFloat() / totalMs },
            modifier = Modifier.fillMaxWidth(0.6f).padding(top = 12.dp),
        )
    }
}

/** 时间用完页：家长密码可延长 15/30/60 分钟（方案 3.7） */
@Composable
fun TimeUpScreen(isTv: Boolean) {
    val app = App.instance
    val day = Prefs.dayKey()
    var asking by remember { mutableStateOf<Int?>(null) }
    BlockPage(Color(0xFFFFF1E0)) {
        Text("🌙", fontSize = 96.sp)
        Text("今天的时间用完啦，明天见！", fontSize = if (isTv) 36.sp else 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text(
            "今天看了 ${app.prefs.stat(day, "videos")} 个视频，玩了 ${app.prefs.stat(day, "games")} 次游戏，读了 ${app.prefs.stat(day, "books")} 次绘本",
            fontSize = 18.sp, color = Color.DarkGray,
        )
        Spacer(Modifier.height(32.dp))
        Text("家长延长时间", color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp)) {
            for (m in listOf(15, 30, 60)) OutlinedButton(onClick = { asking = m }) { Text("+$m 分钟") }
        }
    }
    asking?.let { m ->
        PinDialog("家长密码", app.pin, onDismiss = { asking = null }) {
            asking = null
            app.tracker.extend(m)
        }
    }
}

/** 可用时段外的提示页；家长密码可允许今天继续使用 */
@Composable
fun OutOfWindowScreen(isTv: Boolean, startMin: Int, endMin: Int) {
    val app = App.instance
    var asking by remember { mutableStateOf(false) }
    BlockPage(Color(0xFFEDEBFA)) {
        Text("⏰", fontSize = 96.sp)
        Text("现在不是玩的时间哦", fontSize = if (isTv) 36.sp else 26.sp, fontWeight = FontWeight.Bold)
        Text("可以玩的时间：${minuteLabel(startMin)}–${minuteLabel(endMin)}", fontSize = 20.sp, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(32.dp))
        Button(onClick = { asking = true }) { Text("家长允许今天使用") }
    }
    if (asking) {
        PinDialog("家长密码", app.pin, onDismiss = { asking = false }) {
            asking = false
            app.tracker.allowOutOfWindowToday()
        }
    }
}

/** 距离太近：盖住内容，内容同时暂停 */
@Composable
fun TooCloseOverlay(isTv: Boolean) {
    BlockPage(Color(0xF2FFFFFF)) {
        Text("🙈", fontSize = 96.sp)
        Text("离屏幕太近啦，坐远一点吧", fontSize = if (isTv) 36.sp else 26.sp, fontWeight = FontWeight.Bold)
    }
}

/** 应用内护眼滤镜：半透明暖色层，不拦截点击 */
@Composable
fun EyeFilterLayer() {
    val prefs = App.instance.prefs
    // 每分钟重新判断一次是否到了夜间
    val minute by produceState(currentMinute()) {
        while (true) {
            delay(60_000)
            value = currentMinute()
        }
    }
    if (!EyeCare.filterOn(prefs.filterEnabled, prefs.filterNightAuto, minute)) return
    Box(Modifier.fillMaxSize().background(Color(0xFFFFAA3C).copy(alpha = EyeCare.filterAlpha(prefs.filterStrength))))
}

private fun currentMinute(): Int {
    val c = Calendar.getInstance()
    return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
}
