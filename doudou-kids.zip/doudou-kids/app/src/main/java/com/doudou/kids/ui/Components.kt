@file:OptIn(ExperimentalFoundationApi::class)

package com.doudou.kids.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.doudou.kids.parent.ParentPin
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/* ---------- 颜色 ---------- */

fun hexColor(hex: String, fallback: Color = Color(0xFFFF9F43)): Color =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(fallback)

/** 首页大卡片的配色（与原型 c1–c5 一致），少年版用更沉稳的颜色 */
fun tileColor(index: Int, mature: Boolean): Color {
    val kid = listOf(0xFF4AA3EE, 0xFFFF9F43, 0xFF3FBF84, 0xFFA27FE6, 0xFFF2678A, 0xFF5BC0EB)
    val teen = listOf(0xFF35558A, 0xFF2E7564, 0xFF5B4D8F, 0xFF3D4A60, 0xFF7A4A5E, 0xFF44627A)
    return Color((if (mature) teen else kid)[index % 6])
}

/* ---------- 可聚焦卡片：电视上焦点放大 + 高亮边框（方案 4.3） ---------- */

@Composable
fun FocusCard(
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    shape: RoundedCornerShape = RoundedCornerShape(20.dp),
    focusRequester: FocusRequester? = null,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(if (focused) 1.06f else 1f, label = "focus")
    Column(
        modifier
            .let { if (focusRequester != null) it.focusRequester(focusRequester) else it }
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(color)
            .border(if (focused) BorderStroke(4.dp, Color.White) else BorderStroke(0.dp, Color.Transparent), shape)
            .combinedClickable(interactionSource = source, indication = null, onLongClick = onLongClick, onClick = onClick),
        content = content,
    )
}

/** 带渐变底色的大入口（首页的「看动画」「玩游戏」…） */
@Composable
fun BigTile(
    label: String,
    emoji: String,
    color: Color,
    modifier: Modifier = Modifier,
    height: Dp = 160.dp,
    fontSize: Int = 24,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit,
) {
    FocusCard(
        modifier = modifier.height(height),
        color = Color.Transparent,
        shape = RoundedCornerShape(28.dp),
        focusRequester = focusRequester,
        onClick = onClick,
    ) {
        Box(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(color, color.copy(alpha = 0.78f)))),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(emoji, fontSize = (fontSize * 1.8).sp)
                Text(label, color = Color.White, fontSize = fontSize.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** 内容卡片：封面色块 + 标题 + 副标题 */
@Composable
fun ContentCard(
    title: String,
    subtitle: String,
    color: Color,
    emoji: String,
    width: Dp,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    FocusCard(modifier = modifier.width(width), onLongClick = onLongClick, onClick = onClick) {
        Box(
            Modifier.fillMaxWidth().height(width * 0.62f).background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.7f)))),
            contentAlignment = Alignment.Center,
        ) { Text(emoji, fontSize = 40.sp) }
        Column(Modifier.padding(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotEmpty()) Text(subtitle, fontSize = 12.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/* ---------- 页面骨架 ---------- */

@Composable
fun ScreenScaffold(
    title: String,
    isTv: Boolean,
    onBack: (() -> Unit)?,
    trailing: @Composable () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .padding(horizontal = if (isTv) 48.dp else 16.dp, vertical = if (isTv) 24.dp else 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
            if (onBack != null) {
                OutlinedButton(onClick = onBack) { Text("‹ 返回") }
                Spacer(Modifier.width(12.dp))
            }
            Text(title, fontSize = if (isTv) 30.sp else 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            trailing()
        }
        content()
    }
}

/** 右上角剩余时间 */
@Composable
fun TimePill(remainingSec: Long, warn: Boolean) {
    val min = (remainingSec + 59) / 60
    Surface(shape = RoundedCornerShape(50), color = if (warn) Color(0xFFFFE1D2) else Color(0x22000000)) {
        Text(
            "⏱ 还剩 $min 分钟",
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            color = if (warn) Color(0xFFD9534F) else Color.DarkGray,
        )
    }
}

@Composable
fun SectionTitle(text: String, sub: String = "", isTv: Boolean = false) {
    Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp)) {
        Text(text, fontSize = if (isTv) 24.sp else 18.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text("  $sub", fontSize = 13.sp, color = Color.Gray)
    }
}

/* ---------- 设置项（遥控器也能操作：不用滑块，用 −/+ 步进） ---------- */

@Composable
fun Stepper(label: String, value: Int, range: IntRange, step: Int = 1, format: (Int) -> String = { it.toString() }, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = { onChange((value - step).coerceIn(range)) }) { Text("−") }
        Text(format(value), modifier = Modifier.width(110.dp), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        OutlinedButton(onClick = { onChange((value + step).coerceIn(range)) }) { Text("+") }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, hint: String = "", onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label)
            if (hint.isNotEmpty()) Text(hint, fontSize = 12.sp, color = Color.Gray)
        }
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
fun MenuRow(label: String, hint: String = "", onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick)
            .background(Color.White).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 17.sp)
            if (hint.isNotEmpty()) Text(hint, fontSize = 12.sp, color = Color.Gray)
        }
        Text("›", fontSize = 22.sp, color = Color.Gray)
    }
}

fun minuteLabel(m: Int): String = "%02d:%02d".format(m / 60, m % 60)

/* ---------- 数字键盘与家长密码 ---------- */

@Composable
fun PinPad(entered: Int, onDigit: (Char) -> Unit, onClear: () -> Unit, onOk: () -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(6) { i ->
                Box(
                    Modifier.size(14.dp).background(
                        if (i < entered) MaterialTheme.colorScheme.primary else Color(0x22000000),
                        CircleShape,
                    ),
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        for (row in listOf("123", "456", "789", "C0✓")) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 5.dp)) {
                for (ch in row) {
                    val m = Modifier.size(width = 72.dp, height = 56.dp).let { if (ch == '1') it.focusRequester(first) else it }
                    Button(
                        onClick = {
                            when (ch) {
                                'C' -> onClear()
                                '✓' -> onOk()
                                else -> onDigit(ch)
                            }
                        },
                        modifier = m,
                        contentPadding = PaddingValues(0.dp),
                    ) { Text(if (ch == 'C') "清除" else ch.toString(), fontSize = 20.sp) }
                }
            }
        }
    }
}

fun lockoutMessage(r: ParentPin.Result.LockedOut): String =
    "输错太多次，请在 ${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(r.untilMillis))} 后再试"

/**
 * 家长密码弹窗。设置过密保时提供「忘记密码」：回答正确后重新设置密码。
 */
@Composable
fun PinDialog(title: String, pin: ParentPin, onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var forgot by remember { mutableStateOf(false) }
    var resetting by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    resetting -> {
                        Text("设置新的家长密码", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        NewPinFlow(onDone = { pin.set(it); onSuccess() })
                    }
                    forgot -> {
                        var answer by remember { mutableStateOf("") }
                        Text(pin.securityQuestion ?: "", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(value = answer, onValueChange = { answer = it }, singleLine = true, label = { Text("答案") })
                        Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 6.dp))
                        Button(onClick = {
                            when (val r = pin.checkAnswer(answer)) {
                                ParentPin.Result.Ok -> resetting = true
                                is ParentPin.Result.Wrong -> msg = "答案不对，还能试 ${r.attemptsLeft} 次"
                                is ParentPin.Result.LockedOut -> msg = lockoutMessage(r)
                            }
                        }) { Text("确定") }
                    }
                    else -> {
                        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 6.dp))
                        PinPad(
                            entered = input.length,
                            onDigit = { if (input.length < 6) input += it },
                            onClear = { input = "" },
                            onOk = {
                                when (val r = pin.check(input)) {
                                    ParentPin.Result.Ok -> onSuccess()
                                    is ParentPin.Result.Wrong -> msg = "密码不对，还能试 ${r.attemptsLeft} 次"
                                    is ParentPin.Result.LockedOut -> msg = lockoutMessage(r)
                                }
                                input = ""
                            },
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (!forgot && pin.securityQuestion != null) {
                        OutlinedButton(onClick = { forgot = true; msg = "" }) { Text("忘记密码") }
                    }
                    OutlinedButton(onClick = onDismiss) { Text("取消") }
                }
            }
        }
    }
}

/** 输入两次新密码 */
@Composable
fun NewPinFlow(onDone: (String) -> Unit) {
    var first by remember { mutableStateOf<String?>(null) }
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Text(if (first == null) "输入 4–6 位数字" else "再输入一次", modifier = Modifier.padding(top = 6.dp))
    Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 4.dp))
    PinPad(
        entered = input.length,
        onDigit = { if (input.length < 6) input += it },
        onClear = { input = "" },
        onOk = {
            val f = first
            when {
                !ParentPin.isValid(input) -> msg = "请输入 4–6 位数字"
                f == null -> { first = input; input = ""; msg = "" }
                f == input -> onDone(input)
                else -> { first = null; input = ""; msg = "两次输入不一致，请重新输入" }
            }
        },
    )
}
