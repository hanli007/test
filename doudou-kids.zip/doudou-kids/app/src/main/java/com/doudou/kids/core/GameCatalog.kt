package com.doudou.kids.core

import org.json.JSONObject

/** 一个游戏入口，来自 assets/games/<目录>/meta.json（一个目录可以有多个入口，比如拖拽游戏的 17 套关卡）。 */
data class GameEntry(
    val id: String,
    val dir: String,
    val title: String,
    val desc: String,
    val ageMin: Int,
    val ageMax: Int,
    val touch: Boolean,
    val dpad: Boolean,
    /** 相对目录的入口，可带查询参数，例如 index.html?set=train */
    val entry: String,
    val color: String,
    val icon: String,
) {
    /** WebViewAssetLoader 下的地址 */
    val url: String get() = "https://appassets.androidplatform.net/assets/games/$dir/$entry"
}

object GameCatalog {
    fun parseMeta(dir: String, json: String): List<GameEntry> {
        val arr = JSONObject(json).optJSONArray("games") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val input = o.optJSONArray("input")
            val inputs = if (input == null) emptyList() else List(input.length()) { input.optString(it) }
            GameEntry(
                id = o.optString("id").ifBlank { return@mapNotNull null },
                dir = dir,
                title = o.optString("title"),
                desc = o.optString("desc"),
                ageMin = o.optInt("ageMin", 0),
                ageMax = o.optInt("ageMax", 15),
                touch = "touch" in inputs,
                dpad = "dpad" in inputs,
                entry = o.optString("entry", "index.html"),
                color = o.optString("color", "#FF9F43"),
                icon = o.optString("icon"),
            )
        }
    }

    /**
     * 孩子能看到的游戏：年龄在范围内；电视上隐藏不支持遥控器的游戏（拖拽类只在手机/平板提供，方案 3.6.2）。
     */
    fun visible(all: List<GameEntry>, age: Int, isTv: Boolean): List<GameEntry> =
        all.filter { age in it.ageMin..it.ageMax && (if (isTv) it.dpad else it.touch) }
}

/** 受限网页（绘本、实验、白名单网站）的域名放行规则。 */
object UrlRules {
    /** 主机名等于某个域名或是它的子域名才放行。只允许 http/https。 */
    fun allowed(url: String, domains: Collection<String>): Boolean {
        val host = hostOf(url) ?: return false
        return domains.any { d ->
            val dd = d.trim().lowercase().removePrefix(".")
            dd.isNotEmpty() && (host == dd || host.endsWith(".$dd"))
        }
    }

    fun hostOf(url: String): String? {
        val m = Regex("^(https?)://([^/?#:@]+)(:\\d+)?([/?#].*)?$", RegexOption.IGNORE_CASE).find(url.trim()) ?: return null
        return m.groupValues[2].lowercase()
    }

    /** 家长输入的网站可能不带协议或带路径，取出域名部分。 */
    fun domainFromInput(input: String): String? {
        val t = input.trim()
        if (t.isEmpty()) return null
        return hostOf(if (t.contains("://")) t else "https://$t")?.removePrefix("www.")
    }
}
