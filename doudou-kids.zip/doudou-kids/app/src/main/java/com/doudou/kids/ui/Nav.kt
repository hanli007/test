package com.doudou.kids.ui

import androidx.compose.runtime.mutableStateListOf
import com.doudou.kids.core.GameEntry
import com.doudou.kids.data.SourceItemEntity

/** 页面。孩子端和家长端各自一个返回栈。 */
sealed interface Route {
    /* 孩子端 */
    data object ProfilePicker : Route
    data object KidHome : Route
    data object Videos : Route
    data object Games : Route
    data object Labs : Route
    data object Sites : Route
    data object Apps : Route
    data class Game(val entry: GameEntry) : Route
    data class Player(val item: SourceItemEntity) : Route
    /** 受限网页：绘本、实验、白名单网站、视频源里的网页条目 */
    data class Web(val title: String, val url: String, val domains: Set<String>, val stat: String) : Route

    /* 家长端 */
    data object ParentHome : Route
    data class Parent(val page: ParentPage) : Route
}

enum class ParentPage(val title: String) {
    PROFILES("孩子档案与时间规则"),
    EYE("护眼"),
    VOICE("语音"),
    APPS("白名单 app"),
    SITES("白名单网站"),
    SOURCES("视频源"),
    REVIEW("待审核内容"),
    LOCK("权限与锁定"),
    RECOMMENDED("推荐白名单 app"),
    CHANGE_PIN("修改密码"),
    ACTIVATION("激活信息"),
    LICENSES("素材授权说明"),
}

class Navigator(root: Route) {
    val stack = mutableStateListOf(root)
    val current: Route get() = stack.last()

    fun push(r: Route) {
        stack.add(r)
    }

    /** 返回上一页；已经在根页面时返回 false */
    fun pop(): Boolean {
        if (stack.size <= 1) return false
        stack.removeAt(stack.lastIndex)
        return true
    }

    fun reset(root: Route) {
        stack.clear()
        stack.add(root)
    }
}
