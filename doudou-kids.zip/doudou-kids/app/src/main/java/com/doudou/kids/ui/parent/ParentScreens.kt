@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.doudou.kids.ui.parent

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doudou.kids.App
import com.doudou.kids.BuildConfig
import com.doudou.kids.content.BuiltinContent
import com.doudou.kids.core.ItemStatus
import com.doudou.kids.core.TimeDefaults
import com.doudou.kids.core.UrlRules
import com.doudou.kids.data.ProfileEntity
import com.doudou.kids.data.VideoSourceEntity
import com.doudou.kids.data.WhitelistSiteEntity
import com.doudou.kids.lock.LockManager
import com.doudou.kids.parent.ParentPin
import com.doudou.kids.ui.MenuRow
import com.doudou.kids.ui.Navigator
import com.doudou.kids.ui.NewPinFlow
import com.doudou.kids.ui.ParentPage
import com.doudou.kids.ui.Route
import com.doudou.kids.ui.ScreenScaffold
import com.doudou.kids.ui.SectionTitle
import com.doudou.kids.ui.Stepper
import com.doudou.kids.ui.SwitchRow
import com.doudou.kids.ui.minuteLabel
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

/* ---------- 激活（方案 3.10） ---------- */

@Composable
fun ActivationScreen(isTv: Boolean, onDone: () -> Unit) {
    val a = App.instance.activation
    var code by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("激活豆豆乐园", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("把下面的设备码发给作者，换取激活码：")
        Text(a.deviceCode, fontSize = if (isTv) 44.sp else 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = code, onValueChange = { code = it.uppercase().take(19) }, singleLine = true,
            label = { Text("激活码 XXXX-XXXX-XXXX-XXXX") }, modifier = Modifier.widthIn(max = 420.dp),
        )
        Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 6.dp))
        Button(onClick = { if (a.activate(code)) onDone() else msg = "激活码不对，请检查后重新输入（不区分大小写，O 和 0 都行）" }) { Text("激活") }
    }
}

/* ---------- 首次设置向导（方案 2.2） ---------- */

@Composable
fun SetupWizard(isTv: Boolean, onDone: () -> Unit) {
    val app = App.instance
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(if (app.pin.isSet) 1 else 0) }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("欢迎使用豆豆乐园（第 ${step + 1}/3 步）", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        when (step) {
            0 -> {
                Text("设置家长密码（4–6 位数字，方便遥控器输入）", fontSize = 18.sp)
                NewPinFlow(onDone = { app.pin.set(it); step = 1 })
            }
            1 -> SecurityForm(onSaved = { step = 2 })
            else -> ProfileForm(initial = null, isTv = isTv, onSave = { p ->
                scope.launch {
                    val id = app.db.profiles().insert(p)
                    app.prefs.currentProfileId = id
                    app.prefs.setupDone = true
                    onDone()
                }
            })
        }
    }
}

/** 密保问题：忘记密码时回答问题重置 */
@Composable
fun SecurityForm(onSaved: () -> Unit) {
    val pin = App.instance.pin
    var q by remember { mutableStateOf(pin.securityQuestion ?: ParentPin.QUESTIONS[0]) }
    var answer by remember { mutableStateOf("") }
    Column(Modifier.widthIn(max = 520.dp)) {
        Text("设置密保问题（忘记密码时用）", fontSize = 18.sp)
        ParentPin.QUESTIONS.forEach { item ->
            Row(Modifier.fillMaxWidth().clickable { q = item }, verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.RadioButton(selected = q == item, onClick = null)
                Text(item)
            }
        }
        OutlinedTextField(value = answer, onValueChange = { answer = it }, singleLine = true, label = { Text("答案") }, modifier = Modifier.fillMaxWidth())
        Button(
            enabled = answer.isNotBlank(),
            onClick = { pin.setSecurity(q, answer); onSaved() },
            modifier = Modifier.padding(top = 12.dp),
        ) { Text("保存") }
    }
}

/** 档案：昵称、年龄、时间规则。新建时按年龄填默认时间规则（方案 3.7） */
@Composable
fun ProfileForm(initial: ProfileEntity?, isTv: Boolean, onSave: (ProfileEntity) -> Unit, onDelete: (() -> Unit)? = null) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var age by remember { mutableIntStateOf(initial?.age ?: 5) }
    val base = initial?.timeRule() ?: TimeDefaults.forAge(age)
    var weekday by remember { mutableIntStateOf(base.dailyWeekdayMin) }
    var weekend by remember { mutableIntStateOf(base.dailyWeekendMin) }
    var session by remember { mutableIntStateOf(base.sessionMin) }
    var rest by remember { mutableIntStateOf(base.restMin) }
    var start by remember { mutableIntStateOf(base.windowStartMin) }
    var end by remember { mutableIntStateOf(base.windowEndMin) }
    Column(Modifier.widthIn(max = 640.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it.take(12) }, singleLine = true, label = { Text("昵称") }, modifier = Modifier.fillMaxWidth())
        Stepper("年龄", age, 0..15, format = { "$it 岁" }) {
            age = it
            if (initial == null) {
                // 新建档案时，年龄变了就跟着换默认时长
                val d = TimeDefaults.forAge(it)
                weekday = d.dailyWeekdayMin; weekend = d.dailyWeekendMin; session = d.sessionMin
            }
        }
        if (age < 2) Text("世卫组织建议 2 岁以下尽量不看屏幕", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
        SectionTitle("时间规则", "", isTv)
        Stepper("工作日每天", weekday, 5..240, 5, { "$it 分钟" }) { weekday = it }
        Stepper("周末每天", weekend, 5..300, 5, { "$it 分钟" }) { weekend = it }
        Stepper("单次连续", session, 0..120, 5, { if (it == 0) "不限" else "$it 分钟" }) { session = it }
        Stepper("每次休息", rest, 1..30, 1, { "$it 分钟" }) { rest = it }
        Stepper("可用时段开始", start, 0..1410, 30, ::minuteLabel) { start = it }
        Stepper("可用时段结束", end, 0..1410, 30, ::minuteLabel) { end = it }
        Text("开始和结束相同表示全天可用", fontSize = 12.sp, color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 12.dp)) {
            Button(enabled = name.isNotBlank(), onClick = {
                val p = (initial ?: ProfileEntity(
                    name = name, age = age, dailyWeekdayMin = 0, dailyWeekendMin = 0, sessionMin = 0, restMin = 0,
                    windowStartMin = 0, windowEndMin = 0,
                )).copy(
                    name = name.trim(), age = age, dailyWeekdayMin = weekday, dailyWeekendMin = weekend,
                    sessionMin = session, restMin = rest, windowStartMin = start, windowEndMin = end,
                )
                onSave(p)
            }) { Text("保存") }
            if (onDelete != null) OutlinedButton(onClick = onDelete) { Text("删除档案") }
        }
    }
}

/* ---------- 家长设置首页（方案 3.9） ---------- */

@Composable
fun ParentHome(activity: Activity, isTv: Boolean, nav: Navigator) {
    val app = App.instance
    val pending by app.sources.observePending().collectAsState(initial = emptyList())
    ScreenScaffold("家长设置", isTv, onBack = null) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Button(onClick = { tryLock(activity) }, modifier = Modifier.fillMaxWidth().height(64.dp)) {
                    Text("锁定并进入孩子模式", fontSize = 20.sp)
                }
                val missing = LockManager.missingRequired(activity)
                if (missing.isNotEmpty()) {
                    Text("锁定前还需要开启：${missing.joinToString("、")}（在「权限与锁定」里）", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                }
            }
            items(ParentPage.entries.toList()) { page ->
                val hint = when (page) {
                    ParentPage.REVIEW -> if (pending.isEmpty()) "没有待审核的内容" else "${pending.size} 条待审核"
                    ParentPage.LOCK -> "默认桌面、无障碍、悬浮窗、防卸载"
                    ParentPage.ACTIVATION -> if (app.activation.required) "设备码 ${app.activation.deviceCode}" else "调试包不需要激活"
                    else -> ""
                }
                MenuRow(page.title, hint) { nav.push(Route.Parent(page)) }
            }
            item { Text("版本 ${BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 12.dp)) }
        }
    }
}

@Composable
fun ParentPageScreen(page: ParentPage, activity: Activity, isTv: Boolean, resumeTick: Int, nav: Navigator, requestCamera: () -> Unit) {
    ScreenScaffold(page.title, isTv, onBack = { nav.pop() }) {
        when (page) {
            ParentPage.PROFILES -> ProfilesPage(isTv)
            ParentPage.EYE -> EyePage(requestCamera)
            ParentPage.VOICE -> VoicePage()
            ParentPage.APPS -> AppsPage()
            ParentPage.SITES -> SitesPage()
            ParentPage.SOURCES -> SourcesPage(nav)
            ParentPage.REVIEW -> ReviewPage()
            ParentPage.LOCK -> LockPage(activity, isTv, resumeTick)
            ParentPage.RECOMMENDED -> TextList(
                listOf("以下应用由家长自行安装，装好后在「白名单 app」里勾选。【清单未核实】") +
                    BuiltinContent.RECOMMENDED_APPS.map { "${it.name}（${it.ages}）：${it.note}" },
            )
            ParentPage.CHANGE_PIN -> ChangePinPage(onDone = { nav.pop() })
            ParentPage.ACTIVATION -> ActivationInfo()
            ParentPage.LICENSES -> TextList(BuiltinContent.LICENSES)
        }
    }
}

@Composable
private fun TextList(lines: List<String>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(lines) { Text(it) } }
}

/* ---------- 档案 ---------- */

@Composable
private fun ProfilesPage(isTv: Boolean) {
    val app = App.instance
    val scope = rememberCoroutineScope()
    val profiles by app.db.profiles().observeAll().collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf<ProfileEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    val cur = editing
    when {
        adding -> Column(Modifier.verticalScroll(rememberScrollState())) {
            ProfileForm(null, isTv, onSave = { p -> scope.launch { app.db.profiles().insert(p); adding = false } })
            OutlinedButton(onClick = { adding = false }) { Text("取消") }
        }
        cur != null -> Column(Modifier.verticalScroll(rememberScrollState())) {
            ProfileForm(
                cur, isTv,
                onSave = { p -> scope.launch { app.db.profiles().update(p); editing = null } },
                onDelete = if (profiles.size > 1) ({ scope.launch { app.db.profiles().delete(cur); editing = null } }) else null,
            )
            OutlinedButton(onClick = { editing = null }) { Text("取消") }
        }
        else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(profiles, key = { it.id }) { p ->
                MenuRow("${p.name}（${p.age} 岁，${p.tier.label}）", "工作日 ${p.dailyWeekdayMin} 分钟 · 周末 ${p.dailyWeekendMin} 分钟 · 单次 ${p.sessionMin} 分钟") { editing = p }
            }
            item { OutlinedButton(onClick = { adding = true }) { Text("+ 添加孩子") } }
        }
    }
}

/* ---------- 护眼、语音 ---------- */

@Composable
private fun EyePage(requestCamera: () -> Unit) {
    val prefs = App.instance.prefs
    var rest by remember { mutableStateOf(prefs.restEnabled) }
    var filter by remember { mutableStateOf(prefs.filterEnabled) }
    var night by remember { mutableStateOf(prefs.filterNightAuto) }
    var strength by remember { mutableIntStateOf(prefs.filterStrength) }
    var distance by remember { mutableStateOf(prefs.distanceEnabled) }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        SwitchRow("定时休息", rest, "连续使用到「单次连续」时长后全屏休息，倒计时结束前不能跳过") { rest = it; prefs.restEnabled = it }
        SwitchRow("护眼滤镜", filter, "叠加半透明暖色层；锁定时在白名单 app 里同样生效") {
            filter = it; prefs.filterEnabled = it; LockManager.setAppResumed(LockManager.appResumed.value)
        }
        SwitchRow("夜间自动开启滤镜", night, "20:00 到次日 7:00") { night = it; prefs.filterNightAuto = it }
        Stepper("滤镜强度", strength, 0..80, 10, { "$it%" }) { strength = it; prefs.filterStrength = it }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        SwitchRow(
            "距离提醒", distance,
            "用前置摄像头判断是否离屏幕太近，所有处理在本机完成，不保存、不上传任何图像。只在豆豆乐园处于前台时运行。电视大多没有摄像头",
        ) {
            distance = it
            prefs.distanceEnabled = it
            if (it) requestCamera()
        }
    }
}

@Composable
private fun VoicePage() {
    val app = App.instance
    var en by remember { mutableStateOf(app.prefs.englishVoice) }
    var sound by remember { mutableStateOf(app.prefs.soundEnabled) }
    Column {
        SwitchRow("英文读音", en, "关闭后游戏只读中文") { en = it; app.prefs.englishVoice = it }
        SwitchRow("游戏音效", sound) { sound = it; app.prefs.soundEnabled = it }
        OutlinedButton(onClick = { app.speech.speak("红色", if (en) "red" else null) }, modifier = Modifier.padding(top = 12.dp)) {
            Text("试听系统语音")
        }
        Text("很多国产设备没有英文离线语音引擎，试听没有英文时可以在系统设置里安装语音数据。", fontSize = 12.sp, color = Color.Gray)
    }
}

/* ---------- 白名单网站（方案 3.3） ---------- */

@Composable
private fun SitesPage() {
    val app = App.instance
    val scope = rememberCoroutineScope()
    val profiles by app.db.profiles().observeAll().collectAsState(initial = emptyList())
    var pid by remember { mutableStateOf(app.prefs.currentProfileId) }
    val selected = profiles.firstOrNull { it.id == pid } ?: profiles.firstOrNull()
    val sitesFlow = remember(selected?.id) { selected?.let { app.db.whitelist().observeSites(it.id) } ?: flowOf(emptyList()) }
    val sites by sitesFlow.collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    fun add(n: String, u: String, domain: String?) {
        val p = selected ?: return
        val d = domain ?: UrlRules.domainFromInput(u)
        if (d == null) {
            Toast.makeText(ctx, "网址不对", Toast.LENGTH_SHORT).show()
            return
        }
        val start = if (u.contains("://")) u.trim() else "https://${u.trim()}"
        scope.launch { app.db.whitelist().addSite(WhitelistSiteEntity(profileId = p.id, name = n.ifBlank { d }, startUrl = start, domain = d)) }
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                profiles.forEach { p -> FilterChip(selected = p.id == selected?.id, onClick = { pid = p.id }, label = { Text(p.name) }) }
            }
            Text("只允许访问这些网站的域名（含子域名），点到外部链接会被拦截。电视上用方向键移动光标点击。", fontSize = 13.sp, color = Color.Gray)
        }
        items(sites, key = { it.id }) { s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(s.name); Text(s.domain, fontSize = 12.sp, color = Color.Gray) }
                OutlinedButton(onClick = { scope.launch { app.db.whitelist().removeSite(s.id) } }) { Text("删除") }
            }
        }
        item { SectionTitle("推荐网站", "【未核实可用性】") }
        items(BuiltinContent.RECOMMENDED_SITES.filter { r -> sites.none { it.domain == r.domain } }) { r ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(r.name, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { add(r.name, r.url, r.domain) }) { Text("添加") }
            }
        }
        item {
            SectionTitle("自己添加")
            OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("名称") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = url, onValueChange = { url = it }, singleLine = true, label = { Text("网址") }, modifier = Modifier.fillMaxWidth())
            Button(enabled = url.isNotBlank(), onClick = { add(name, url, null); name = ""; url = "" }, modifier = Modifier.padding(top = 8.dp)) { Text("添加") }
        }
    }
}

/* ---------- 视频源（方案 3.4） ---------- */

@Composable
private fun SourcesPage(nav: Navigator) {
    val app = App.instance
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val sources by app.sources.observeSources().collectAsState(initial = emptyList())
    var url by remember { mutableStateOf("") }
    var review by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf<Long?>(null) }
    var blacklist by remember { mutableStateOf(app.prefs.keywordBlacklist.joinToString("、")) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(
                "只添加合法来源。豆豆乐园不提供、不内置影视资源站或 TVBox 接口。过滤只看标题和分类，识别不了画面内容。",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.error,
            )
        }
        items(sources, key = { it.id }) { s -> SourceCard(s, expanded == s.id, onToggle = { expanded = if (expanded == s.id) null else s.id }) }
        item {
            SectionTitle("添加源", "JSON 或 M3U 地址")
            OutlinedTextField(value = url, onValueChange = { url = it }, singleLine = true, label = { Text("https://…") }, modifier = Modifier.fillMaxWidth())
            SwitchRow("审核模式", review, "新内容先隐藏，家长放行后才显示（建议 0–6 岁开启）") { review = it }
            Button(enabled = !busy && url.startsWith("http"), onClick = {
                busy = true
                scope.launch {
                    val r = runCatching { app.sources.add(url.trim(), review) }
                    busy = false
                    Toast.makeText(ctx, r.fold({ "已添加，请确认保留哪些分类" }, { "添加失败：${it.message}" }), Toast.LENGTH_LONG).show()
                    r.onSuccess { expanded = it; url = "" }
                }
            }) { Text(if (busy) "正在读取…" else "添加") }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { scope.launch { app.sources.refreshAll() } }) { Text("全部刷新") }
                OutlinedButton(onClick = { nav.push(Route.Parent(ParentPage.REVIEW)) }) { Text("待审核内容") }
            }
        }
        item {
            SectionTitle("关键词黑名单", "标题含这些词的直接排除，用顿号分隔")
            OutlinedTextField(value = blacklist, onValueChange = { blacklist = it }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                app.prefs.keywordBlacklist = blacklist.split('、', ',', '，', ' ', '\n').map { it.trim() }.filter { it.isNotEmpty() }
                Toast.makeText(ctx, "已保存", Toast.LENGTH_SHORT).show()
            }) { Text("保存黑名单") }
        }
    }
}

@Composable
private fun SourceCard(s: VideoSourceEntity, expanded: Boolean, onToggle: () -> Unit) {
    val app = App.instance
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Row(Modifier.clickable(onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.name, fontWeight = FontWeight.Bold)
                Text(s.url, fontSize = 12.sp, color = Color.Gray, maxLines = 1)
                s.lastError?.let { Text("上次刷新失败：$it", fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
            }
            Text(if (expanded) "收起" else "设置")
        }
        if (!expanded) return@Column
        SwitchRow("启用", s.enabled) { v -> scope.launch { app.sources.update(s.copy(enabled = v)) } }
        SwitchRow("审核模式", s.reviewMode) { v -> scope.launch { app.sources.update(s.copy(reviewMode = v)) } }
        Text("保留的分类（过滤第 1 层）", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        val allowed = s.allowedSet()
        s.allList().forEach { cat ->
            Row(
                Modifier.fillMaxWidth().clickable {
                    val next = if (cat in allowed) allowed - cat else allowed + cat
                    scope.launch { app.sources.update(s.copy(allowedCategories = next.joinToString("\n"))) }
                },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(checked = cat in allowed, onCheckedChange = null)
                Text(cat)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp)) {
            OutlinedButton(onClick = { scope.launch { app.sources.refresh(s) } }) { Text("刷新") }
            OutlinedButton(onClick = { scope.launch { app.sources.delete(s.id) } }) { Text("删除源") }
        }
    }
}

@Composable
private fun ReviewPage() {
    val app = App.instance
    val scope = rememberCoroutineScope()
    val pending by app.sources.observePending().collectAsState(initial = emptyList())
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (pending.isEmpty()) item { Text("没有待审核的内容") }
        else item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { scope.launch { app.sources.approveAllPending(ItemStatus.APPROVED) } }) { Text("全部放行") }
                OutlinedButton(onClick = { scope.launch { app.sources.approveAllPending(ItemStatus.BLOCKED) } }) { Text("全部屏蔽") }
            }
        }
        items(pending, key = { it.id }) { item ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.title)
                    Text("${item.category} · ${item.url}", fontSize = 12.sp, color = Color.Gray, maxLines = 1)
                }
                OutlinedButton(onClick = { scope.launch { app.sources.setStatus(item.id, ItemStatus.APPROVED) } }) { Text("放行") }
                OutlinedButton(onClick = { scope.launch { app.sources.setStatus(item.id, ItemStatus.BLOCKED) } }) { Text("屏蔽") }
            }
        }
    }
}

/* ---------- 密码、激活 ---------- */

@Composable
private fun ChangePinPage(onDone: () -> Unit) {
    val app = App.instance
    val ctx = LocalContext.current
    var changeQ by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        if (changeQ) {
            SecurityForm(onSaved = { Toast.makeText(ctx, "密保已更新", Toast.LENGTH_SHORT).show(); changeQ = false })
        } else {
            Text("设置新的家长密码", fontSize = 18.sp)
            NewPinFlow(onDone = {
                app.pin.set(it)
                Toast.makeText(ctx, "密码已修改", Toast.LENGTH_SHORT).show()
                onDone()
            })
            OutlinedButton(onClick = { changeQ = true }, modifier = Modifier.padding(top = 12.dp)) { Text("修改密保问题") }
        }
    }
}

@Composable
private fun ActivationInfo() {
    val a = App.instance.activation
    Column {
        Text("设备码：${a.deviceCode}", fontSize = 20.sp)
        Text(
            when {
                !a.required -> "调试包，不需要激活"
                a.isActivated -> "已激活：${App.instance.prefs.activationCode}"
                else -> "未激活"
            },
            modifier = Modifier.padding(top = 8.dp),
        )
        Text("设备恢复出厂后设备码可能变化，需要重新激活。", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
    }
}
