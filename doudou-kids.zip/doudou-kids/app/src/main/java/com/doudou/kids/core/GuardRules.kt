package com.doudou.kids.core

/**
 * 无障碍服务什么时候开按键过滤、Home 键怎么处理。思路参考 PlanYourTV 的 HomeGuardService（MIT），
 * 那边的注释里记录了大量真机问题，这里只取和豆豆乐园有关的几条：
 *
 * - 开着过滤时，所有按键都要绕经无障碍服务再注入回去。有的 app 里按一次会移动两格（云视听小电视，小米），
 *   接了游戏手柄或鼠标时小米电视的系统进程会卡死重启。所以只在需要时开，接了手柄或鼠标就关。
 * - Android 11 及以下，系统处理完 Home 键后会把后台启动界面压 5 秒，拉回会很慢。
 *   这些版本上锁定时一直过滤，在无障碍里截下 Home 键自己处理。
 * - Android 12 及以上不再压 5 秒，只在豆豆乐园自己在前台时过滤（屏蔽设置键、信源键等）；
 *   在白名单 app 里按这些键打开的界面会被前台检测拉回。
 */
object KeyFilterRules {
    const val SDK_R = 30

    fun wanted(
        locked: Boolean,
        screenOn: Boolean,
        sdk: Int,
        selfInFront: Boolean,
        gamepadOrMouse: Boolean,
    ): Boolean {
        if (!locked || !screenOn || gamepadOrMouse) return false
        return sdk <= SDK_R || selfInFront
    }

    /**
     * 过滤到 Home 键时是否截下来自己处理。是默认桌面时交给系统（系统会打开 HomeActivity）；
     * 不是默认桌面（guard 变体或固件不让换桌面）时截下，直接拉回豆豆乐园。
     */
    fun takeHome(locked: Boolean, isDefaultHome: Boolean): Boolean = locked && !isDefaultHome

    const val KEYCODE_HOME = 3
    const val KEYCODE_MOVE_HOME = 122
    const val KEYCODE_UNKNOWN = 0

    /** Linux 输入码里遥控器 Home 键的两种：KEY_HOME、KEY_HOMEPAGE */
    private const val SCAN_KEY_HOME = 102
    private const val SCAN_KEY_HOMEPAGE = 172

    /**
     * 键位表配错的遥控器 Home 键：有的遥控器的 Home 被映射成 MOVE_HOME 或 UNKNOWN，系统也不当它是 Home。
     * 带字母的键盘上 MOVE_HOME 是「光标移到行首」，不算。
     */
    fun isHome(keyCode: Int, scanCode: Int, alphabeticKeyboard: Boolean): Boolean = when (keyCode) {
        KEYCODE_HOME -> true
        KEYCODE_MOVE_HOME -> !alphabeticKeyboard && (scanCode == SCAN_KEY_HOME || scanCode == SCAN_KEY_HOMEPAGE)
        KEYCODE_UNKNOWN -> scanCode == SCAN_KEY_HOME || scanCode == SCAN_KEY_HOMEPAGE
        else -> false
    }
}

/**
 * 判断接的是不是真的游戏手柄或外接鼠标（接了就关按键过滤）。电视上很多内置输入设备会谎报自己是手柄，
 * 当成手柄会让过滤一直关着，Home 键先显示厂商桌面。下面的例外名单来自 PlanYourTV 的 GamepadDevices（MIT）。
 */
object InputDeviceRules {
    fun isPhysicalGamepad(
        name: String?,
        isVirtual: Boolean,
        supportsGamepad: Boolean,
        vendorId: Int,
        productId: Int,
        alphabetic: Boolean,
    ): Boolean {
        if (isVirtual || name.orEmpty().contains("virtual", ignoreCase = true) || !supportsGamepad) return false
        // 带字母的全键盘不是手柄（TCL 的手机遥控替身 sim-kb）
        if (alphabetic) return false
        // 内核驱动没设 id 时给内置输入的默认值（Amlogic 红外接收、海思按键），真手柄不会是它
        if (vendorId == 0x0001 && productId == 0x0001) return false
        // 小米 MiTV-AZFP0 的软件事件端点
        if (name == "eventserver-Joystick" && vendorId == 0xdead && productId == 0xbeef) return false
        // 红米投影仪配的小米蓝牙语音遥控器
        if (name == "小米蓝牙语音遥控器" && vendorId == 0x2717 && productId == 0x32b8) return false
        return true
    }

    /** 外接鼠标（Android 10+ 才能判断 isExternal）。TCL 内置的 gIrTouch_Mouse 不是外接的，不算。 */
    fun isExternalMouse(isExternal: Boolean, isVirtual: Boolean, supportsMouse: Boolean): Boolean =
        isExternal && !isVirtual && supportsMouse
}

/** 什么时候不要去拉回：拉回会启动界面，在部分电视上会把待机中的屏幕重新点亮。 */
object PullBackRules {
    fun allowed(screenOn: Boolean, tvPowerMode: String?): Boolean =
        // ColorOS TV 的「快速待机」黑屏时系统仍醒着，此时启动界面会把电视点亮
        screenOn && tvPowerMode != "QUICK"

    /** Android 5–8.1 上，用 PendingIntent 发出启动请求可以绕过 Home 键之后的 5 秒限制 */
    fun viaPendingIntent(sdk: Int): Boolean = sdk <= 27
}
