package com.doudou.kids.lock

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** 设备管理器：只用来防卸载，不申请任何管控策略。 */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "关闭后孩子可以卸载豆豆乐园。建议在豆豆乐园的家长设置里选择「不再使用」。"
}
