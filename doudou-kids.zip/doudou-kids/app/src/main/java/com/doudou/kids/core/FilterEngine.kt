package com.doudou.kids.core

object ItemStatus {
    const val PENDING = "pending"
    const val APPROVED = "approved"
    const val BLOCKED = "blocked"
}

data class FilterConfig(
    /** 家长确认保留的分类名 */
    val allowedCategories: Set<String>,
    val keywordBlacklist: List<String>,
    val childAge: Int,
)

/**
 * 视频源内容过滤（方案文档 3.4.3 的五层规则）：
 * 分类白名单 → 关键词黑名单 → 年龄 → 审核状态 → 单条屏蔽。
 * 注意：过滤只看标题和分类，识别不了画面里的内容。
 */
object FilterEngine {
    val LEARNING_KEYWORDS = listOf(
        "教育", "科普", "纪录", "启蒙", "早教", "英语", "数学", "语文", "编程", "儿歌", "学习", "知识",
        "科学", "历史", "地理", "自然", "物理", "化学", "生物", "绘本", "故事", "国学", "手工", "美术", "音乐", "课",
    )

    val DEFAULT_BLACKLIST = listOf(
        "恐怖", "惊悚", "暴力", "血腥", "灵异", "丧尸", "僵尸", "枪战", "凶杀", "赌", "成人", "情色", "限制级",
    )

    /** 添加源时，名字里带学习类关键词的分类默认勾选。 */
    fun looksLearning(categoryName: String): Boolean = LEARNING_KEYWORDS.any { categoryName.contains(it) }

    fun initialStatus(reviewMode: Boolean): String = if (reviewMode) ItemStatus.PENDING else ItemStatus.APPROVED

    fun isVisible(
        category: String,
        title: String,
        ageMin: Int?,
        ageMax: Int?,
        status: String,
        config: FilterConfig,
    ): Boolean {
        if (status != ItemStatus.APPROVED) return false
        if (category !in config.allowedCategories) return false
        if (config.keywordBlacklist.any { it.isNotBlank() && title.contains(it, ignoreCase = true) }) return false
        if (ageMin != null && config.childAge < ageMin) return false
        if (ageMax != null && config.childAge > ageMax) return false
        return true
    }

    /** 多个源合并时按标题去重，保留第一个。 */
    fun <T> dedupeByTitle(items: List<T>, titleOf: (T) -> String): List<T> {
        val seen = HashSet<String>()
        return items.filter { seen.add(titleOf(it).trim().lowercase()) }
    }
}
