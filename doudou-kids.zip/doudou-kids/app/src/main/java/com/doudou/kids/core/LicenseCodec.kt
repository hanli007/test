package com.doudou.kids.core

import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * 离线激活码。
 *
 * 设备码：设备标识的 SHA-256，取 Crockford Base32 前 10 位，格式 XXXXX-XXXXX。
 * 激活码：HMAC-SHA256(密钥, "DDKIDS1|" + 设备码)，取 Base32 前 16 位，格式 XXXX-XXXX-XXXX-XXXX。
 *
 * 用 HMAC 而不是公钥签名，是为了激活码足够短、能在电视上用遥控器输入。
 * 代价是密钥在 apk 里，反编译可以拿到。生成工具 tools/license/gen_code.py 必须与这里保持一致。
 */
object LicenseCodec {
    private const val ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

    fun deviceCode(rawDeviceId: String): String =
        group(base32(sha256("DDKIDS-DEV|$rawDeviceId")).take(10), 5)

    fun activationCode(secret: String, deviceCode: String): String =
        group(base32(hmac(secret, "DDKIDS1|" + normalize(deviceCode))).take(16), 4)

    fun verify(secret: String, deviceCode: String, input: String): Boolean {
        val a = normalize(input)
        val b = normalize(activationCode(secret, deviceCode))
        return a.length == b.length && MessageDigest.isEqual(a.toByteArray(), b.toByteArray())
    }

    /** 大写，去掉分隔符；把容易看错的 O/I/L 换成 0/1/1。 */
    fun normalize(code: String): String = buildString {
        for (c in code.uppercase()) {
            when (c) {
                'O' -> append('0')
                'I', 'L' -> append('1')
                in ALPHABET -> append(c)
                else -> Unit
            }
        }
    }

    fun group(s: String, size: Int): String = s.chunked(size).joinToString("-")

    fun base32(bytes: ByteArray): String {
        val sb = StringBuilder()
        var buffer = 0
        var bits = 0
        for (b in bytes) {
            buffer = (buffer shl 8) or (b.toInt() and 0xff)
            bits += 8
            while (bits >= 5) {
                sb.append(ALPHABET[(buffer ushr (bits - 5)) and 31])
                bits -= 5
            }
        }
        if (bits > 0) sb.append(ALPHABET[(buffer shl (5 - bits)) and 31])
        return sb.toString()
    }

    private fun sha256(s: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))

    private fun hmac(secret: String, msg: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(msg.toByteArray(Charsets.UTF_8))
    }
}
