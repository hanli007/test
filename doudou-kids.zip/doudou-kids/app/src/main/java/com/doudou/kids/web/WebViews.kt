package com.doudou.kids.web

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader
import com.doudou.kids.BuildConfig
import com.doudou.kids.core.UrlRules

/** 能把按键先交给外部处理的 WebView（游戏页把遥控器按键转给 KidsGame._dispatchInput）。 */
class KidsWebView(context: Context) : WebView(context) {
    var keyHandler: ((KeyEvent) -> Boolean)? = null

    override fun dispatchKeyEvent(event: KeyEvent): Boolean =
        keyHandler?.invoke(event) == true || super.dispatchKeyEvent(event)
}

object WebSetup {
    const val ASSET_HOST = "appassets.androidplatform.net"

    @SuppressLint("SetJavaScriptEnabled")
    fun common(w: WebView) {
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
        }
        // 不允许下载文件
        w.setDownloadListener { _, _, _, _, _ -> }
        w.isFocusable = true
        w.isFocusableInTouchMode = true
    }

    /** 本地 H5 游戏：只从 apk 的 assets 加载，不允许跳去任何外部地址。 */
    fun forAssets(context: Context, w: WebView) {
        common(w)
        val loader = WebViewAssetLoader.Builder()
            .setDomain(ASSET_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != ASSET_HOST
        }
    }

    /**
     * 绘本、实验、白名单网站：页面跳转只允许指定域名（含子域名），点到外部链接会被拦截。
     * 只管页面跳转，不拦图片、脚本等子资源，否则大多数网站的 CDN 资源会加载失败。
     */
    fun restricted(w: WebView, domains: Set<String>, onBlocked: (String) -> Unit, onPage: (String) -> Unit = {}) {
        common(w)
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (UrlRules.allowed(url, domains)) return false
                if (request.isForMainFrame) onBlocked(url)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                onPage(url)
            }
        }
    }

    fun hostOf(url: String): String? = Uri.parse(url).host
}

/**
 * 电视上的虚拟光标（方案 3.3）：方向键移动光标，确认键在光标处点击，碰到边缘时滚动网页。
 * 把 WebView 放进这个容器里使用。
 */
class CursorLayout(context: Context, private val web: WebView) : FrameLayout(context) {
    var cursorEnabled = true
    private var cx = -1f
    private var cy = -1f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var downAt = 0L

    init {
        addView(web, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        setWillNotDraw(false)
        isFocusable = true
        descendantFocusability = FOCUS_BLOCK_DESCENDANTS
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!cursorEnabled) return super.dispatchKeyEvent(event)
        if (cx < 0) { cx = width / 2f; cy = height / 2f }
        val step = (STEP_DP * resources.displayMetrics.density) * (1 + event.repeatCount.coerceAtMost(8) / 2f)
        val down = event.action == KeyEvent.ACTION_DOWN
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> { if (down) move(0f, -step); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { if (down) move(0f, step); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { if (down) move(-step, 0f); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { if (down) move(step, 0f); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (down && event.repeatCount == 0) touch(MotionEvent.ACTION_DOWN)
                else if (event.action == KeyEvent.ACTION_UP) touch(MotionEvent.ACTION_UP)
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun move(dx: Float, dy: Float) {
        val margin = EDGE_DP * resources.displayMetrics.density
        cx = (cx + dx).coerceIn(0f, width - 1f)
        cy = (cy + dy).coerceIn(0f, height - 1f)
        // 碰到上下边缘就滚动网页
        if (cy <= margin && dy < 0) web.scrollBy(0, dy.toInt())
        if (cy >= height - margin && dy > 0) web.scrollBy(0, dy.toInt())
        if (cx <= margin && dx < 0) web.scrollBy(dx.toInt(), 0)
        if (cx >= width - margin && dx > 0) web.scrollBy(dx.toInt(), 0)
        invalidate()
    }

    private fun touch(action: Int) {
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) downAt = now
        val e = MotionEvent.obtain(downAt, now, action, cx, cy, 0)
        e.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
        web.dispatchTouchEvent(e)
        e.recycle()
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (!cursorEnabled || cx < 0) return
        val r = RADIUS_DP * resources.displayMetrics.density
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(200, 255, 138, 61)
        canvas.drawCircle(cx, cy, r, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = r / 3
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)
    }

    private companion object {
        const val STEP_DP = 18f
        const val EDGE_DP = 40f
        const val RADIUS_DP = 12f
    }
}
