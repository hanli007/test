package com.doudou.kids

import android.app.Application
import android.app.UiModeManager
import android.content.pm.PackageManager
import android.content.res.Configuration
import com.doudou.kids.content.SourceRepository
import com.doudou.kids.data.AppDatabase
import com.doudou.kids.data.Prefs
import com.doudou.kids.lock.LockManager
import com.doudou.kids.media.Speech
import com.doudou.kids.parent.Activation
import com.doudou.kids.parent.ParentPin
import com.doudou.kids.timer.UsageTracker

class App : Application() {
    lateinit var prefs: Prefs
        private set
    val db: AppDatabase by lazy { AppDatabase.create(this) }
    val pin: ParentPin by lazy { ParentPin(prefs) }
    val activation: Activation by lazy { Activation(this, prefs) }
    val speech: Speech by lazy { Speech(this) }
    val sources: SourceRepository by lazy { SourceRepository(db, prefs) }
    lateinit var tracker: UsageTracker
        private set

    /** 电视走电视布局（方向键焦点导航），其余走手机/平板布局 */
    val isTv: Boolean by lazy {
        getSystemService(UiModeManager::class.java)?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        LockManager.init(prefs)
        tracker = UsageTracker(this).also { it.start() }
    }

    companion object {
        lateinit var instance: App
            private set
    }
}
