package com.doudou.kids.lock

import android.app.Activity
import android.os.Bundle
import com.doudou.kids.App

/**
 * Home 键入口（不显示界面）。锁定时进孩子首页；未锁定时转去家长原来的桌面，家长感觉不到区别。
 * 设备重启后系统也会先打开这里，所以锁定状态会自动保持。
 */
class HomeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        route()
        finish()
    }

    private fun route() {
        if (App.instance.prefs.locked || !LockManager.startPreviousHome(this)) {
            LockManager.bringToFront(this)
        }
    }
}
