package com.doudou.kids.lock

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.doudou.kids.App
import com.doudou.kids.core.EyeCare
import java.util.Calendar

/**
 * 守护服务自己的浮层窗口（无障碍浮层，不需要悬浮窗权限）：
 * - 护眼滤镜：孩子在白名单 app 里时，盖一层半透明暖色（豆豆乐园里面的滤镜由界面自己画）；
 * - 提示条：比如「还剩 5 分钟」，几秒后自动消失。
 * 两个窗口都不接收触摸和按键，不影响操作。
 */
class GuardOverlay(private val service: AccessibilityService) {
    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var filterView: View? = null
    private var bannerView: TextView? = null
    private val hideBanner = Runnable { removeBanner() }

    private fun params(height: Int, gravity: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        height,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT,
    ).apply { this.gravity = gravity }

    /** 前台、锁定状态、护眼设置变化时调用 */
    fun refresh() {
        val prefs = App.instance.prefs
        val inOtherApp = LockManager.locked.value && !LockManager.appResumed.value &&
            LockManager.foreground.value.let { it != null && it != service.packageName }
        val cal = Calendar.getInstance()
        val minute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val want = inOtherApp && EyeCare.filterOn(prefs.filterEnabled, prefs.filterNightAuto, minute)
        if (!want) {
            filterView?.let { runCatching { wm.removeView(it) } }
            filterView = null
            return
        }
        val alpha = (EyeCare.filterAlpha(prefs.filterStrength) * 255).toInt()
        val color = Color.argb(alpha, 255, 170, 60)
        val v = filterView
        if (v != null) {
            v.setBackgroundColor(color)
            return
        }
        filterView = View(service).also {
            it.setBackgroundColor(color)
            runCatching { wm.addView(it, params(WindowManager.LayoutParams.MATCH_PARENT, Gravity.TOP)) }
        }
    }

    fun banner(text: String) {
        removeBanner()
        val tv = TextView(service).apply {
            this.text = text
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(220, 255, 138, 61))
            gravity = Gravity.CENTER
            setPadding(24, 18, 24, 18)
        }
        if (runCatching { wm.addView(tv, params(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP)) }.isSuccess) {
            bannerView = tv
            tv.postDelayed(hideBanner, BANNER_MS)
        }
    }

    private fun removeBanner() {
        bannerView?.let {
            it.removeCallbacks(hideBanner)
            runCatching { wm.removeView(it) }
        }
        bannerView = null
    }

    fun remove() {
        removeBanner()
        filterView?.let { runCatching { wm.removeView(it) } }
        filterView = null
    }

    private companion object {
        const val BANNER_MS = 6_000L
    }
}
