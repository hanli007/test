package com.doudou.kids.core

/** 护眼（方案 3.8）。 */
object EyeCare {
    /** 夜间：20:00 到次日 7:00 */
    const val NIGHT_START = 20 * 60
    const val NIGHT_END = 7 * 60

    fun isNight(minuteOfDay: Int): Boolean = minuteOfDay >= NIGHT_START || minuteOfDay < NIGHT_END

    /** 滤镜：家长开了就一直显示；开了夜间自动的，夜里也显示。 */
    fun filterOn(enabled: Boolean, nightAuto: Boolean, minuteOfDay: Int): Boolean =
        enabled || (nightAuto && isNight(minuteOfDay))

    /** 强度 0–80 换成叠加层不透明度 */
    fun filterAlpha(strength: Int): Float = strength.coerceIn(0, 80) / 100f
}

/**
 * 距离提醒：用前置摄像头画面里人脸宽度占画面宽度的比例估算距离。
 * 比例越大越近。用两个阈值加持续时间做迟滞，避免在边界上来回闪。
 */
class DistanceJudge(
    private val nearRatio: Float = 0.42f,
    private val farRatio: Float = 0.34f,
    private val holdMs: Long = 2_000L,
) {
    var tooClose = false
        private set
    private var crossedAt = -1L

    /**
     * @param faceRatio 最大那张脸的宽度 / 画面宽度；没检测到脸时传 null
     * @return 状态是否变化
     */
    fun update(faceRatio: Float?, now: Long): Boolean {
        val wantClose = when {
            faceRatio == null -> false
            tooClose -> faceRatio > farRatio
            else -> faceRatio >= nearRatio
        }
        if (wantClose == tooClose) {
            crossedAt = -1
            return false
        }
        if (crossedAt < 0) crossedAt = now
        // 变近要持续一会儿才提醒；离开（或看不到脸）也要持续一会儿才解除
        if (now - crossedAt < holdMs) return false
        tooClose = wantClose
        crossedAt = -1
        return true
    }
}
