package com.doudou.kids.core

import org.json.JSONArray
import org.json.JSONObject

data class SourceCategory(val id: String, val name: String, val ageMin: Int?, val ageMax: Int?)

data class ParsedItem(
    val key: String,
    val title: String,
    val cover: String,
    /** "video"：原生播放器播放；"webpage"：WebView 打开 */
    val type: String,
    val url: String,
    val category: String,
    val ageMin: Int?,
    val ageMax: Int?,
    val tags: List<String>,
    val durationSec: Int?,
)

data class ParsedSource(val name: String, val categories: List<SourceCategory>, val items: List<ParsedItem>)

/**
 * 视频源解析。支持两种格式（见 docs/source-format.md）：
 * 1. 豆豆乐园 JSON 格式
 * 2. M3U 播放列表（group-title 作为分类）
 */
object SourceParser {

    fun parse(text: String): ParsedSource {
        val t = text.trimStart('﻿', ' ', '\n', '\r', '\t')
        return if (t.startsWith("#EXTM3U") || t.startsWith("#EXTINF")) parseM3u(t) else parseJson(t)
    }

    fun parseJson(text: String): ParsedSource {
        val root = JSONObject(text)
        val cats = root.optJSONArray("categories").objects().map {
            SourceCategory(
                id = it.optString("id"),
                name = it.optString("name", it.optString("id")),
                ageMin = it.optIntOrNull("ageMin"),
                ageMax = it.optIntOrNull("ageMax"),
            )
        }
        val catById = cats.associateBy { it.id }
        val items = root.optJSONArray("items").objects().mapNotNull { o ->
            val url = o.optString("url").trim()
            val title = o.optString("title").trim()
            if (url.isEmpty() || title.isEmpty()) return@mapNotNull null
            val cat = catById[o.optString("categoryId")]
            ParsedItem(
                key = o.optString("id").ifBlank { url },
                title = title,
                cover = o.optString("cover"),
                type = if (o.optString("type") == "webpage") "webpage" else "video",
                url = url,
                category = cat?.name ?: o.optString("category").ifBlank { "未分类" },
                ageMin = o.optIntOrNull("ageMin") ?: cat?.ageMin,
                ageMax = o.optIntOrNull("ageMax") ?: cat?.ageMax,
                tags = o.optJSONArray("tags")?.let { a -> List(a.length()) { a.optString(it) } } ?: emptyList(),
                durationSec = o.optIntOrNull("duration"),
            )
        }
        return ParsedSource(root.optString("name", "未命名源"), cats, items)
    }

    private val ATTR = Regex("([A-Za-z][\\w-]*)=\"([^\"]*)\"")

    fun parseM3u(text: String): ParsedSource {
        val items = mutableListOf<ParsedItem>()
        var pendingTitle: String? = null
        var pendingAttrs: Map<String, String> = emptyMap()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF")) {
                val comma = line.indexOf(',')
                val head = if (comma >= 0) line.substring(0, comma) else line
                pendingTitle = if (comma >= 0) line.substring(comma + 1).trim() else ""
                pendingAttrs = ATTR.findAll(head).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                continue
            }
            if (line.startsWith("#")) continue
            val title = pendingTitle?.ifBlank { null } ?: line.substringAfterLast('/')
            items += ParsedItem(
                key = line,
                title = title,
                cover = pendingAttrs["tvg-logo"].orEmpty(),
                type = "video",
                url = line,
                category = pendingAttrs["group-title"]?.ifBlank { null } ?: "未分类",
                ageMin = null,
                ageMax = null,
                tags = emptyList(),
                durationSec = null,
            )
            pendingTitle = null
            pendingAttrs = emptyMap()
        }
        val cats = items.map { it.category }.distinct().map { SourceCategory(it, it, null, null) }
        return ParsedSource("M3U 播放列表", cats, items)
    }

    private fun JSONArray?.objects(): List<JSONObject> =
        if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

    private fun JSONObject.optIntOrNull(name: String): Int? =
        if (has(name) && !isNull(name)) optInt(name).takeIf { optString(name).isNotBlank() } else null
}
