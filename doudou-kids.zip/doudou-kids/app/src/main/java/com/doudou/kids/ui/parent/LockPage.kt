package com.doudou.kids.ui.parent

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doudou.kids.App
import com.doudou.kids.core.HomeCandidate
import com.doudou.kids.lock.LockManager
import com.doudou.kids.ui.SectionTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class Perm(val title: String, val ok: Boolean, val hint: String, val fix: () -> Unit)

/** 尝试锁定；缺权限时提示。返回是否已经锁定。 */
fun tryLock(activity: Activity): Boolean {
    val missing = LockManager.missingRequired(activity)
    if (missing.isNotEmpty()) {
        Toast.makeText(activity, "还需要开启：${missing.joinToString("、")}", Toast.LENGTH_LONG).show()
        return false
    }
    return when (LockManager.lock(activity)) {
        LockManager.LockResult.LOCKED -> true
        LockManager.LockResult.WAITING_FOR_SERVICE -> {
            Toast.makeText(activity, "请开启「豆豆乐园 · 儿童锁定」无障碍服务，开启后自动锁定", Toast.LENGTH_LONG).show()
            false
        }
    }
}

/** 权限与锁定（方案 3.1.5）。resumeTick 变化时重新检测（从系统设置页回来）。 */
@Composable
fun LockPage(activity: Activity, isTv: Boolean, resumeTick: Int) {
    val ctx = LocalContext.current
    val guardRunning by LockManager.guardRunning.collectAsState()
    val perms = remember(resumeTick) {
        buildList {
            if (LockManager.homeDeclared) {
                add(Perm("设为默认桌面", LockManager.isDefaultHome(ctx), "按 Home 键回到豆豆乐园；未锁定时自动转到原来的桌面") {
                    val prefs = App.instance.prefs
                    if (prefs.previousHome == null) LockManager.previousHome(ctx)?.let(LockManager::rememberPreviousHome)
                    LockManager.openHomeSettings(activity)
                })
            }
            add(Perm("悬浮窗", LockManager.canDrawOverlays(ctx), "允许从后台把豆豆乐园拉回前台") { LockManager.openOverlaySettings(activity) })
            add(Perm("防卸载（设备管理器）", LockManager.isAdminActive(ctx), "孩子不能直接卸载") { LockManager.requestAdmin(activity) })
            add(Perm("电池优化白名单（建议）", LockManager.ignoresBatteryOptimizations(ctx), "国产系统还要在手机管家 / 电视管家里允许自启动，否则后台会被杀") {
                LockManager.openBatterySettings(activity)
            })
            add(Perm("守护恢复（建议）", LockManager.isRevivalEnabled(ctx), "被系统杀掉后自动恢复锁定，需配合下面的 adb 授权。不读取任何通知") {
                LockManager.openNotificationListenerSettings(activity)
            })
        }
    }
    val guardListed = remember(resumeTick) { LockManager.isGuardEnabled(ctx) }
    val adbOk = remember(resumeTick) { LockManager.canWriteSecureSettings(ctx) }
    val homes = remember(resumeTick) { LockManager.homeCandidates(ctx).filter { it.pkg != ctx.packageName && it.priority > -1000 } }
    var prevHome by remember { mutableStateOf(App.instance.prefs.previousHome) }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!LockManager.homeDeclared) {
            item {
                Text(
                    "这是 guard 版：不声明桌面入口，用于拒绝安装桌面类 app 的电视（部分 TCL、海信）。按 Home 键时可能先闪一下电视自带的桌面，随后回到豆豆乐园。",
                    fontSize = 13.sp, color = Color.Gray,
                )
            }
        }
        items(perms) { PermRow(it) }
        item {
            val state = when {
                guardRunning -> "运行中"
                guardListed -> "已开启但没在运行（试试重新开关一次，或重启设备）"
                else -> "未开启"
            }
            PermRow(Perm("无障碍服务：$state", guardRunning, "检测孩子打开了别的 app 并拉回。点「锁定」时会自动引导开启；解锁后自动关闭") {
                LockManager.openAccessibilitySettings(activity)
            })
        }
        if (!guardRunning && LockManager.needsRestrictedSettingsHint) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Android 13 及以上：如果无障碍里豆豆乐园是灰色的，先到「应用信息 → 右上角菜单 → 允许受限制的设置」。",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f),
                    )
                    OutlinedButton(onClick = { LockManager.openAppDetails(activity) }) { Text("应用信息") }
                }
            }
        }
        item { SectionTitle("电脑 adb 授权（建议）", if (adbOk) "已授权：锁定、解锁和被杀后恢复都能自动完成" else "未授权", isTv) }
        item {
            Text("在电视或手机上打开 USB / 网络调试，电脑执行：", fontSize = 13.sp, color = Color.Gray)
        }
        items(LockManager.adbCommands(ctx)) { cmd ->
            Text(cmd, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
        }
        if (LockManager.homeDeclared && homes.isNotEmpty()) {
            item { SectionTitle("原来的桌面", "解锁时按 Home 键去这里", isTv) }
            items(homes) { h ->
                val key = "${h.pkg}/${h.cls}"
                val selected = prevHome == key || (prevHome == null && h == LockManager.previousHome(ctx))
                Row(
                    Modifier.fillMaxWidth().clickable { LockManager.rememberPreviousHome(h); prevHome = key },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = selected, onClick = null)
                    Text(homeLabel(ctx, h))
                }
            }
        }
        item {
            Column(Modifier.padding(top = 16.dp)) {
                Button(onClick = { tryLock(activity) }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("锁定并进入孩子模式", fontSize = 20.sp) }
                OutlinedButton(onClick = { LockManager.retire(activity) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text(if (LockManager.homeDeclared) "不再使用：取消防卸载并改回原来的桌面" else "不再使用：取消防卸载")
                }
            }
        }
    }
}

private fun homeLabel(ctx: android.content.Context, h: HomeCandidate): String =
    runCatching { ctx.packageManager.getApplicationInfo(h.pkg, 0).loadLabel(ctx.packageManager).toString() }
        .getOrDefault(h.pkg) + "（${h.pkg}）"

@Composable
private fun PermRow(p: Perm) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text((if (p.ok) "✅ " else "⬜ ") + p.title, fontSize = 16.sp)
            Text(p.hint, fontSize = 13.sp, color = Color.Gray)
        }
        if (!p.ok) OutlinedButton(onClick = p.fix) { Text("去开启") }
    }
}

/** 白名单 app（方案 3.2）：锁定后孩子可以打开的 app */
@Composable
fun AppsPage() {
    val ctx = LocalContext.current
    val prefs = App.instance.prefs
    var allowed by remember { mutableStateOf(prefs.allowedApps) }
    val apps by produceState(emptyList<LockManager.LaunchableApp>()) {
        value = withContext(Dispatchers.IO) { LockManager.launchableApps(ctx) }
    }
    LazyColumn {
        item { Text("提醒：关闭这些 app 的免密支付，打开它们自带的家长锁。白名单 app 的使用时间也计入每日总时长。", fontSize = 13.sp, color = Color.Gray) }
        items(apps, key = { it.pkg }) { a ->
            Row(
                Modifier.fillMaxWidth().clickable {
                    allowed = if (a.pkg in allowed) allowed - a.pkg else allowed + a.pkg
                    prefs.allowedApps = allowed
                },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(checked = a.pkg in allowed, onCheckedChange = null)
                Text(a.label)
            }
        }
    }
}
