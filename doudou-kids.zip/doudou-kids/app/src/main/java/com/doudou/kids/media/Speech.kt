package com.doudou.kids.media

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * 系统 TTS 兜底（方案 3.6.3）：先读中文，再读英文，任一可为空。
 * 游戏优先播放 assets/games/_voice 里的预录音频，找不到才走这里。
 * 引擎同一时间只能设一种语言，所以英文要等中文读完（onDone）再切语言读。
 */
class Speech(context: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pendingEn: String? = null
    private var queued: Pair<String?, String?>? = null
    private var token = 0

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) = onFinished(utteranceId)
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = onFinished(utteranceId)
                })
                queued?.let { (zh, en) -> speak(zh, en) }
                queued = null
            }
        }
    }

    /** 可以在任意线程调用（游戏桥在 JavaBridge 线程） */
    @Synchronized
    fun speak(zh: String?, en: String?) {
        val t = tts ?: return
        if (!ready) {
            queued = zh to en
            return
        }
        token++
        t.stop()
        val zhText = zh?.takeIf { it.isNotBlank() }
        val enText = en?.takeIf { it.isNotBlank() }
        if (zhText != null) {
            pendingEn = enText
            t.setLanguage(Locale.SIMPLIFIED_CHINESE)
            t.speak(zhText, TextToSpeech.QUEUE_FLUSH, null, "zh-$token")
        } else if (enText != null) {
            pendingEn = null
            speakEnglish(t, enText)
        }
    }

    @Synchronized
    private fun onFinished(id: String?) {
        if (id != "zh-$token") return
        val en = pendingEn ?: return
        pendingEn = null
        tts?.let { speakEnglish(it, en) }
    }

    private fun speakEnglish(t: TextToSpeech, text: String) {
        // 很多国产设备没有英文离线语音，设置失败时就不读英文
        val r = t.setLanguage(Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) return
        t.speak(text, TextToSpeech.QUEUE_ADD, null, "en-$token")
    }

    @Synchronized
    fun stop() {
        token++
        pendingEn = null
        queued = null
        tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
        ready = false
    }
}
