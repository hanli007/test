package com.doudou.kids.lock

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import com.doudou.kids.BuildConfig
import com.doudou.kids.MainActivity
import com.doudou.kids.core.HomeCandidate
import com.doudou.kids.core.HomePicker
import com.doudou.kids.data.Prefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 设备锁定（方案第 3.1 节）：默认桌面 + 无障碍服务检测拉回 + 悬浮窗 + 设备管理器防卸载。
 * 不刷机、不需要设备所有者。
 *
 * guard 变体（[homeDeclared] 为 false）不声明桌面入口，只靠无障碍服务把厂商桌面挡回去。
 */
object LockManager {
    private lateinit var prefs: Prefs
    private val _locked = MutableStateFlow(false)
    val locked: StateFlow<Boolean> = _locked.asStateFlow()

    /** 豆豆乐园的界面在前台（MainActivity 处于 resumed） */
    private val _appResumed = MutableStateFlow(false)
    val appResumed: StateFlow<Boolean> = _appResumed.asStateFlow()

    /** 守护服务看到的前台 app 包名；不知道时为 null */
    private val _foreground = MutableStateFlow<String?>(null)
    val foreground: StateFlow<String?> = _foreground.asStateFlow()

    /** 守护服务是否真的连上了。设置里「已启用」不等于系统绑定了它（升级后常见），以这个为准。 */
    private val _guardRunning = MutableStateFlow(false)
    val guardRunning: StateFlow<Boolean> = _guardRunning.asStateFlow()

    val homeDeclared: Boolean get() = BuildConfig.HOME_DECLARED

    fun init(p: Prefs) {
        prefs = p
        _locked.value = p.locked
    }

    internal fun setLocked(v: Boolean) {
        prefs.locked = v
        _locked.value = v
        GuardService.instance?.onStateChanged()
    }

    fun setAppResumed(v: Boolean) {
        _appResumed.value = v
        GuardService.instance?.onStateChanged()
    }

    internal fun reportForeground(pkg: String) {
        _foreground.value = pkg
    }

    internal fun reportGuardRunning(v: Boolean) {
        _guardRunning.value = v
    }

    enum class LockResult {
        LOCKED,
        /** 已跳到无障碍设置页，开启服务后自动完成锁定 */
        WAITING_FOR_SERVICE,
    }

    fun lock(activity: Activity): LockResult {
        GuardService.instance?.let {
            it.refresh()
            setLocked(true)
            return LockResult.LOCKED
        }
        prefs.lockPending = true
        // 家长用 adb 授权过时，自己打开服务，不用进设置页（方案 3.1.8 进阶选项）
        if (!canWriteSecureSettings(activity) || !setGuardEnabled(activity, true)) {
            openAccessibilitySettings(activity)
        }
        return LockResult.WAITING_FOR_SERVICE
    }

    /** 密码已验证后调用。解锁时关掉无障碍服务，免得银行、支付 app 提示风险（方案 3.1.7）。 */
    fun unlock(context: Context) {
        prefs.lockPending = false
        setLocked(false)
        val service = GuardService.instance
        if (service != null) service.disableSelf() else if (canWriteSecureSettings(context)) setGuardEnabled(context, false)
    }

    /* ---------- 自我修复（需要 adb 授予 WRITE_SECURE_SETTINGS） ---------- */

    /**
     * 锁定中却发现守护服务不在启用列表里（被固件杀掉后 Android 会把它删掉），写回去。
     * 返回是否做了修改。
     */
    fun ensureGuardEnabled(context: Context): Boolean {
        if (!prefs.locked && !prefs.lockPending) return false
        if (isGuardEnabled(context) || !canWriteSecureSettings(context)) return false
        return setGuardEnabled(context, true)
    }

    /**
     * 列表里有、但系统没绑定：先把自己移出列表，隔一会儿再加回去，Android 就会重新绑定。
     * 两次写入挨得太近会被合并成「没变化」，所以中间等 1.5 秒（PlanYourTV 的 rebindIfStalled 同样做法）。
     */
    fun rebindIfStalled(context: Context) {
        if (GuardService.instance != null || !canWriteSecureSettings(context) || !isGuardEnabled(context)) return
        if (!prefs.locked && !prefs.lockPending) return
        val app = context.applicationContext
        if (!setGuardEnabled(app, false)) return
        Handler(Looper.getMainLooper()).postDelayed({ setGuardEnabled(app, true) }, 1_500)
    }

    /* ---------- 权限检测 ---------- */

    fun isDefaultHome(context: Context): Boolean {
        val ri = context.packageManager.resolveActivity(homeIntent(), PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == context.packageName
    }

    fun isGuardEnabled(context: Context): Boolean =
        listed(Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES), guardComponent(context))

    fun isRevivalEnabled(context: Context): Boolean =
        listed(Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners"), revivalComponent(context))

    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun isAdminActive(context: Context): Boolean = dpm(context).isAdminActive(adminComponent(context))

    fun ignoresBatteryOptimizations(context: Context): Boolean =
        context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)

    /** adb shell pm grant com.doudou.kids android.permission.WRITE_SECURE_SETTINGS */
    fun canWriteSecureSettings(context: Context): Boolean =
        context.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    /**
     * 全部必需项都开好了才能锁定；电池优化、adb 授权、复活服务是建议项。
     * guard 变体没有桌面入口，默认桌面不是必需项。
     */
    fun missingRequired(context: Context): List<String> = buildList {
        if (homeDeclared && !isDefaultHome(context)) add("默认桌面")
        if (!canDrawOverlays(context)) add("悬浮窗")
        if (!isAdminActive(context)) add("防卸载")
    }

    /* ---------- 跳转到各设置页 ---------- */

    fun openHomeSettings(context: Context) {
        tryStart(
            context,
            Intent(Settings.ACTION_HOME_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            // 还没有默认桌面时会弹出系统的选择框，选豆豆乐园并点「始终」
            homeIntent(),
        )
    }

    fun openAccessibilitySettings(context: Context) {
        tryStart(context, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), appDetails(context))
    }

    fun openOverlaySettings(context: Context) {
        tryStart(
            context,
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")),
            appDetails(context),
        )
    }

    fun openNotificationListenerSettings(context: Context) {
        tryStart(context, Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"), appDetails(context))
    }

    fun requestAdmin(activity: Activity) {
        val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent(activity))
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "开启后，孩子不能直接卸载豆豆乐园。家长可在豆豆乐园设置里随时关闭。")
        tryStart(activity, i)
    }

    fun openBatterySettings(context: Context) {
        tryStart(context, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), appDetails(context))
    }

    /** Android 13+ 从浏览器装的 apk 要先在这里「允许受限制的设置」，才能开无障碍。 */
    fun openAppDetails(context: Context) {
        tryStart(context, appDetails(context))
    }

    val needsRestrictedSettingsHint: Boolean get() = Build.VERSION.SDK_INT >= 33

    /** 「不再使用」：取消防卸载，并引导家长把默认桌面改回去，之后可正常卸载。 */
    fun retire(context: Context) {
        unlock(context)
        if (isAdminActive(context)) dpm(context).removeActiveAdmin(adminComponent(context))
        if (homeDeclared) openHomeSettings(context)
    }

    /** 家长用电脑执行的 adb 命令，显示在权限页上（方案 3.1.5、3.1.8）。 */
    fun adbCommands(context: Context): List<String> {
        val pkg = context.packageName
        return buildList {
            add("adb shell pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
            add("adb shell appops set $pkg SYSTEM_ALERT_WINDOW allow")
            if (Build.VERSION.SDK_INT >= 33) add("adb shell appops set $pkg ACCESS_RESTRICTED_SETTINGS allow")
            add("adb shell cmd notification allow_listener ${revivalComponent(context).flattenToString()}")
            if (homeDeclared) add("adb shell cmd package set-home-activity $pkg/.lock.HomeActivity")
            // TCL / 雷鸟的自启动开关，其他固件上不认识这些名字，执行失败无害
            add("for op in APP_AUTO_START APP_ASSOC_START AUTO_START ASSOC_START; do adb shell appops set $pkg \$op allow; done")
        }
    }

    /* ---------- 桌面与 app 列表 ---------- */

    fun homeCandidates(context: Context): List<HomeCandidate> =
        context.packageManager.queryIntentActivities(homeIntent(), 0).map {
            val ai = it.activityInfo
            HomeCandidate(ai.packageName, ai.name, it.priority, (ai.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
        }

    fun previousHome(context: Context): HomeCandidate? =
        HomePicker.pick(homeCandidates(context), context.packageName, prefs.previousHome)

    fun rememberPreviousHome(c: HomeCandidate) {
        prefs.previousHome = "${c.pkg}/${c.cls}"
    }

    /** 解锁状态下按 Home 键：转去原来的桌面。找不到时返回 false。 */
    fun startPreviousHome(context: Context): Boolean {
        val c = previousHome(context) ?: return false
        val i = homeIntent().setComponent(ComponentName(c.pkg, c.cls)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return tryStart(context, i)
    }

    fun bringToFrontIntent(context: Context): Intent =
        Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)

    fun bringToFront(context: Context) {
        tryStart(context, bringToFrontIntent(context))
    }

    data class LaunchableApp(val pkg: String, val label: String)

    /** 本机可打开的 app（手机桌面入口和电视桌面入口都算），用于勾选白名单。 */
    fun launchableApps(context: Context): List<LaunchableApp> {
        val pm = context.packageManager
        val infos = listOf(Intent.CATEGORY_LAUNCHER, Intent.CATEGORY_LEANBACK_LAUNCHER).flatMap {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(it), 0)
        }
        return infos.map { it.activityInfo.packageName to it }
            .distinctBy { it.first }
            .filter { it.first != context.packageName }
            .map { (pkg, ri) -> LaunchableApp(pkg, ri.loadLabel(pm).toString()) }
            .sortedBy { it.label }
    }

    fun launchApp(context: Context, pkg: String, preferTv: Boolean): Boolean {
        val pm = context.packageManager
        val i = (if (preferTv) pm.getLeanbackLaunchIntentForPackage(pkg) else null)
            ?: pm.getLaunchIntentForPackage(pkg)
            ?: pm.getLeanbackLaunchIntentForPackage(pkg)
            ?: return false
        return tryStart(context, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /* ---------- 内部 ---------- */

    fun guardComponent(context: Context) = ComponentName(context, GuardService::class.java)
    private fun revivalComponent(context: Context) = ComponentName(context, RevivalListener::class.java)
    private fun adminComponent(context: Context) = ComponentName(context, AdminReceiver::class.java)
    private fun dpm(context: Context) = context.getSystemService(DevicePolicyManager::class.java)
    internal fun homeIntent() = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    private fun appDetails(context: Context) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))

    private fun listed(value: String?, component: ComponentName): Boolean =
        value.orEmpty().split(':').any { it.isNotBlank() && ComponentName.unflattenFromString(it) == component }

    /** 只增删自己这一项，保留其他 app 的无障碍服务 */
    private fun setGuardEnabled(context: Context, on: Boolean): Boolean = runCatching {
        val cr = context.contentResolver
        val me = guardComponent(context)
        val cur = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            .split(':').filter { it.isNotBlank() && ComponentName.unflattenFromString(it) != me }
        val next = if (on) cur + me.flattenToString() else cur
        Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, next.joinToString(":"))
        if (on) Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        true
    }.getOrDefault(false)

    /** 依次尝试，电视上很多设置页不存在，取第一个能打开的。 */
    private fun tryStart(context: Context, vararg intents: Intent): Boolean {
        for (i in intents) {
            if (context !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(i)
                return true
            } catch (_: ActivityNotFoundException) {
            } catch (_: SecurityException) {
            }
        }
        return false
    }
}
