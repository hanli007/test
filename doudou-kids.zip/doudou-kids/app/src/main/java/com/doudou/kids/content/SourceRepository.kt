package com.doudou.kids.content

import com.doudou.kids.core.FilterConfig
import com.doudou.kids.core.FilterEngine
import com.doudou.kids.core.ParsedSource
import com.doudou.kids.core.SourceParser
import com.doudou.kids.data.AppDatabase
import com.doudou.kids.data.Prefs
import com.doudou.kids.data.ProfileEntity
import com.doudou.kids.data.SourceItemEntity
import com.doudou.kids.data.VideoSourceEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * 视频源（方案 3.4）：添加源 + 五层过滤。只缓存内容列表，不缓存视频。
 * 不内置影视资源站或 TVBox 接口，不做爬虫。
 */
class SourceRepository(private val db: AppDatabase, private val prefs: Prefs) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val dao get() = db.sources()

    fun observeSources(): Flow<List<VideoSourceEntity>> = dao.observeSources()
    fun observePending(): Flow<List<SourceItemEntity>> = dao.observePending()

    suspend fun fetch(url: String): ParsedSource = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", "DoudouKids").build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("HTTP ${resp.code}")
            val body = resp.body?.string() ?: error("空内容")
            if (body.length > MAX_SOURCE_CHARS) error("源文件太大")
            SourceParser.parse(body)
        }
    }

    /**
     * 添加源。名字里带学习类关键词的分类默认勾选，其余由家长确认（过滤第 1 层）。
     * 审核模式下新内容先隐藏，家长放行后才显示（第 4 层）。
     */
    suspend fun add(url: String, reviewMode: Boolean): Long {
        val parsed = fetch(url)
        val all = parsed.categories.map { it.name }.ifEmpty { parsed.items.map { it.category }.distinct() }
        val allowed = all.filter { FilterEngine.looksLearning(it) }
        val id = withContext(Dispatchers.IO) {
            dao.insertSource(
                VideoSourceEntity(
                    name = parsed.name,
                    url = url,
                    reviewMode = reviewMode,
                    allowedCategories = allowed.joinToString("\n"),
                    allCategories = all.joinToString("\n"),
                    lastUpdated = System.currentTimeMillis(),
                ),
            )
        }
        store(id, parsed, reviewMode)
        return id
    }

    suspend fun refresh(source: VideoSourceEntity) {
        try {
            val parsed = fetch(source.url)
            val all = (source.allList() + parsed.categories.map { it.name } + parsed.items.map { it.category }).distinct()
            store(source.id, parsed, source.reviewMode)
            withContext(Dispatchers.IO) {
                dao.updateSource(source.copy(allCategories = all.joinToString("\n"), lastUpdated = System.currentTimeMillis(), lastError = null))
            }
        } catch (e: Exception) {
            withContext(Dispatchers.IO) { dao.updateSource(source.copy(lastError = e.message ?: e.javaClass.simpleName)) }
        }
    }

    suspend fun refreshAll() {
        for (s in withContext(Dispatchers.IO) { dao.sources() }) if (s.enabled) refresh(s)
    }

    suspend fun update(source: VideoSourceEntity) = withContext(Dispatchers.IO) { dao.updateSource(source) }
    suspend fun delete(id: Long) = withContext(Dispatchers.IO) { dao.deleteSource(id) }
    suspend fun setStatus(itemId: Long, status: String) = withContext(Dispatchers.IO) { dao.setStatus(itemId, status) }
    suspend fun approveAllPending(status: String) = withContext(Dispatchers.IO) { dao.setAllPending(status) }
    /** 播放失败的链接自动隐藏（方案 3.4.4） */
    suspend fun markFailed(itemId: Long) = withContext(Dispatchers.IO) { dao.markFailed(itemId) }

    private suspend fun store(sourceId: Long, parsed: ParsedSource, reviewMode: Boolean) {
        val status = FilterEngine.initialStatus(reviewMode)
        val rows = parsed.items.map {
            SourceItemEntity(
                sourceId = sourceId, itemKey = it.key, title = it.title, cover = it.cover, type = it.type, url = it.url,
                category = it.category, ageMin = it.ageMin, ageMax = it.ageMax, durationSec = it.durationSec, status = status,
            )
        }
        withContext(Dispatchers.IO) { dao.replaceItems(sourceId, rows) }
    }

    /** 孩子能看到的内容：启用的源 → 五层过滤 → 去掉播放失败的 → 按标题去重 */
    fun visibleItems(profile: Flow<ProfileEntity?>): Flow<List<SourceItemEntity>> =
        combine(dao.observeSources(), dao.observeItems(), profile) { sources, items, p ->
            if (p == null) return@combine emptyList()
            val blacklist = prefs.keywordBlacklist
            val byId = sources.filter { it.enabled }.associateBy { it.id }
            val visible = items.filter { item ->
                val src = byId[item.sourceId] ?: return@filter false
                !item.failed && FilterEngine.isVisible(
                    item.category, item.title, item.ageMin, item.ageMax, item.status,
                    FilterConfig(src.allowedSet(), blacklist, p.age),
                )
            }
            FilterEngine.dedupeByTitle(visible) { it.title }
        }

    private companion object {
        const val MAX_SOURCE_CHARS = 8 * 1024 * 1024
    }
}
