package com.doudou.kids.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = lightColorScheme(
    primary = Color(0xFFFF8A3D),
    onPrimary = Color.White,
    secondary = Color(0xFF4CB8A5),
    background = Color(0xFFFFF5E1),
    surface = Color(0xFFFFFBF3),
    error = Color(0xFFD9534F),
)

@Composable
fun DoudouTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
