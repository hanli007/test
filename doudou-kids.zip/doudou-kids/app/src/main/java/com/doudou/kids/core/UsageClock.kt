package com.doudou.kids.core

/**
 * 使用时长累加。用开机后流逝时间（elapsedRealtime）的差值计时，孩子改系统时间也不影响（方案 3.7）。
 * 单次间隔封顶，防止进程被冻结、设备休眠后一次记上一大段。
 */
class UsageClock(private val maxStepMs: Long = 5_000L) {
    private var lastAt: Long = -1
    private var carryMs: Long = 0

    /**
     * 每次心跳调用。返回这次应计入的整秒数。
     * @param nowElapsed SystemClock.elapsedRealtime()
     * @param active 这段时间是否在计时范围内（锁定、屏幕亮着、豆豆乐园或白名单 app 在前台）
     */
    fun tick(nowElapsed: Long, active: Boolean): Long {
        val prev = lastAt
        lastAt = nowElapsed
        if (prev < 0 || !active || nowElapsed <= prev) return 0
        carryMs += (nowElapsed - prev).coerceAtMost(maxStepMs)
        val sec = carryMs / 1000
        carryMs -= sec * 1000
        return sec
    }

    /** 暂停后重新开始：丢掉上次的时间点，避免把暂停期间算进去。 */
    fun reset() {
        lastAt = -1
        carryMs = 0
    }
}
