package com.doudou.kids.ui.kid

import android.view.KeyEvent
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.doudou.kids.App
import com.doudou.kids.core.GameEntry
import com.doudou.kids.data.Prefs
import com.doudou.kids.data.SourceItemEntity
import com.doudou.kids.games.GameBridge
import com.doudou.kids.ui.ScreenScaffold
import com.doudou.kids.web.CursorLayout
import com.doudou.kids.web.KidsWebView
import com.doudou.kids.web.WebSetup
import kotlinx.coroutines.launch

/* ---------- 游戏容器（方案 3.6.2、6.5） ---------- */

/**
 * WebView + WebViewAssetLoader 加载 assets/games，注入 KidsBridge。
 * 遥控器方向键、确认、返回转成 KidsGame._dispatchInput；[paused] 为 true（休息、时间用完、距离太近、
 * 家长密码框打开）时调用 KidsGame._pause()。
 */
@Composable
fun GameScreen(d: KidData, entry: GameEntry, paused: Boolean, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val app = App.instance
    val exit by rememberUpdatedState(onExit)
    val web = remember {
        KidsWebView(ctx).apply {
            WebSetup.forAssets(ctx, this)
            val profileJson = GameBridge.profileJson(
                d.profile.name, d.tier.code, d.profile.age, d.isTv, app.prefs.englishVoice, app.prefs.soundEnabled,
            )
            addJavascriptInterface(GameBridge(entry.id, d.profile.id, profileJson) { exit() }, "KidsBridge")
            keyHandler = { e -> forwardKey(this, e) }
            loadUrl(entry.url)
        }
    }
    LaunchedEffect(Unit) { app.prefs.bumpStat(Prefs.dayKey(), "games") }
    LaunchedEffect(paused) { web.evaluateJavascript(if (paused) JS_PAUSE else JS_RESUME, null) }
    // 手机的返回手势也交给游戏：游戏没处理时由共享库调用 KidsBridge.exit()
    BackHandler { web.evaluateJavascript(js("back"), null) }
    DisposableEffect(Unit) {
        web.requestFocus()
        onDispose {
            app.speech.stop()
            web.stopLoading()
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
        }
    }
    AndroidView(factory = { web }, modifier = Modifier.fillMaxSize())
}

private const val JS_PAUSE = "window.KidsGame&&KidsGame._pause()"
private const val JS_RESUME = "window.KidsGame&&KidsGame._resume()"
private fun js(key: String) = "window.KidsGame&&KidsGame._dispatchInput('$key')"

private fun forwardKey(web: WebView, e: KeyEvent): Boolean {
    val key = when (e.keyCode) {
        KeyEvent.KEYCODE_DPAD_UP -> "up"
        KeyEvent.KEYCODE_DPAD_DOWN -> "down"
        KeyEvent.KEYCODE_DPAD_LEFT -> "left"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> "ok"
        KeyEvent.KEYCODE_BACK -> "back"
        else -> return false
    }
    // 只在按下时发一次，抬起也吃掉，免得 WebView 再生成一次键盘事件
    if (e.action == KeyEvent.ACTION_DOWN && (e.repeatCount == 0 || key != "ok" && key != "back")) {
        web.evaluateJavascript(js(key), null)
    }
    return true
}

/* ---------- 视频播放（Media3） ---------- */

/** 原生播放器。不自动连播；播放失败的链接自动隐藏（方案 3.4.4）。 */
@Composable
fun PlayerScreen(d: KidData, item: SourceItemEntity, paused: Boolean, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val app = App.instance
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    val exo = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(item.url))
            repeatMode = Player.REPEAT_MODE_OFF
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(Unit) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                error = "这个视频播放不了，已经帮你藏起来啦"
                scope.launch { app.sources.markFailed(item.id) }
            }
        }
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }
    LaunchedEffect(Unit) { app.prefs.bumpStat(Prefs.dayKey(), "videos") }
    LaunchedEffect(paused) { if (paused) exo.pause() }
    BackHandler { onExit() }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = exo
                    useController = true
                    keepScreenOn = true
                    requestFocus()
                }
            },
            modifier = Modifier.fillMaxSize(),
        )
        error?.let {
            Column(Modifier.fillMaxWidth().padding(24.dp)) {
                Text(it, color = Color.White)
                Text("按返回键回到列表", color = Color.LightGray)
            }
        }
    }
}

/* ---------- 受限网页：StoryWeaver 绘本、PhET 实验、白名单网站（方案 3.3、3.5） ---------- */

@Composable
fun WebScreen(d: KidData, title: String, url: String, domains: Set<String>, stat: String, paused: Boolean, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val app = App.instance
    val web = remember {
        KidsWebView(ctx).apply {
            WebSetup.restricted(this, domains, onBlocked = {
                Toast.makeText(ctx, "这个链接不在允许的网站里", Toast.LENGTH_SHORT).show()
            })
            loadUrl(url)
        }
    }
    // 电视上用虚拟光标点击网页
    val container = remember { if (d.isTv) CursorLayout(ctx, web) else null }
    LaunchedEffect(Unit) { app.prefs.bumpStat(Prefs.dayKey(), stat) }
    LaunchedEffect(paused) { if (paused) web.onPause() else web.onResume() }
    BackHandler { if (web.canGoBack()) web.goBack() else onExit() }
    DisposableEffect(Unit) {
        (container ?: web).requestFocus()
        onDispose {
            web.stopLoading()
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
        }
    }
    ScreenScaffold(title, d.isTv, onBack = onExit) {
        AndroidView(factory = { container ?: web }, modifier = Modifier.fillMaxSize())
    }
}
