/* 认知卡片：选类别 → 大卡片翻开，读中英文名称；左右滑动或遥控器左右键切换。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  function shapeSVG(inner, color) {
    return '<svg viewBox="0 0 100 100" aria-hidden="true"><g fill="' + color + '" stroke="rgba(0,0,0,.18)" stroke-width="3" stroke-linejoin="round">' + inner + '</g></svg>';
  }

  var CATS = [
    { id: 'animal', icon: '🐶', say: { key: 'item_animals', zh: '动物', en: 'animals' }, cards: [
      { e: '🐶', say: { key: 'animal_dog', zh: '小狗', en: 'dog' }, sound: { key: 'animal_dog_sound', zh: '汪汪汪' } },
      { e: '🐱', say: { key: 'animal_cat', zh: '小猫', en: 'cat' }, sound: { key: 'animal_cat_sound', zh: '喵喵喵' } },
      { e: '🦆', say: { key: 'animal_duck', zh: '小鸭', en: 'duck' }, sound: { key: 'animal_duck_sound', zh: '嘎嘎嘎' } },
      { e: '🐮', say: { key: 'animal_cow', zh: '奶牛', en: 'cow' }, sound: { key: 'animal_cow_sound', zh: '哞哞哞' } },
      { e: '🐷', say: { key: 'animal_pig', zh: '小猪', en: 'pig' }, sound: { key: 'animal_pig_sound', zh: '哼哼哼' } },
      { e: '🐑', say: { key: 'animal_sheep', zh: '小羊', en: 'sheep' }, sound: { key: 'animal_sheep_sound', zh: '咩咩咩' } },
      { e: '🐤', say: { key: 'animal_chick', zh: '小鸡', en: 'chick' }, sound: { key: 'animal_chick_sound', zh: '叽叽叽' } },
      { e: '🐸', say: { key: 'animal_frog', zh: '青蛙', en: 'frog' }, sound: { key: 'animal_frog_sound', zh: '呱呱呱' } },
      { e: '🦁', say: { key: 'animal_lion', zh: '狮子', en: 'lion' }, sound: { key: 'animal_lion_sound', zh: '嗷呜' } },
      { e: '🐴', say: { key: 'animal_horse', zh: '小马', en: 'horse' }, sound: { key: 'animal_horse_sound', zh: '嘚嘚嘚' } }
    ] },
    { id: 'color', icon: '🎨', say: { key: 'item_colors', zh: '颜色', en: 'colors' }, cards: [
      { c: '#EF4444', say: { key: 'color_red', zh: '红色', en: 'red' } },
      { c: '#FB923C', say: { key: 'color_orange', zh: '橙色', en: 'orange' } },
      { c: '#FACC15', say: { key: 'color_yellow', zh: '黄色', en: 'yellow' } },
      { c: '#4ADE80', say: { key: 'color_green', zh: '绿色', en: 'green' } },
      { c: '#3B82F6', say: { key: 'color_blue', zh: '蓝色', en: 'blue' } },
      { c: '#A78BFA', say: { key: 'color_purple', zh: '紫色', en: 'purple' } },
      { c: '#F9A8D4', say: { key: 'color_pink', zh: '粉色', en: 'pink' } },
      { c: '#A47148', say: { key: 'color_brown', zh: '棕色', en: 'brown' } }
    ] },
    { id: 'shape', icon: shapeSVG('<path d="M50 8 L92 86 L8 86 Z"/>', '#4AA3EE'), say: { key: 'item_shapes', zh: '形状', en: 'shapes' }, cards: [
      { s: shapeSVG('<circle cx="50" cy="50" r="42"/>', '#EF4444'), say: { key: 'shape_circle', zh: '圆形', en: 'circle' } },
      { s: shapeSVG('<rect x="10" y="10" width="80" height="80" rx="4"/>', '#3B82F6'), say: { key: 'shape_square', zh: '正方形', en: 'square' } },
      { s: shapeSVG('<path d="M50 8 L94 88 L6 88 Z"/>', '#4ADE80'), say: { key: 'shape_triangle', zh: '三角形', en: 'triangle' } },
      { s: shapeSVG('<rect x="4" y="24" width="92" height="52" rx="4"/>', '#FB923C'), say: { key: 'shape_rectangle', zh: '长方形', en: 'rectangle' } },
      { s: shapeSVG('<polygon points="50,6 61,38 95,38 68,58 78,92 50,72 22,92 32,58 5,38 39,38"/>', '#FACC15'), say: { key: 'shape_star', zh: '星形', en: 'star' } },
      { s: shapeSVG('<path d="M50 90 C20 68 6 50 6 32 C6 18 17 8 30 8 C40 8 46 14 50 22 C54 14 60 8 70 8 C83 8 94 18 94 32 C94 50 80 68 50 90 Z"/>', '#F472B6'), say: { key: 'shape_heart', zh: '心形', en: 'heart' } },
      { s: shapeSVG('<ellipse cx="50" cy="50" rx="45" ry="30"/>', '#A78BFA'), say: { key: 'shape_oval', zh: '椭圆形', en: 'oval' } },
      { s: shapeSVG('<path d="M50 4 L88 50 L50 96 L12 50 Z"/>', '#2DB7C4'), say: { key: 'shape_diamond', zh: '菱形', en: 'diamond' } }
    ] },
    { id: 'vehicle', icon: '🚗', say: { key: 'item_vehicles', zh: '交通工具', en: 'vehicles' }, cards: [
      { e: '🚗', say: { key: 'vehicle_car', zh: '小汽车', en: 'car' } },
      { e: '🚌', say: { key: 'vehicle_bus', zh: '公交车', en: 'bus' } },
      { e: '🚂', say: { key: 'vehicle_train', zh: '火车', en: 'train' } },
      { e: '✈️', say: { key: 'vehicle_plane', zh: '飞机', en: 'plane' } },
      { e: '🚢', say: { key: 'vehicle_ship', zh: '轮船', en: 'ship' } },
      { e: '🚲', say: { key: 'vehicle_bike', zh: '自行车', en: 'bike' } },
      { e: '🚒', say: { key: 'vehicle_fire_truck', zh: '消防车', en: 'fire truck' } },
      { e: '🚁', say: { key: 'vehicle_helicopter', zh: '直升机', en: 'helicopter' } },
      { e: '🚀', say: { key: 'vehicle_rocket', zh: '火箭', en: 'rocket' } }
    ] },
    { id: 'fruit', icon: '🍎', say: { key: 'item_fruits', zh: '水果', en: 'fruits' }, cards: [
      { e: '🍎', say: { key: 'food_apple', zh: '苹果', en: 'apple' } },
      { e: '🍌', say: { key: 'food_banana', zh: '香蕉', en: 'banana' } },
      { e: '🍇', say: { key: 'food_grapes', zh: '葡萄', en: 'grapes' } },
      { e: '🍊', say: { key: 'food_orange', zh: '橙子', en: 'orange' } },
      { e: '🍓', say: { key: 'food_strawberry', zh: '草莓', en: 'strawberry' } },
      { e: '🍉', say: { key: 'food_watermelon', zh: '西瓜', en: 'watermelon' } },
      { e: '🍐', say: { key: 'food_pear', zh: '梨', en: 'pear' } },
      { e: '🍑', say: { key: 'food_peach', zh: '桃子', en: 'peach' } },
      { e: '🍒', say: { key: 'food_cherry', zh: '樱桃', en: 'cherry' } },
      { e: '🍍', say: { key: 'food_pineapple', zh: '菠萝', en: 'pineapple' } }
    ] }
  ];

  var PROMPT_PICK = { key: 'prompt_cards_1', zh: '选一组卡片吧' };
  var PROMPT_FLIP = { key: 'prompt_cards_2', zh: '点一点卡片，翻开看看' };

  var main = document.getElementById('main');
  var screen = 'pick';
  var cat = null, idx = 0, flipped = false, lastCat = 0;
  var cardEl = null, stageEl = null, swiped = false;

  function picHTML(c) {
    if (c.e) return '<div class="pic">' + c.e + '</div>';
    if (c.c) return '<div class="pic"><div class="blob" style="background:' + c.c + '"></div></div>';
    return '<div class="pic">' + c.s + '</div>';
  }

  /* ---------- 类别选择 ---------- */
  function renderPicker() {
    screen = 'pick';
    var html = '<div class="cards-top kg-prompt">' + KG.dogSVG('happy', 64) + '<div class="kg-bubble">选一组卡片吧</div></div><div class="cats">';
    CATS.forEach(function (c, i) {
      html += '<button class="cat" data-nav data-i="' + i + '"><span class="cat-ico">' + c.icon + '</span><span class="cat-name"></span></button>';
    });
    html += '</div>';
    main.innerHTML = html;
    Array.prototype.forEach.call(main.querySelectorAll('.cat'), function (b) {
      var i = +b.getAttribute('data-i');
      b.querySelector('.cat-name').textContent = CATS[i].say.zh;
      b.addEventListener('click', function () { KG.sfx('tap'); openCat(i); });
    });
    KG.nav.refresh(main.querySelectorAll('.cat')[lastCat]);
  }

  /* ---------- 卡片浏览 ---------- */
  var ARROW_L = '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var ARROW_R = '<svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function openCat(i) {
    screen = 'view';
    lastCat = i;
    cat = CATS[i];
    idx = 0;
    main.innerHTML = '<div class="cv">'
      + '<button class="arrow prev" aria-label="上一张">' + ARROW_L + '</button>'
      + '<div class="stage"><button class="card" data-nav data-autofocus><div class="inner">'
      + '<div class="face back">' + KG.dogSVG('happy', 120) + '<div class="q">?</div></div>'
      + '<div class="face front"></div></div></button></div>'
      + '<button class="arrow next" aria-label="下一张">' + ARROW_R + '</button>'
      + '</div><div class="dots"></div>';
    cardEl = main.querySelector('.card');
    stageEl = main.querySelector('.stage');
    main.querySelector('.prev').addEventListener('click', function () { go(-1); });
    main.querySelector('.next').addEventListener('click', function () { go(1); });
    cardEl.addEventListener('click', function () {
      if (swiped) { swiped = false; return; }
      flip();
    });
    bindSwipe(stageEl);
    showCard(0);
    KG.nav.refresh(cardEl);
    KG.sayAll([cat.say, PROMPT_FLIP]);
  }

  function showCard(dir) {
    var c = cat.cards[idx];
    // 先瞬间翻回背面，再换内容，避免翻转过程中露出下一张
    cardEl.classList.add('instant');
    cardEl.classList.remove('flipped');
    flipped = false;
    var front = cardEl.querySelector('.front');
    front.innerHTML = picHTML(c) + '<div class="label"></div>';
    front.querySelector('.label').textContent = c.say.zh;
    void cardEl.offsetWidth;
    cardEl.classList.remove('instant');
    stageEl.classList.remove('slide-l', 'slide-r');
    if (dir) {
      void stageEl.offsetWidth;
      stageEl.classList.add(dir > 0 ? 'slide-l' : 'slide-r');
    }
    var dots = '';
    for (var i = 0; i < cat.cards.length; i++) dots += '<i' + (i === idx ? ' class="on"' : '') + '></i>';
    main.querySelector('.dots').innerHTML = dots;
  }

  function sayCard() {
    var c = cat.cards[idx];
    var items = [c.say];
    if (c.sound) items.push(c.sound);
    KG.sayAll(items);
  }

  function flip() {
    if (!flipped) {
      flipped = true;
      cardEl.classList.add('flipped');
      KG.sfx('pick');
    } else {
      var pic = cardEl.querySelector('.front .pic');
      pic.classList.remove('kg-pop');
      void pic.offsetWidth;
      pic.classList.add('kg-pop');
      KG.sfx('tap');
    }
    sayCard();
  }

  function go(d) {
    var n = cat.cards.length;
    idx = (idx + d + n) % n;
    KG.stopSay();
    KG.sfx('tap');
    showCard(d);
  }

  function bindSwipe(el) {
    var sx = 0, sy = 0, pid = null;
    el.addEventListener('pointerdown', function (e) {
      if (pid !== null) return;
      pid = e.pointerId; sx = e.clientX; sy = e.clientY; swiped = false;
    });
    function end(e) {
      if (e.pointerId !== pid) return;
      pid = null;
      var dx = e.clientX - sx, dy = e.clientY - sy;
      if (e.type === 'pointerup' && Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
        swiped = true;
        setTimeout(function () { swiped = false; }, 400);
        go(dx < 0 ? 1 : -1);
      }
    }
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
  }

  function backToPicker() {
    KG.stopSay();
    renderPicker();
  }

  /* ---------- 启动 ---------- */
  KG.init({
    id: 'cards',
    nav: true,
    onInput: function (key) {
      if (screen === 'view' && (key === 'left' || key === 'right')) {
        var cur = KG.nav.current();
        if (!cur || cur === cardEl) {
          go(key === 'right' ? 1 : -1);
          KG.nav.focus(cardEl);
          return true;
        }
      }
      return false;
    },
    onBack: function () {
      if (screen === 'view') { backToPicker(); return true; }
      return false;
    },
    onPause: function () {},
    onResume: function () {}
  });
  var header = KG.mountHeader('认知卡片');
  // 浏览卡片时，顶栏返回键先回到类别选择
  header.addEventListener('click', function (e) {
    if (screen === 'view' && e.target.closest && e.target.closest('.kg-back')) {
      e.stopPropagation();
      backToPicker();
    }
  }, true);

  renderPicker();
  KG.say(PROMPT_PICK);
})();
