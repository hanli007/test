/* 24 点：有理数运算与穷举求解（纯逻辑；node 下可直接 require 测试）。
 * 规则与游戏一致：减法结果不能为负，不能除以 0；intOnly 时每一步都必须是整数（简单模式）。 */
(function (root) {
  'use strict';

  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { var t = a % b; a = b; b = t; } return a || 1; }
  function R(n, d) {
    if (d === undefined) d = 1;
    if (d < 0) { n = -n; d = -d; }
    var g = gcd(n, d);
    return { n: n / g, d: d / g };
  }
  var OPS = ['+', '-', '*', '/'];
  /** 计算 a op b，不合法（负数、除以 0、简单模式下非整数）返回 null。 */
  function apply(a, op, b, intOnly) {
    var r;
    if (op === '+') r = R(a.n * b.d + b.n * a.d, a.d * b.d);
    else if (op === '-') r = R(a.n * b.d - b.n * a.d, a.d * b.d);
    else if (op === '*') r = R(a.n * b.n, a.d * b.d);
    else { if (b.n === 0) return null; r = R(a.n * b.d, a.d * b.n); }
    if (r.n < 0) return null;
    if (intOnly && r.d !== 1) return null;
    return r;
  }
  function is24(v) { return v.d === 1 && v.n === 24; }

  /** 返回第一步 {i, j, op}（i op j，按下标），没有解返回 null。 */
  function firstStep(vals, intOnly) {
    if (vals.length === 1) return is24(vals[0]) ? { done: true } : null;
    for (var i = 0; i < vals.length; i++) {
      for (var j = 0; j < vals.length; j++) {
        if (i === j) continue;
        for (var k = 0; k < OPS.length; k++) {
          var op = OPS[k];
          if ((op === '+' || op === '*') && j < i) continue; // 交换律，少算一半
          var r = apply(vals[i], op, vals[j], intOnly);
          if (!r) continue;
          var rest = [];
          for (var m = 0; m < vals.length; m++) if (m !== i && m !== j) rest.push(vals[m]);
          rest.push(r);
          if (firstStep(rest, intOnly)) return { i: i, j: j, op: op, r: r };
        }
      }
    }
    return null;
  }
  function solvable(vals, intOnly) { return !!firstStep(vals, intOnly); }

  /** 生成一手可解的牌（1–10）；intOnly 时保证存在每步都是整数的解法。avoid 为已出过的手牌键。 */
  function generate(intOnly, avoid) {
    avoid = avoid || {};
    var nums = null;
    for (var t = 0; t < 500; t++) {
      nums = [];
      for (var i = 0; i < 4; i++) nums.push(1 + Math.floor(Math.random() * 10));
      var key = nums.slice().sort(function (a, b) { return a - b; }).join(',');
      if (avoid[key] && t < 400) continue;
      if (solvable(nums.map(function (n) { return R(n, 1); }), intOnly)) return nums;
    }
    return [3, 8, 1, 1];
  }

  function fmt(v) { return v.d === 1 ? String(v.n) : v.n + '/' + v.d; }

  var api = { R: R, apply: apply, firstStep: firstStep, solvable: solvable, generate: generate, fmt: fmt, is24: is24 };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.TFCore = api;
})(this);
