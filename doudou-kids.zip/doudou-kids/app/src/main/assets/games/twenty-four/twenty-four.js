/* 24 点：选两张牌和一个运算，结果变成新牌，最后一张是 24 就成功。只出有解的牌。 */
(function () {
  'use strict';
  var KG = window.KidsGame, C = window.TFCore;

  var profile = KG.init({ id: 'twenty-four', nav: true, onBack: onBack });
  var saved = KG.load() || {};
  var easy = saved.easy !== undefined ? !!saved.easy : ((+profile.age || 9) < 10 && profile.ageTier !== 'sn');

  KG.mountHeader('24 点', '<button class="kg-chip tf-hbtn" data-nav id="modeBtn"></button><span class="kg-chip" id="score"></span>');
  var $modeBtn = document.getElementById('modeBtn'), $score = document.getElementById('score');
  var $msg = document.getElementById('msg'), $cards = document.getElementById('cards');
  var $expr = document.getElementById('expr'), $ops = document.getElementById('ops');
  var OP_TXT = { '+': '+', '-': '−', '*': '×', '/': '÷' };

  var hand = [], cards = [], history = [], sel = null, op = null, hints = 0, nextId = 1, done = false;
  var seenHands = {};

  function renderMode() { $modeBtn.textContent = easy ? '简单' : '挑战'; }
  function renderScore() { $score.textContent = '已完成 ' + (saved.solved || 0); }
  $modeBtn.addEventListener('click', function () {
    KG.sfx('tap');
    easy = !easy;
    saved = KG.load() || {};
    saved.easy = easy;
    KG.save(saved);
    renderMode();
    newHand();
    setMsg(easy ? '简单模式：每一步都能算出整数' : '挑战模式：有的题要用到分数哦');
  });

  function valHtml(v) {
    return v.d === 1 ? String(v.n) : '<span class="tf-fr"><span>' + v.n + '</span><span>' + v.d + '</span></span>';
  }
  function setMsg(t) { $msg.textContent = t; }

  function newHand() {
    hand = C.generate(easy, seenHands);
    seenHands[hand.slice().sort(function (a, b) { return a - b; }).join(',')] = 1;
    hints = 0;
    startHand();
    KG.say({ key: 'prompt_twentyfour_1', zh: '用这四个数，加减乘除，算出二十四' });
  }
  function startHand() {
    cards = hand.map(function (n) { return { id: nextId++, v: C.R(n, 1), expr: '' }; });
    history = []; sel = null; op = null; done = false;
    setMsg('点一张牌，再点运算符，再点另一张牌');
    render();
    KG.nav.refresh($cards.firstChild);
  }

  function render(newId) {
    $cards.innerHTML = cards.map(function (c) {
      var cls = 'tf-card' + (c.id === sel ? ' sel' : '') + (c.id === newId ? ' new' : '') + (cards.length === 1 && C.is24(c.v) ? ' goal' : '');
      return '<button class="' + cls + '" data-nav data-id="' + c.id + '"><span>' + valHtml(c.v) + '</span>' + (c.expr ? '<small>' + c.expr + '</small>' : '') + '</button>';
    }).join('');
    Array.prototype.forEach.call($ops.children, function (b) { b.classList.toggle('on', b.getAttribute('data-op') === op); });
    var s = byId(sel);
    if (s) $expr.innerHTML = '<span>' + valHtml(s.v) + '</span>' + (op ? '<span>' + OP_TXT[op] + '</span><span class="q">?</span>' : '');
    else if (!history.length) $expr.innerHTML = '';
  }
  function byId(id) {
    for (var i = 0; i < cards.length; i++) if (cards[i].id === id) return cards[i];
    return null;
  }
  function focusCard(id) {
    if (!KG.nav.enabled) return;
    KG.nav.refresh($cards.querySelector('[data-id="' + id + '"]') || $cards.firstChild);
  }

  $cards.addEventListener('click', function (e) {
    var b = e.target.closest('[data-id]'); if (!b || done || KG.paused) return;
    var c = byId(+b.getAttribute('data-id')); if (!c) return;
    clearHint();
    if (sel === null || (op === null && c.id !== sel)) { sel = c.id; KG.sfx('pick'); render(); focusCard(c.id); return; }
    if (c.id === sel) { sel = null; op = null; KG.sfx('tap'); $expr.innerHTML = ''; render(); focusCard(c.id); return; }
    combine(byId(sel), op, c);
  });

  $ops.addEventListener('click', function (e) {
    var b = e.target.closest('[data-op]'); if (!b || done || KG.paused) return;
    if (sel === null) { setMsg('先点一张牌，再选运算符'); KG.shake($cards); return; }
    var o = b.getAttribute('data-op');
    op = op === o ? null : o;
    KG.sfx('tap');
    render();
    // 遥控器：选好运算符后焦点回到牌上，方便选第二张
    if (op && KG.nav.enabled) {
      var other = cards.filter(function (c) { return c.id !== sel; })[0];
      if (other) focusCard(other.id);
    }
  });

  function combine(a, o, b) {
    var r = C.apply(a.v, o, b.v, false);
    if (!r) {
      KG.sfx('drop');
      setMsg(o === '-' ? '不够减哦，换个顺序试试：先点大的数' : '不能除以 0 哦');
      KG.shake($cards.querySelector('[data-id="' + b.id + '"]'));
      return;
    }
    history.push(cards.map(function (c) { return { id: c.id, v: c.v, expr: c.expr }; }));
    var expr = C.fmt(a.v) + OP_TXT[o] + C.fmt(b.v);
    var nc = { id: nextId++, v: r, expr: expr };
    var idx = cards.indexOf(b);
    cards[idx] = nc;
    cards.splice(cards.indexOf(a), 1);
    $expr.innerHTML = '<span>' + valHtml(a.v) + '</span><span>' + OP_TXT[o] + '</span><span>' + valHtml(b.v) + '</span><span>=</span><span>' + valHtml(r) + '</span>';
    sel = null; op = null;
    KG.sfx('pop');
    if (cards.length === 1) {
      render(nc.id);
      if (C.is24(r)) win();
      else {
        setMsg('得到 ' + C.fmt(r) + '，不是 24。点撤销再换个算法试试');
        KG.say(KG.hintItem());
        if (KG.nav.enabled) KG.nav.refresh(document.querySelector('[data-tool="undo"]'));
      }
      return;
    }
    setMsg('还剩 ' + cards.length + ' 张牌，继续算');
    render(nc.id);
    focusCard(nc.id);
  }

  function clearHint() {
    Array.prototype.forEach.call($cards.querySelectorAll('.kg-hint'), function (x) { x.classList.remove('kg-hint'); });
  }

  document.getElementById('tools').addEventListener('click', function (e) {
    var b = e.target.closest('[data-tool]'); if (!b || KG.paused) return;
    var t = b.getAttribute('data-tool');
    KG.sfx('tap');
    if (t === 'new') { newHand(); return; }
    if (done) return;
    if (t === 'undo') {
      var h = history.pop();
      if (!h) { setMsg('已经是最开始的四张牌啦'); return; }
      cards = h; sel = null; op = null;
      $expr.innerHTML = '';
      setMsg('退回一步');
      render();
      KG.nav.refresh();
    } else if (t === 'hint') {
      hint();
    }
  });

  function hint() {
    var vals = cards.map(function (c) { return c.v; });
    var s = (easy && C.firstStep(vals, true)) || C.firstStep(vals, false);
    if (!s) {
      setMsg('这几张牌算不出 24 了，点撤销退回去试试');
      KG.say({ key: 'prompt_twentyfour_2', zh: '这条路走不通，退回去试试' });
      return;
    }
    if (s.done) return;
    hints++;
    var a = cards[s.i], b = cards[s.j];
    sel = null; op = null;
    render();
    var ea = $cards.querySelector('[data-id="' + a.id + '"]'), eb = $cards.querySelector('[data-id="' + b.id + '"]');
    ea.classList.add('kg-hint'); eb.classList.add('kg-hint');
    var text = C.fmt(a.v) + ' ' + OP_TXT[s.op] + ' ' + C.fmt(b.v);
    setMsg('试试先算 ' + text + ' = ' + C.fmt(s.r));
    KG.say({ zh: '试试先算 ' + C.fmt(a.v) + { '+': '加', '-': '减', '*': '乘', '/': '除以' }[s.op] + C.fmt(b.v) });
    focusCard(a.id);
  }

  function win() {
    done = true;
    var stars = hints === 0 ? 3 : (hints === 1 ? 2 : 1);
    var p = KG.recordStars(easy ? 'easy' : 'hard', stars);
    p.solved = (p.solved || 0) + 1;
    KG.save(p);
    saved = p;
    renderScore();
    setMsg('算出 24 啦！');
    setTimeout(function () {
      KG.showWin({
        title: profile.ageTier === 'sn' ? '24！' : '算出 24 啦！',
        text: hand.join('  ') + (hints ? '（用了 ' + hints + ' 次提示）' : '（没用提示）'),
        stars: stars,
        nextText: '下一题',
        onNext: newHand,
        replayText: '这题再算一次',
        onReplay: function () { hints = 0; startHand(); }
      });
    }, 600);
  }

  function onBack() {
    if (sel !== null) { sel = null; op = null; $expr.innerHTML = ''; render(); return true; }
    return false;
  }

  renderMode();
  renderScore();
  newHand();
})();
