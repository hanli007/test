/* 编程闯关：用积木排程序，点运行让小狗一步步走，找到骨头就过关。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var profile = KG.init({ id: 'code-maze', nav: true, onBack: onBack, onPause: onPause, onResume: onResume });
  var saved = KG.load() || {};
  var mode = saved.mode || (profile.ageTier === 'qm' ? 'abs' : 'rel'); // abs: ↑↓←→；rel: 前进/左转/右转

  KG.mountHeader('编程闯关',
    '<button class="kg-chip cm-hbtn" data-nav id="modeBtn"></button>' +
    '<button class="kg-chip cm-hbtn" data-nav id="levelBtn">关卡</button>');
  var $modeBtn = document.getElementById('modeBtn'), $levelBtn = document.getElementById('levelBtn');
  var $levels = document.getElementById('levels'), $levelGrid = document.getElementById('levelGrid');
  var $game = document.getElementById('game'), $msg = document.getElementById('msg');
  var $wrap = document.getElementById('mazeWrap'), $maze = document.getElementById('maze');
  var $right = document.getElementById('right'), $prog = document.getElementById('prog');
  var $count = document.getElementById('count'), $palette = document.getElementById('palette');
  var $run = document.getElementById('runBtn');

  var DIRS = { N: [-1, 0], E: [0, 1], S: [1, 0], W: [0, -1] };
  var ORDER = ['N', 'E', 'S', 'W'];
  var ABS = { U: 'N', D: 'S', L: 'W', R: 'E' };
  var BLOCKS = {
    U: { ic: '↑', label: '上', cls: 'c-move' },
    D: { ic: '↓', label: '下', cls: 'c-move' },
    L: { ic: '←', label: '左', cls: 'c-move' },
    R: { ic: '→', label: '右', cls: 'c-move' },
    F: { ic: '⬆', label: '前进', cls: 'c-move' },
    TL: { ic: '↺', label: '左转', cls: 'c-turn' },
    TR: { ic: '↻', label: '右转', cls: 'c-turn' },
    loop: { ic: '🔁', label: '重复', cls: 'c-loop' },
    end: { ic: '⏹', label: '结束', cls: 'c-end' }
  };
  var STEP_MS = 520;

  var levels = [], lv = null, lvIdx = 0;
  var grid = null, off = 0, rows = 0, cols = 0, cell = 40;
  var program = [], loopN = 3, runs = 0;
  var dog = { r: 0, c: 0, f: 'E', angle: 0 };
  var state = 'edit';     // edit | running | done（运行结束或撞墙，等待修改）
  var run = null;         // { cmds, i, timer, paused }
  var $dog = null, cellEls = [];
  var firstLoopIdx = -1;

  function loadJSON(url, ok, fail) {
    function xhr() {
      try {
        var x = new XMLHttpRequest();
        x.open('GET', url, true);
        x.onload = function () { try { ok(JSON.parse(x.responseText)); } catch (e) { fail(e); } };
        x.onerror = function () { fail(new Error('xhr ' + url)); };
        x.send();
      } catch (e) { fail(e); }
    }
    if (window.fetch) fetch(url).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }).then(ok, xhr);
    else xhr();
  }

  /* ---------- 模式 ---------- */
  function renderModeBtn() { $modeBtn.textContent = mode === 'abs' ? '↑↓ 方向' : '↻ 转向'; }
  $modeBtn.addEventListener('click', function () {
    KG.sfx('tap');
    mode = mode === 'abs' ? 'rel' : 'abs';
    saved = KG.load() || {};
    saved.mode = mode;
    KG.save(saved);
    renderModeBtn();
    if (lv) {
      stopRun();
      program = [];
      resetDog();
      renderPalette();
      renderProgram();
      setMsg(mode === 'abs' ? '方向模式：箭头指哪儿，小狗就往哪儿走' : '转向模式：小狗朝着箭头的方向前进');
      KG.say(mode === 'abs'
        ? { key: 'prompt_codemaze_1', zh: '用箭头积木排好路线，再点运行，带小狗找到骨头' }
        : { key: 'prompt_codemaze_2', zh: '用前进和转弯积木排好路线，再点运行' });
    }
  });

  /* ---------- 选关 ---------- */
  function starsHtml(n) {
    var s = '';
    for (var k = 1; k <= 3; k++) s += '<i' + (k <= n ? ' class="on"' : '') + '>★</i>';
    return s;
  }
  function showLevels() {
    stopRun();
    $game.hidden = true;
    $levels.hidden = false;
    var st = (KG.load() || {}).stars || {};
    $levelGrid.innerHTML = levels.map(function (l, i) {
      return '<button class="cm-lv' + (l.loop ? ' loop' : '') + (i === lvIdx ? ' cur' : '') + '" data-nav data-lv="' + i + '">'
        + '<b>' + l.id + '</b><small>' + starsHtml(st['L' + l.id] || 0) + '</small></button>';
    }).join('');
    KG.nav.refresh($levelGrid.children[lvIdx]);
  }
  $levelGrid.addEventListener('click', function (e) {
    var b = e.target.closest('[data-lv]'); if (!b) return;
    KG.sfx('tap');
    startLevel(+b.getAttribute('data-lv'));
  });
  $levelBtn.addEventListener('click', function () {
    KG.sfx('tap');
    if ($levels.hidden) showLevels();
    else if (lv) { $levels.hidden = true; $game.hidden = false; layout(); KG.nav.refresh($run); }
  });

  /* ---------- 关卡 ---------- */
  function startLevel(i) {
    stopRun();
    lvIdx = i;
    lv = levels[i];
    grid = lv.grid;
    // 外圈全是墙时不画外圈，格子更大
    var ring = true;
    for (var r = 0; r < grid.length; r++) for (var c = 0; c < grid[r].length; c++) {
      if ((r === 0 || c === 0 || r === grid.length - 1 || c === grid[r].length - 1) && grid[r][c] !== '#') ring = false;
    }
    off = ring && grid.length > 2 && grid[0].length > 2 ? 1 : 0;
    rows = grid.length - off * 2;
    cols = grid[0].length - off * 2;
    program = [];
    runs = 0;
    saved = KG.load() || {};
    saved.lastLevel = lv.id;
    KG.save(saved);

    $levels.hidden = true;
    $game.hidden = false;
    buildMaze();
    resetDog();
    renderPalette();
    renderProgram();
    layout();
    KG.nav.refresh($palette.firstChild);

    setMsg('第 ' + lv.id + ' 关 · ' + lv.name + '：带小狗找到骨头 🦴');
    if (i === firstLoopIdx) {
      setMsg('新积木「重复」：夹在「重复」和「结束」中间的积木会做好几次');
      KG.say({ key: 'prompt_codemaze_3', zh: '新积木重复，夹在重复和结束中间的积木，会做好几次' });
    } else if (i === 0) {
      KG.say(mode === 'abs'
        ? { key: 'prompt_codemaze_1', zh: '用箭头积木排好路线，再点运行，带小狗找到骨头' }
        : { key: 'prompt_codemaze_2', zh: '用前进和转弯积木排好路线，再点运行' });
    }
  }

  function findCell(ch) {
    for (var r = 0; r < grid.length; r++) { var c = grid[r].indexOf(ch); if (c >= 0) return [r, c]; }
    return [0, 0];
  }
  function isWall(r, c) { return r < 0 || r >= grid.length || c < 0 || c >= grid[r].length || grid[r][c] === '#'; }
  function cellEl(r, c) {
    var rr = r - off, cc = c - off;
    if (rr < 0 || cc < 0 || rr >= rows || cc >= cols) return null;
    return cellEls[rr * cols + cc];
  }

  function buildMaze() {
    var h = '';
    for (var r = off; r < off + rows; r++) {
      for (var c = off; c < off + cols; c++) {
        var ch = grid[r][c];
        h += '<div class="cm-cell ' + (ch === '#' ? 'w' : 'f') + '">' + (ch === 'B' ? '<span class="cm-bone">🦴</span>' : '') + '</div>';
      }
    }
    h += '<div class="cm-dog" id="dog"><span class="cm-face"></span>' + KG.dogSVG('happy', 40) + '</div>';
    $maze.innerHTML = h;
    cellEls = Array.prototype.slice.call($maze.querySelectorAll('.cm-cell'));
    $dog = document.getElementById('dog');
  }

  function layout() {
    if (!lv || $game.hidden) return;
    var w = $wrap.clientWidth - 4, h = $wrap.clientHeight - 4;
    cell = Math.max(22, Math.min(72, Math.floor(Math.min(w / cols, h / rows))));
    $maze.style.gridTemplateColumns = 'repeat(' + cols + ',' + cell + 'px)';
    $maze.style.gridAutoRows = cell + 'px';
    $maze.style.fontSize = cell + 'px';
    $dog.style.width = cell + 'px';
    $dog.style.height = cell + 'px';
    var svg = $dog.querySelector('svg');
    svg.setAttribute('width', Math.round(cell * 0.86));
    svg.setAttribute('height', Math.round(cell * 0.86));
    placeDog(false);
  }

  function placeDog(animate, dr, dc) {
    if (!$dog) return;
    if (!animate) $dog.style.transition = 'none';
    var y = (dog.r - off + (dr || 0)) * cell, x = (dog.c - off + (dc || 0)) * cell;
    $dog.style.transform = 'translate(' + x + 'px,' + y + 'px)';
    $dog.querySelector('.cm-face').style.transform = 'rotate(' + dog.angle + 'deg)';
    $dog.classList.toggle('noface', mode === 'abs');
    if (!animate) { void $dog.offsetWidth; $dog.style.transition = ''; }
  }

  function resetDog() {
    var s = findCell('S');
    dog.r = s[0]; dog.c = s[1];
    dog.f = mode === 'rel' ? (lv.face || 'E') : 'E';
    dog.angle = ORDER.indexOf(dog.f) * 90;
    cellEls.forEach(function (el) { el.classList.remove('trail', 'hit'); });
    if ($dog) $dog.classList.remove('win');
    placeDog(false);
    state = 'edit';
    markNow(-1);
  }

  /* ---------- 积木面板 ---------- */
  function renderPalette() {
    var keys = mode === 'abs' ? ['U', 'D', 'L', 'R'] : ['F', 'TL', 'TR'];
    var h = keys.map(function (k) {
      var b = BLOCKS[k];
      return '<button class="cm-pal ' + b.cls + '" data-nav data-add="' + k + '"><span class="ic">' + b.ic + '</span>' + (mode === 'rel' ? b.label : '') + '</button>';
    }).join('');
    if (lv && lv.loop) {
      h += '<button class="cm-pal c-loop" data-nav data-add="loop"><span class="ic">🔁</span><span id="loopLabel">重复 ' + loopN + ' 次</span></button>'
        + '<button class="cm-pal cm-n" data-nav data-add="n" aria-label="改变重复次数">次数 ' + loopN + ' ▸</button>'
        + '<button class="cm-pal c-end" data-nav data-add="end"><span class="ic">⏹</span>结束</button>';
    }
    $palette.innerHTML = h;
  }

  $palette.addEventListener('click', function (e) {
    var b = e.target.closest('[data-add]'); if (!b || KG.paused) return;
    var k = b.getAttribute('data-add');
    if (state === 'running') { busyHint(); return; }
    if (k === 'n') {
      KG.sfx('tap');
      loopN = loopN >= 9 ? 2 : loopN + 1;
      b.textContent = '次数 ' + loopN + ' ▸';
      var lbl = document.getElementById('loopLabel');
      if (lbl) lbl.textContent = '重复 ' + loopN + ' 次';
      return;
    }
    if (program.length >= lv.maxBlocks) {
      KG.sfx('drop');
      setMsg('积木用完啦，这一关最多 ' + lv.maxBlocks + ' 块' + (lv.loop ? '，试试用「重复」' : ''), true);
      KG.shake($count);
      return;
    }
    KG.sfx('pick');
    editStarted();
    program.push(k === 'loop' ? { t: 'loop', n: loopN } : { t: k });
    renderProgram();
    $prog.scrollLeft = $prog.scrollWidth;
    $prog.scrollTop = $prog.scrollHeight;
  });

  /* ---------- 程序区 ---------- */
  function renderProgram() {
    var depth = 0;
    $prog.innerHTML = program.map(function (b, i) {
      var d = BLOCKS[b.t];
      if (b.t === 'end' && depth > 0) depth--;
      var inCls = depth > 0 ? ' in' + Math.min(depth, 2) : '';
      if (b.t === 'loop') depth++;
      var body = b.t === 'loop' ? '<span>' + d.ic + '</span><small>×' + b.n + '</small>'
        : '<span>' + d.ic + '</span>' + (mode === 'rel' || b.t === 'end' ? '<small>' + d.label + '</small>' : '');
      return '<button class="cm-blk ' + d.cls + inCls + '" data-nav data-pi="' + i + '" aria-label="' + d.label + '，点一下删除">' + body + '</button>';
    }).join('');
    $count.textContent = program.length + '/' + lv.maxBlocks;
  }

  $prog.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pi]'); if (!b || KG.paused) return;
    if (state === 'running') { busyHint(); return; }
    var i = +b.getAttribute('data-pi');
    KG.sfx('drop');
    editStarted();
    program.splice(i, 1);
    renderProgram();
    var next = $prog.children[Math.min(i, program.length - 1)];
    if (KG.nav.enabled) KG.nav.refresh(next || $palette.firstChild);
  });

  $right.addEventListener('click', function (e) {
    var b = e.target.closest('[data-tool]'); if (!b || KG.paused) return;
    var t = b.getAttribute('data-tool');
    if (t === 'run') { KG.sfx('tap'); if (state === 'running') { stopRun(); resetDog(); setMsg('停下来啦，改一改再运行'); } else startRun(); return; }
    if (state === 'running') { busyHint(); return; }
    if (!program.length) return;
    KG.sfx('drop');
    editStarted();
    if (t === 'del') program.pop(); else program = [];
    renderProgram();
    if (KG.nav.enabled) KG.nav.refresh(b);
  });

  function busyHint() { setMsg('小狗正在走，点「停止」可以停下来'); }
  function editStarted() {
    if (state === 'done') resetDog();
    Array.prototype.forEach.call($prog.querySelectorAll('.err'), function (x) { x.classList.remove('err'); });
  }
  function setMsg(t, bad) {
    $msg.textContent = t;
    $msg.classList.toggle('bad', !!bad);
  }
  function markNow(pi) {
    Array.prototype.forEach.call($prog.querySelectorAll('.now'), function (x) { x.classList.remove('now'); });
    if (pi >= 0 && $prog.children[pi]) {
      var el = $prog.children[pi];
      el.classList.add('now');
      // 让正在执行的积木保持在可视范围内（不移动遥控器焦点）
      var pr = $prog.getBoundingClientRect(), er = el.getBoundingClientRect();
      if (er.right > pr.right) $prog.scrollLeft += er.right - pr.right + 8;
      else if (er.left < pr.left) $prog.scrollLeft -= pr.left - er.left + 8;
      if (er.bottom > pr.bottom) $prog.scrollTop += er.bottom - pr.bottom + 4;
      else if (er.top < pr.top) $prog.scrollTop -= pr.top - er.top + 4;
    }
  }

  /** 把积木展开成命令序列；未配对的「结束」忽略，没写「结束」的重复到程序末尾。 */
  function flatten(prog) {
    var out = [];
    function exec(i, end) {
      while (i < end) {
        var b = prog[i];
        if (b.t === 'loop') {
          var depth = 1, j = i + 1;
          while (j < end && depth) { if (prog[j].t === 'loop') depth++; else if (prog[j].t === 'end') depth--; if (depth) j++; }
          for (var k = 0; k < b.n && out.length < 400; k++) exec(i + 1, j);
          i = j + 1;
        } else {
          if (b.t !== 'end') out.push({ t: b.t, pi: i });
          i++;
        }
      }
    }
    exec(0, prog.length);
    return out;
  }

  /* ---------- 运行 ---------- */
  function startRun() {
    var cmds = flatten(program);
    if (!cmds.length) {
      setMsg('先点下面的积木，排一个程序吧');
      KG.shake($prog);
      return;
    }
    resetDog();
    Array.prototype.forEach.call($prog.querySelectorAll('.err'), function (x) { x.classList.remove('err'); });
    runs++;
    state = 'running';
    $right.classList.add('cm-busy');
    $run.textContent = '■ 停止';
    $run.classList.add('stop');
    setMsg('小狗出发啦！');
    run = { cmds: cmds, i: 0, timer: null, paused: false };
    schedule(250);
  }
  function schedule(ms) {
    if (!run) return;
    if (KG.paused) { run.paused = true; return; }
    run.timer = setTimeout(step, ms);
  }
  function stopRun() {
    if (run && run.timer) clearTimeout(run.timer);
    run = null;
    $right.classList.remove('cm-busy');
    $run.textContent = '▶ 运行';
    $run.classList.remove('stop');
    markNow(-1);
    if (state === 'running') state = 'edit';
  }
  function finishRun() {
    if (run && run.timer) clearTimeout(run.timer);
    run = null;
    $right.classList.remove('cm-busy');
    $run.textContent = '▶ 运行';
    $run.classList.remove('stop');
    state = 'done';
  }

  function step() {
    if (!run) return;
    run.timer = null;
    if (run.i >= run.cmds.length) {
      markNow(-1);
      finishRun();
      setMsg('程序走完了，还没到骨头哦。再加几块积木吧', true);
      KG.say({ key: 'prompt_codemaze_5', zh: '还没走到骨头哦，再加几块积木吧' });
      return;
    }
    var cmd = run.cmds[run.i++];
    markNow(cmd.pi);
    if (cmd.t === 'TL' || cmd.t === 'TR') {
      var d = cmd.t === 'TL' ? -1 : 1;
      dog.f = ORDER[(ORDER.indexOf(dog.f) + 4 + d) % 4];
      dog.angle += d * 90;
      KG.sfx('tap');
      placeDog(true);
      schedule(STEP_MS);
      return;
    }
    var dir = DIRS[cmd.t === 'F' ? dog.f : ABS[cmd.t]];
    var nr = dog.r + dir[0], nc = dog.c + dir[1];
    if (isWall(nr, nc)) { crash(cmd.pi, nr, nc, dir); return; }
    var here = cellEl(dog.r, dog.c);
    if (here) here.classList.add('trail');
    dog.r = nr; dog.c = nc;
    KG.sfx('drop');
    placeDog(true);
    if (grid[nr][nc] === 'B') {
      var p = run;
      finishRun();
      markNow(-1);
      if (p) win();
      return;
    }
    schedule(STEP_MS);
  }

  function crash(pi, nr, nc, dir) {
    finishRun();
    var blk = $prog.children[pi];
    if (blk) { blk.classList.add('err'); blk.classList.remove('now'); }
    var wall = cellEl(nr, nc);
    if (wall) wall.classList.add('hit');
    placeDog(true, dir[0] * 0.3, dir[1] * 0.3);
    setTimeout(function () { placeDog(true); }, 200);
    KG.sfx('wrong');
    setMsg('第 ' + (pi + 1) + ' 块积木让小狗撞墙啦，改一改再试试', true);
    KG.say({ key: 'prompt_codemaze_4', zh: '撞到墙啦，改一改再试试' });
  }

  function win() {
    $dog.classList.add('win');
    var stars = runs <= 1 ? 3 : (runs <= 3 ? 2 : 1);
    KG.recordStars('L' + lv.id, stars);
    var hasNext = lvIdx < levels.length - 1;
    var idx = lvIdx;
    setMsg('找到骨头啦！');
    setTimeout(function () {
      KG.showWin({
        stars: stars,
        text: '第 ' + lv.id + ' 关完成，用了 ' + program.length + ' 块积木' + (runs > 1 ? '，试了 ' + runs + ' 次' : ''),
        onReplay: function () { startLevel(idx); },
        onNext: hasNext ? function () { startLevel(idx + 1); } : function () { showLevels(); },
        nextText: hasNext ? '下一关' : '选关卡'
      });
    }, 500);
  }

  /* ---------- 生命周期 ---------- */
  function onBack() {
    if (!$levels.hidden && lv) { $levels.hidden = true; $game.hidden = false; layout(); KG.nav.refresh($run); return true; }
    return false;
  }
  function onPause() {
    if (run && run.timer) { clearTimeout(run.timer); run.timer = null; run.paused = true; }
  }
  function onResume() {
    if (run && run.paused) { run.paused = false; run.timer = setTimeout(step, 400); }
  }

  var resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(layout, 120);
  });

  renderModeBtn();
  loadJSON('levels.json', function (data) {
    levels = data.levels || [];
    for (var i = 0; i < levels.length; i++) if (levels[i].loop) { firstLoopIdx = i; break; }
    // 从第一个还没拿到星的关卡开始
    var st = (KG.load() || {}).stars || {};
    var start = 0;
    while (start < levels.length - 1 && st['L' + levels[start].id]) start++;
    startLevel(start);
  }, function (err) {
    KG.log('levels.json 加载失败：' + err);
    $game.hidden = false;
    setMsg('关卡加载失败，请返回重试', true);
  });
})();
