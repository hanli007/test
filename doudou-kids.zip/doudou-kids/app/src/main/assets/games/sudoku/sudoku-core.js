/*
 * 数独核心：生成、唯一解检查（回溯求解）、只用「唯一数 / 隐性唯一数」能否解出的难度检查。
 * 浏览器中挂到 window.SudokuCore；Node 中 module.exports（供 tools 下的检查脚本使用）。
 * 盘面用长度 n*n 的数组表示，0 为空格，1..n 为数字。
 */
(function (root) {
  'use strict';

  /** 宫的尺寸 [行数, 列数] */
  function boxDims(n) { return n === 4 ? [2, 2] : (n === 6 ? [2, 3] : [3, 3]); }

  var cache = {};
  function units(n) {
    if (cache[n]) return cache[n];
    var bd = boxDims(n), br = bd[0], bc = bd[1], perRow = n / bc;
    var u = { rowOf: [], colOf: [], boxOf: [], peers: [], all: [] };
    var i, j;
    for (i = 0; i < n * n; i++) {
      var r = Math.floor(i / n), c = i % n;
      u.rowOf.push(r); u.colOf.push(c);
      u.boxOf.push(Math.floor(r / br) * perRow + Math.floor(c / bc));
    }
    for (i = 0; i < n * n; i++) {
      var p = [];
      for (j = 0; j < n * n; j++) {
        if (j !== i && (u.rowOf[j] === u.rowOf[i] || u.colOf[j] === u.colOf[i] || u.boxOf[j] === u.boxOf[i])) p.push(j);
      }
      u.peers.push(p);
    }
    for (var k = 0; k < n; k++) {
      var row = [], col = [], box = [];
      for (i = 0; i < n * n; i++) {
        if (u.rowOf[i] === k) row.push(i);
        if (u.colOf[i] === k) col.push(i);
        if (u.boxOf[i] === k) box.push(i);
      }
      u.all.push(row, col, box);
    }
    cache[n] = u;
    return u;
  }

  function pop(m) { var c = 0; while (m) { m &= m - 1; c++; } return c; }
  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function range(n) { var a = []; for (var i = 0; i < n; i++) a.push(i); return a; }

  /**
   * 回溯搜索（每步选候选数最少的格子）。最多找 limit 个解。
   * rnd 为 true 时随机尝试顺序（用来生成终盘）。返回 {count, first}。
   */
  function search(g, n, limit, rnd) {
    var u = units(n), a = g.slice(), full = (1 << n) - 1;
    var rm = [], cm = [], bm = [], i;
    for (i = 0; i < n; i++) { rm.push(0); cm.push(0); bm.push(0); }
    for (i = 0; i < a.length; i++) {
      if (!a[i]) continue;
      var bit0 = 1 << (a[i] - 1);
      if ((rm[u.rowOf[i]] | cm[u.colOf[i]] | bm[u.boxOf[i]]) & bit0) return { count: 0, first: null };
      rm[u.rowOf[i]] |= bit0; cm[u.colOf[i]] |= bit0; bm[u.boxOf[i]] |= bit0;
    }
    var count = 0, first = null;
    function rec() {
      var best = -1, bestM = 0, bestC = 99;
      for (var k = 0; k < a.length; k++) {
        if (a[k]) continue;
        var m = full & ~(rm[u.rowOf[k]] | cm[u.colOf[k]] | bm[u.boxOf[k]]);
        var cnt = pop(m);
        if (cnt === 0) return;
        if (cnt < bestC) { bestC = cnt; best = k; bestM = m; if (cnt === 1) break; }
      }
      if (best < 0) { count++; if (!first) first = a.slice(); return; }
      var ds = [];
      for (var d = 0; d < n; d++) if (bestM & (1 << d)) ds.push(d);
      if (rnd) shuffle(ds);
      var r = u.rowOf[best], c = u.colOf[best], b = u.boxOf[best];
      for (var t = 0; t < ds.length; t++) {
        var bit = 1 << ds[t];
        a[best] = ds[t] + 1; rm[r] |= bit; cm[c] |= bit; bm[b] |= bit;
        rec();
        a[best] = 0; rm[r] &= ~bit; cm[c] &= ~bit; bm[b] &= ~bit;
        if (count >= limit) return;
      }
    }
    rec();
    return { count: count, first: first };
  }

  function countSolutions(g, n, limit) { return search(g, n, limit || 2, false).count; }
  function solve(g, n) { return search(g, n, 1, false).first; }

  /** 当前盘面下某格的候选数位掩码 */
  function candidates(a, n, k) {
    var u = units(n), m = (1 << n) - 1, p = u.peers[k];
    for (var i = 0; i < p.length; i++) if (a[p[i]]) m &= ~(1 << (a[p[i]] - 1));
    return m;
  }

  /** 只用唯一数（naked single）和隐性唯一数（hidden single）能否解出。 */
  function solvableBySingles(g, n) {
    var u = units(n), a = g.slice(), progress = true, k, m;
    while (progress) {
      progress = false;
      var empty = 0;
      for (k = 0; k < a.length; k++) {
        if (a[k]) continue;
        m = candidates(a, n, k);
        if (m === 0) return false;
        if (pop(m) === 1) {
          for (var d = 0; d < n; d++) if (m === (1 << d)) a[k] = d + 1;
          progress = true;
        } else empty++;
      }
      if (empty === 0) break;
      if (progress) continue;
      for (var ui = 0; ui < u.all.length; ui++) {
        var unit = u.all[ui];
        for (var dd = 0; dd < n; dd++) {
          var bit = 1 << dd, place = -1, cnt = 0;
          for (var t = 0; t < unit.length; t++) {
            k = unit[t];
            if (a[k] === dd + 1) { cnt = -1; break; }
            if (!a[k] && (candidates(a, n, k) & bit)) { cnt++; place = k; }
          }
          if (cnt === 1) { a[place] = dd + 1; progress = true; }
        }
      }
    }
    for (k = 0; k < a.length; k++) if (!a[k]) return false;
    return true;
  }

  /*
   * 难度：target 为目标提示数；singles 要求只用基础技巧可解；
   * notSingles 尽量要求基础技巧解不出（多试几次，取不到就用最后一盘）。
   */
  var LEVELS = {
    intro4: { name: '入门 4×4', n: 4, target: 6, singles: true },
    intro6: { name: '入门 6×6', n: 6, target: 16, singles: true },
    easy: { name: '简单', n: 9, target: 38, singles: true },
    medium: { name: '中等', n: 9, target: 30 },
    hard: { name: '困难', n: 9, target: 25, notSingles: true, tries: 5 }
  };
  var LEVEL_ORDER = ['intro4', 'intro6', 'easy', 'medium', 'hard'];

  function zeros(len) { var a = []; for (var i = 0; i < len; i++) a.push(0); return a; }

  function generate(level) {
    var cfg = LEVELS[level] || LEVELS.easy, n = cfg.n, last = null;
    var tries = cfg.tries || 1;
    for (var attempt = 0; attempt < tries; attempt++) {
      var sol = search(zeros(n * n), n, 1, true).first;
      var puz = sol.slice(), givens = n * n;
      var order = shuffle(range(n * n));
      for (var i = 0; i < order.length && givens > cfg.target; i++) {
        var idx = order[i], v = puz[idx];
        puz[idx] = 0;
        // 只用基础技巧可解必然唯一解；否则用回溯求解器数解的个数
        var ok = cfg.singles ? solvableBySingles(puz, n) : countSolutions(puz, n, 2) === 1;
        if (ok) givens--; else puz[idx] = v;
      }
      last = { level: level, n: n, puzzle: puz, solution: sol, givens: givens };
      if (!cfg.notSingles || !solvableBySingles(puz, n)) return last;
    }
    return last;
  }

  var api = {
    boxDims: boxDims, units: units, countSolutions: countSolutions, solve: solve,
    solvableBySingles: solvableBySingles, candidates: candidates, generate: generate,
    LEVELS: LEVELS, LEVEL_ORDER: LEVEL_ORDER
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SudokuCore = api;
})(this);
