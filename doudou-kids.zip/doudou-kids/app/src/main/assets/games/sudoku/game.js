/* 数独：触屏点格子 + 底部数字栏；遥控器方向键移动光标，OK 跳到数字栏选数字。 */
(function () {
  'use strict';
  var KG = window.KidsGame, S = window.SudokuCore;
  var LV_DESC = { intro4: '4×4 小盘', intro6: '6×6 小盘', easy: '9×9 · 只需基础推理', medium: '9×9 · 提示数更少', hard: '9×9 · 需要更多技巧' };

  var main = document.getElementById('main');
  var wrap = document.getElementById('wrap');
  var boardEl = document.getElementById('board');
  var padEl = document.getElementById('pad');
  var infoEl = document.getElementById('info');
  var tNotes = document.getElementById('tNotes');

  /* game: {level, n, puzzle, sol, vals, notes, hinted, hints} */
  var game = null, sel = 0, notesMode = false, undoStack = [], cells = [];

  KG.init({ id: 'sudoku', nav: true, onInput: onInput, onBack: onBack, onPause: save, onResume: function () { render(); } });
  KG.mountHeader('数独', '<button class="kg-chip" data-nav id="btnNew">新局</button>');
  document.getElementById('btnNew').addEventListener('click', function () { showMenu(!!game); });

  /* ---------- 存档 ---------- */
  function save() {
    var d = KG.load() || {};
    d.cur = game ? {
      level: game.level, n: game.n, puzzle: game.puzzle, sol: game.sol, vals: game.vals,
      notes: game.notes, hinted: game.hinted, hints: game.hints, sel: sel
    } : null;
    KG.save(d);
  }

  /* ---------- 开局 ---------- */
  function startGame(level) {
    game = null;
    boardEl.innerHTML = '';
    padEl.innerHTML = '';
    infoEl.innerHTML = '<span class="sd-gen">正在出题…</span>';
    setTimeout(function () {
      var g = S.generate(level);
      var zeros = g.puzzle.map(function () { return 0; });
      game = {
        level: level, n: g.n, puzzle: g.puzzle, sol: g.solution, vals: g.puzzle.slice(),
        notes: zeros.slice(), hinted: zeros.slice(), hints: 0
      };
      sel = firstEmpty();
      undoStack = [];
      notesMode = false;
      build();
      save();
      KG.sfx('pop');
    }, 30);
  }
  function firstEmpty() {
    for (var i = 0; i < game.vals.length; i++) if (!game.vals[i]) return i;
    return 0;
  }

  /* ---------- 布局 ---------- */
  function build() {
    var n = game.n, bd = S.boxDims(n), i;
    boardEl.innerHTML = '';
    boardEl.style.gridTemplateColumns = 'repeat(' + n + ',1fr)';
    cells = [];
    var noteCols = n === 4 ? 2 : 3;
    for (i = 0; i < n * n; i++) {
      var c = document.createElement('div');
      c.setAttribute('data-i', i);
      c._base = 'sd-cell' + edgeClass(i, n, bd);
      c._noteCols = noteCols;
      boardEl.appendChild(c);
      cells.push(c);
    }
    var keys = '';
    for (i = 1; i <= n; i++) keys += '<button class="sd-key" data-nav data-d="' + i + '">' + i + '</button>';
    padEl.innerHTML = keys;
    layout();
    render();
    KG.nav.refresh(boardEl);
  }
  function edgeClass(i, n, bd) {
    var r = Math.floor(i / n), c = i % n, s = '';
    if (c === n - 1) s += ' eR'; else if (c % bd[1] === bd[1] - 1) s += ' bR';
    if (r === n - 1) s += ' eB'; else if (r % bd[0] === bd[0] - 1) s += ' bB';
    return s;
  }
  function layout() {
    if (!game) return;
    var n = game.n;
    var W = main.clientWidth - 32, H = main.clientHeight - 24 - 28;
    var land = W > H * 1.15;
    wrap.classList.toggle('land', land);
    var size, keyW, keyH, cols;
    if (land) {
      size = Math.min(H, W - 230 - 24);
      cols = n === 4 ? 2 : 3;
      keyW = 64; keyH = Math.max(44, Math.min(60, Math.floor((H - 120) / Math.ceil(n / cols)) - 6));
    } else {
      size = Math.min(W, H - 48 - 44 - 24);
      cols = n;
      keyW = Math.floor((Math.min(W, Math.max(size, 300)) - (n - 1) * 6) / n);
      keyH = 46;
      if (n < 9) keyW = Math.min(keyW, 64);
    }
    size = Math.max(180, Math.floor(size / n) * n) + 6;
    boardEl.style.width = size + 'px';
    boardEl.style.height = size + 'px';
    var cs = (size - 6) / n;
    boardEl.style.fontSize = Math.round(cs * 0.56) + 'px';
    cells.forEach(function (c) { c._fs = Math.max(8, Math.round(cs * (n === 9 ? 0.24 : 0.22))); });
    padEl.style.gridTemplateColumns = 'repeat(' + cols + ',' + keyW + 'px)';
    Array.prototype.forEach.call(padEl.children, function (k) { k.style.height = keyH + 'px'; });
  }
  window.addEventListener('resize', function () { layout(); render(); });

  /* ---------- 渲染 ---------- */
  function render() {
    if (!game) return;
    var n = game.n, u = S.units(n), v = game.vals, selV = v[sel], i, j;
    var peer = {}, bad = {};
    u.peers[sel].forEach(function (p) { peer[p] = 1; });
    for (i = 0; i < v.length; i++) {
      if (!v[i]) continue;
      var ps = u.peers[i];
      for (j = 0; j < ps.length; j++) if (v[ps[j]] === v[i]) { bad[i] = 1; break; }
    }
    var badCount = 0;
    for (i = 0; i < cells.length; i++) {
      var c = cells[i], cls = c._base;
      if (game.puzzle[i]) cls += ' given';
      else if (game.hinted[i]) cls += ' hinted';
      if (i === sel) cls += ' sel';
      else if (selV && v[i] === selV) cls += ' same';
      else if (peer[i]) cls += ' peer';
      if (bad[i]) { cls += ' bad'; badCount++; }
      c.className = cls;
      var html;
      if (v[i]) html = String(v[i]);
      else if (game.notes[i]) {
        html = '<div class="sd-notes" style="grid-template-columns:repeat(' + c._noteCols + ',1fr);font-size:' + c._fs + 'px">';
        for (var d = 1; d <= n; d++) {
          var has = game.notes[i] & (1 << (d - 1));
          html += '<span' + (has && d === selV ? ' class="on"' : '') + '>' + (has ? d : '') + '</span>';
        }
        html += '</div>';
      } else html = '';
      if (c._html !== html) { c.innerHTML = html; c._html = html; }
    }
    // 数字栏：已填满 n 个的数字变淡
    var cnt = [];
    for (i = 0; i <= n; i++) cnt.push(0);
    v.forEach(function (x) { cnt[x]++; });
    Array.prototype.forEach.call(padEl.children, function (k) {
      var d = +k.getAttribute('data-d');
      k.classList.toggle('done', cnt[d] >= n);
    });
    tNotes.classList.toggle('on', notesMode);
    tNotes.textContent = notesMode ? '笔记：开' : '笔记';
    var info = '<span><b>' + S.LEVELS[game.level].name + '</b></span>';
    info += '<span>提示 ' + game.hints + ' 次</span>';
    if (badCount) info += '<span style="color:var(--bad)">有数字冲突</span>';
    else if (KG.isDpad()) info += '<span>方向键选格 · OK 填数</span>';
    infoEl.innerHTML = info;
  }

  /* ---------- 操作 ---------- */
  function pushUndo(idxs) {
    var seen = {}, snap = [];
    idxs.forEach(function (i) {
      if (seen[i]) return;
      seen[i] = 1;
      snap.push({ i: i, v: game.vals[i], n: game.notes[i], h: game.hinted[i] });
    });
    undoStack.push(snap);
    if (undoStack.length > 300) undoStack.shift();
  }
  /** 把 idx 填上 d，并清掉同行同列同宫笔记里的 d。返回受影响格子。 */
  function placeValue(idx, d) {
    var bit = 1 << (d - 1), ps = S.units(game.n).peers[idx], touched = [idx];
    ps.forEach(function (p) { if (game.notes[p] & bit) touched.push(p); });
    pushUndo(touched);
    game.vals[idx] = d;
    game.notes[idx] = 0;
    ps.forEach(function (p) { game.notes[p] &= ~bit; });
  }
  function enter(d) {
    if (!game) return;
    if (game.puzzle[sel]) { KG.toast('这是题目给出的数字'); KG.shake(cells[sel]); return; }
    if (notesMode) {
      if (game.vals[sel]) { KG.toast('先擦除这个数字，再做笔记'); return; }
      pushUndo([sel]);
      game.notes[sel] ^= 1 << (d - 1);
    } else if (game.vals[sel] === d) {
      pushUndo([sel]);
      game.vals[sel] = 0;
      game.hinted[sel] = 0;
    } else {
      placeValue(sel, d);
      game.hinted[sel] = 0;
    }
    KG.sfx('tap');
    after();
  }
  function erase() {
    if (!game || game.puzzle[sel]) return;
    if (!game.vals[sel] && !game.notes[sel]) return;
    pushUndo([sel]);
    game.vals[sel] = 0; game.notes[sel] = 0; game.hinted[sel] = 0;
    KG.sfx('drop');
    after();
  }
  function undo() {
    if (!game) return;
    var snap = undoStack.pop();
    if (!snap) { KG.toast('没有可以撤销的操作'); return; }
    snap.forEach(function (s) { game.vals[s.i] = s.v; game.notes[s.i] = s.n; game.hinted[s.i] = s.h; });
    sel = snap[0].i;
    KG.sfx('drop');
    after();
  }
  function hint() {
    if (!game) return;
    var target = -1;
    if (!game.puzzle[sel] && game.vals[sel] !== game.sol[sel]) target = sel;
    else {
      var list = [];
      for (var i = 0; i < game.vals.length; i++) if (game.vals[i] !== game.sol[i]) list.push(i);
      if (!list.length) return;
      target = KG.pick(list);
    }
    placeValue(target, game.sol[target]);
    game.hinted[target] = 1;
    game.hints++;
    sel = target;
    KG.sfx('pop');
    after();
  }
  function after() {
    render();
    save();
    checkWin();
  }
  function checkWin() {
    var v = game.vals, full = true, right = true;
    for (var i = 0; i < v.length; i++) {
      if (!v[i]) full = false;
      else if (v[i] !== game.sol[i]) right = false;
    }
    if (!full) return;
    if (!right) { KG.toast('还有冲突的格子，再检查一下'); return; }
    var lv = game.level, hints = game.hints;
    var stars = hints === 0 ? 3 : (hints <= 2 ? 2 : 1);
    game = null;
    var d = KG.load() || {};
    d.cur = null;
    d.solved = d.solved || {};
    d.solved[lv] = (d.solved[lv] || 0) + 1;
    KG.save(d);
    KG.recordStars(lv, stars);
    setTimeout(function () {
      KG.showWin({
        title: '完成！',
        text: S.LEVELS[lv].name + (hints ? '，用了 ' + hints + ' 次提示' : '，没有用提示') + '。已完成 ' + d.solved[lv] + ' 局',
        stars: stars,
        replayText: '再来一局',
        onReplay: function () { startGame(lv); },
        nextText: '换难度',
        onNext: function () { showMenu(false); }
      });
    }, 350);
  }

  /* ---------- 事件 ---------- */
  boardEl.addEventListener('click', function (e) {
    var c = e.target.closest('[data-i]');
    if (!c || !game) return;
    sel = +c.getAttribute('data-i');
    KG.sfx('tap');
    render();
    if (KG.nav.enabled) KG.nav.focus(boardEl);
  });
  padEl.addEventListener('click', function (e) {
    var k = e.target.closest('[data-d]');
    if (!k) return;
    enter(+k.getAttribute('data-d'));
    if (KG.nav.enabled && !notesMode) KG.nav.focus(boardEl);
  });
  tNotes.addEventListener('click', function () { notesMode = !notesMode; KG.sfx('tap'); render(); });
  document.getElementById('tErase').addEventListener('click', function () { erase(); if (KG.nav.enabled) KG.nav.focus(boardEl); });
  document.getElementById('tUndo').addEventListener('click', undo);
  document.getElementById('tHint').addEventListener('click', hint);

  // 外接键盘：数字填写，0/退格擦除，N 切换笔记
  document.addEventListener('keydown', function (e) {
    if (!game || document.querySelector('.kg-overlay')) return;
    if (/^[1-9]$/.test(e.key) && +e.key <= game.n) { enter(+e.key); e.preventDefault(); }
    else if (e.key === '0' || e.key === 'Backspace' || e.key === 'Delete') { erase(); e.preventDefault(); }
    else if (e.key === 'n' || e.key === 'N') { notesMode = !notesMode; render(); }
  });

  var DIRS = { up: [-1, 0], down: [1, 0], left: [0, -1], right: [0, 1] };
  function onInput(key) {
    if (!game || document.querySelector('.kg-overlay')) return false;
    var onBoard = !KG.nav.enabled || KG.nav.current() === boardEl;
    if (!onBoard) return false;
    if (key === 'ok') {
      if (!KG.nav.enabled) return false;
      var btn = padEl.querySelector('[data-d="' + (game.vals[sel] || 1) + '"]');
      KG.nav.focus(btn);
      KG.sfx('tap');
      return true;
    }
    var d = DIRS[key];
    if (!d) return false;
    var n = game.n, r = Math.floor(sel / n) + d[0], c = sel % n + d[1];
    if (r < 0 || c < 0 || r >= n || c >= n) return KG.nav.enabled ? false : true; // 到边缘时让焦点离开棋盘
    sel = r * n + c;
    KG.sfx('tap');
    render();
    return true;
  }
  function onBack() {
    var cur = KG.nav.current();
    if (KG.nav.enabled && cur && cur.closest('.sd-side')) { KG.nav.focus(boardEl); return true; }
    save();
    return false;
  }

  /* ---------- 选择难度 ---------- */
  function showMenu(canClose) {
    var old = document.querySelector('.sd-menu');
    if (old) old.remove();
    var stars = (KG.load() || {}).stars || {};
    var cur = game ? game.level : 'easy';
    var html = '<div class="kg-overlay sd-menu"><div class="kg-card sd-menu-card"><h2>选择难度</h2><div class="sd-levels">';
    S.LEVEL_ORDER.forEach(function (lv) {
      var st = '';
      for (var s = 1; s <= 3; s++) st += s <= (stars[lv] || 0) ? '★' : '';
      html += '<button class="kg-btn ghost sd-lv" data-nav data-lv="' + lv + '"' + (lv === cur ? ' data-autofocus' : '') + '>'
        + S.LEVELS[lv].name + '<small>' + LV_DESC[lv] + '</small><span class="st">' + st + '</span></button>';
    });
    html += '</div>' + (canClose ? '<button class="kg-btn" data-nav data-close>继续这一局</button>' : '') + '</div></div>';
    var ov = KG.el(html);
    function close() { ov.remove(); KG.nav.refresh(boardEl); }
    ov.addEventListener('click', function (e) {
      var b = e.target.closest('[data-lv]');
      if (b) { close(); KG.sfx('tap'); startGame(b.getAttribute('data-lv')); return; }
      if (e.target.closest('[data-close]')) close();
    });
    ov._onBack = canClose ? close : function () { ov.remove(); KG.exit(); };
    document.body.appendChild(ov);
    if (KG.nav.enabled) KG.nav.focus(ov.querySelector('[data-autofocus]') || ov.querySelector('[data-nav]'));
  }

  /* ---------- 启动：恢复存档或选难度 ---------- */
  var saved = (KG.load() || {}).cur;
  if (saved && saved.sol && saved.vals && S.LEVELS[saved.level]) {
    game = {
      level: saved.level, n: saved.n, puzzle: saved.puzzle, sol: saved.sol, vals: saved.vals,
      notes: saved.notes, hinted: saved.hinted || saved.vals.map(function () { return 0; }), hints: saved.hints || 0
    };
    sel = saved.sel || 0;
    build();
    KG.toast('已恢复上次的进度');
  } else {
    showMenu(false);
  }
})();
