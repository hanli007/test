/*
 * 知识问答通用引擎：index.html?bank=<name> 读取 banks/<name>.json。
 * 题库格式：{ title, questions: [ {id, type:"choice", question, options[4], answer, explanation}
 *                                 {id, type:"fill", question（每个 "_" 是一个空）, tiles[], answer, explanation} ] }
 * 每轮随机 10 题，没有计时，答完显示解析，最后给总结和星级。
 */
(function () {
  'use strict';
  var KG = window.KidsGame;
  var ROUND = 10;
  var bank = KG.params.get('bank') || 'poetry';
  if (!/^[a-z0-9_-]+$/.test(bank)) bank = 'poetry';

  var box = document.getElementById('box');
  var mainEl = document.getElementById('main');
  var all = [], title = '知识问答';
  var round = [], qi = 0, score = 0, wrong = [], answered = false;
  var fill = null; // {tiles, used[], slots[] (tile index or -1)}

  KG.init({ id: 'quiz-' + bank, nav: true });
  KG.mountHeader(title, '<span class="kg-chip" id="prog" style="cursor:default"></span>');
  var progEl = document.getElementById('prog');
  progEl.style.visibility = 'hidden';

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }
  function loadJSON(url, cb) {
    function xhr() {
      var x = new XMLHttpRequest();
      x.open('GET', url);
      x.onload = function () { try { cb(JSON.parse(x.responseText)); } catch (e) { cb(null); } };
      x.onerror = function () { cb(null); };
      x.send();
    }
    if (window.fetch) fetch(url).then(function (r) { return r.json(); }).then(cb, xhr);
    else xhr();
  }

  loadJSON('banks/' + bank + '.json', function (json) {
    if (!json || !json.questions || !json.questions.length) {
      box.innerHTML = '<p class="kg-msg">题库加载失败</p>';
      return;
    }
    title = json.title || title;
    document.querySelector('.kg-title').textContent = title;
    document.title = title;
    all = json.questions.filter(function (q) {
      return q && q.question && q.answer && (q.type === 'fill' ? q.tiles && q.tiles.length : q.options && q.options.length);
    });
    newRound();
  });

  /* ---------- 一轮 ---------- */
  function newRound() {
    var d = KG.load() || {};
    var recent = d.recent || [];
    // 最近做过的题排到后面，尽量每轮都是新题
    var fresh = KG.shuffle(all.filter(function (q) { return recent.indexOf(q.id) < 0; }));
    var old = KG.shuffle(all.filter(function (q) { return recent.indexOf(q.id) >= 0; }));
    round = fresh.concat(old).slice(0, Math.min(ROUND, all.length));
    recent = recent.concat(round.map(function (q) { return q.id; }));
    var keep = Math.max(0, all.length - ROUND);
    d.recent = recent.slice(Math.max(0, recent.length - keep));
    KG.save(d);
    qi = 0; score = 0; wrong = [];
    progEl.style.visibility = 'visible';
    showQuestion();
  }

  function showQuestion() {
    var q = round[qi];
    answered = false;
    fill = null;
    progEl.textContent = (qi + 1) + ' / ' + round.length;
    var html = '<div class="qz-progress"><i style="width:' + (qi / round.length * 100) + '%"></i></div>';
    html += '<div class="kg-card qz-card"><div class="qz-tag">第 ' + (qi + 1) + ' 题' + (q.type === 'fill' ? ' · 选字填空' : ' · 单选') + '</div><div class="qz-q" id="qtext"></div></div>';
    if (q.type === 'fill') {
      html += '<div class="qz-tiles" id="tiles"></div><div class="qz-tools"><button class="kg-chip" data-nav id="bClear">清空重填</button></div>';
    } else {
      html += '<div class="qz-opts" id="opts"></div>';
    }
    html += '<div id="fbArea"></div>';
    box.innerHTML = html;
    mainEl.scrollTop = 0;
    if (q.type === 'fill') setupFill(q);
    else setupChoice(q);
    KG.nav.refresh();
  }

  /* 单选：选项顺序打乱 */
  function setupChoice(q) {
    document.getElementById('qtext').textContent = q.question;
    var opts = KG.shuffle(q.options), keys = 'ABCD', html = '';
    opts.forEach(function (o, i) {
      html += '<button class="qz-opt" data-nav' + (i === 0 ? ' data-autofocus' : '') + ' data-o="' + esc(o) + '"><span class="k">' + (keys[i] || i + 1) + '</span><span>' + esc(o) + '</span></button>';
    });
    var el = document.getElementById('opts');
    el.innerHTML = html;
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-o]');
      if (!b || answered) return;
      answered = true;
      var pick = b.getAttribute('data-o'), ok = pick === q.answer;
      Array.prototype.forEach.call(el.children, function (x) {
        var v = x.getAttribute('data-o');
        if (v === q.answer) x.classList.add('ok');
        else if (x === b) x.classList.add('bad');
        else x.classList.add('dim');
      });
      finish(q, ok, pick);
    });
  }

  /* 选字填空：题目里每个 "_" 是一个空 */
  function setupFill(q) {
    var tiles = KG.shuffle(q.tiles);
    fill = { tiles: tiles, used: tiles.map(function () { return false; }), slots: [] };
    var parts = q.question.split('_'), html = '';
    parts.forEach(function (p, i) {
      html += esc(p);
      if (i < parts.length - 1) {
        html += '<button class="qz-slot" data-nav data-s="' + i + '"></button>';
        fill.slots.push(-1);
      }
    });
    document.getElementById('qtext').innerHTML = html;
    var th = '';
    tiles.forEach(function (t, i) {
      th += '<button class="qz-tile" data-nav' + (i === 0 ? ' data-autofocus' : '') + ' data-t="' + i + '">' + esc(t) + '</button>';
    });
    document.getElementById('tiles').innerHTML = th;
    renderFill();
    document.getElementById('tiles').addEventListener('click', function (e) {
      var b = e.target.closest('[data-t]');
      if (!b || answered) return;
      var t = +b.getAttribute('data-t');
      if (fill.used[t]) return;
      var s = fill.slots.indexOf(-1);
      if (s < 0) return;
      fill.slots[s] = t;
      fill.used[t] = true;
      KG.sfx('tap');
      renderFill();
      if (fill.slots.indexOf(-1) < 0) checkFill(q);
      else if (KG.nav.enabled) {
        // 焦点移到下一个可用的字块
        var nextTile = document.querySelector('.qz-tile:not(.used)');
        if (nextTile && b.classList.contains('used')) KG.nav.focus(nextTile);
      }
    });
    document.getElementById('qtext').addEventListener('click', function (e) {
      var b = e.target.closest('[data-s]');
      if (!b || answered) return;
      var s = +b.getAttribute('data-s');
      if (fill.slots[s] < 0) return;
      fill.used[fill.slots[s]] = false;
      fill.slots[s] = -1;
      KG.sfx('drop');
      renderFill();
    });
    document.getElementById('bClear').addEventListener('click', function () {
      if (answered) return;
      fill.slots = fill.slots.map(function () { return -1; });
      fill.used = fill.used.map(function () { return false; });
      renderFill();
    });
  }
  function renderFill() {
    var firstEmpty = fill.slots.indexOf(-1);
    Array.prototype.forEach.call(document.querySelectorAll('.qz-slot'), function (el, i) {
      var t = fill.slots[i];
      el.textContent = t >= 0 ? fill.tiles[t] : '';
      el.classList.toggle('next', i === firstEmpty && !answered);
    });
    Array.prototype.forEach.call(document.querySelectorAll('.qz-tile'), function (el, i) {
      el.classList.toggle('used', fill.used[i]);
    });
  }
  function checkFill(q) {
    answered = true;
    var got = fill.slots.map(function (t) { return fill.tiles[t]; });
    var ok = got.join('') === q.answer;
    var ans = q.answer.split('');
    Array.prototype.forEach.call(document.querySelectorAll('.qz-slot'), function (el, i) {
      el.classList.add(got[i] === ans[i] ? 'ok' : 'bad');
      el.textContent = ans[i] || got[i];
    });
    finish(q, ok, got.join(''));
  }

  /* ---------- 答完一题 ---------- */
  function finish(q, ok, pick) {
    if (ok) { score++; KG.sfx('ok'); }
    else { wrong.push({ q: q, pick: pick }); KG.sfx('drop'); }
    var last = qi + 1 >= round.length;
    var fb = '<div class="kg-card qz-fb' + (ok ? '' : ' wrong') + '"><h3>' + (ok ? '回答正确' : '正确答案：' + esc(q.answer)) + '</h3>'
      + (q.explanation ? '<p>' + esc(q.explanation) + '</p>' : '') + '</div>'
      + '<button class="kg-btn qz-next" data-nav id="bNext">' + (last ? '查看结果' : '下一题') + '</button>';
    var area = document.getElementById('fbArea');
    area.style.display = 'flex';
    area.style.flexDirection = 'column';
    area.style.gap = '12px';
    area.innerHTML = fb;
    var bNext = document.getElementById('bNext');
    bNext.addEventListener('click', function () {
      qi++;
      if (qi >= round.length) summary(); else showQuestion();
    });
    if (KG.nav.enabled) KG.nav.focus(bNext);
    else if (bNext.scrollIntoView) bNext.scrollIntoView({ block: 'nearest' });
  }

  /* ---------- 总结 ---------- */
  function summary() {
    var n = round.length;
    var stars = score >= n - 1 ? 3 : (score >= Math.ceil(n * 0.6) ? 2 : 1);
    var d = KG.load() || {};
    d.rounds = (d.rounds || 0) + 1;
    d.bestScore = Math.max(d.bestScore || 0, score);
    KG.save(d);
    KG.recordStars('round', stars);
    KG.sfx('win');
    progEl.style.visibility = 'hidden';
    var st = '';
    for (var s = 1; s <= 3; s++) st += '<span class="kg-star' + (s <= stars ? ' on' : '') + '">★</span>';
    var msg = score === n ? '全部答对，太厉害了！' : score >= n * 0.7 ? '很不错，继续保持！' : '每轮都能学到新知识，再来一轮吧';
    var html = '<div class="kg-card qz-sum"><h2>本轮完成</h2><div class="score">' + score + ' / ' + n + '</div>'
      + '<div class="kg-stars">' + st + '</div><p style="margin:0;color:var(--muted)">' + msg + '</p>';
    if (wrong.length) {
      html += '<ol class="qz-review">';
      wrong.forEach(function (w) {
        html += '<li>' + esc(w.q.question.replace(/_+/g, function (m) { return '（' + Array(m.length + 1).join('＿') + '）'; }))
          + ' <b>' + esc(w.q.answer) + '</b></li>';
      });
      html += '</ol>';
    }
    html += '<div class="kg-row"><button class="kg-btn" data-nav data-autofocus id="bAgain">再来一轮</button>'
      + '<button class="kg-btn ghost" data-nav id="bHome">返回</button></div>'
      + '<p style="margin:0;font-size:13px;color:var(--muted)">已完成 ' + d.rounds + ' 轮 · 最高 ' + d.bestScore + ' 分</p></div>';
    box.innerHTML = html;
    mainEl.scrollTop = 0;
    document.getElementById('bAgain').addEventListener('click', newRound);
    document.getElementById('bHome').addEventListener('click', function () { KG.exit(); });
    KG.nav.refresh(document.getElementById('bAgain'));
  }
})();
