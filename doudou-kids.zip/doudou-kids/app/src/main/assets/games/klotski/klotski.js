/* 华容道：经典方块华容道（曹操走出出口）+ 数字推盘（3×3 / 4×4，只生成可解排列）。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var profile = KG.init({ id: 'klotski', nav: true, onInput: onInput, onBack: onBack });
  KG.mountHeader('华容道', '<span class="kg-chip" id="moves" hidden></span>');

  var $moves = document.getElementById('moves');
  var $picker = document.getElementById('picker'), $list = document.getElementById('list');
  var $play = document.getElementById('play'), $msg = document.getElementById('msg');
  var $wrap = document.getElementById('wrap'), $board = document.getElementById('board');

  var levels = [], lv = null;
  var W = 4, H = 5, cell = 80, GAP = 4;
  var blocks = [], initial = null, history = [], moves = 0, held = null, solved = false;
  var suppressClick = false;

  function loadJSON(url, ok, fail) {
    function xhr() {
      try {
        var x = new XMLHttpRequest();
        x.open('GET', url, true);
        x.onload = function () { try { ok(JSON.parse(x.responseText)); } catch (e) { fail(e); } };
        x.onerror = function () { fail(new Error('xhr ' + url)); };
        x.send();
      } catch (e) { fail(e); }
    }
    if (window.fetch) fetch(url).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }).then(ok, xhr);
    else xhr();
  }

  /* ---------- 数字推盘：只生成可解排列 ---------- */
  /** tiles: 长度 n*n 的数组，0 为空格，按行排列。 */
  function isSolvable(tiles, n) {
    var inv = 0, arr = tiles.filter(function (t) { return t !== 0; });
    for (var i = 0; i < arr.length; i++) for (var j = i + 1; j < arr.length; j++) if (arr[i] > arr[j]) inv++;
    if (n % 2 === 1) return inv % 2 === 0;
    var blankRowFromBottom = n - Math.floor(tiles.indexOf(0) / n);
    return (blankRowFromBottom % 2 === 1) === (inv % 2 === 0);
  }
  function isSolvedTiles(tiles) {
    for (var i = 0; i < tiles.length - 1; i++) if (tiles[i] !== i + 1) return false;
    return true;
  }
  function genNumber(n) {
    var tiles = [];
    for (var i = 0; i < n * n; i++) tiles.push(i);
    for (var tries = 0; tries < 100; tries++) {
      tiles = KG.shuffle(tiles);
      if (!isSolvable(tiles, n)) {
        // 交换两个非空格的数字，奇偶性翻转后必然可解
        var a = -1, b = -1;
        for (var k = 0; k < tiles.length && b < 0; k++) if (tiles[k] !== 0) { if (a < 0) a = k; else b = k; }
        var t = tiles[a]; tiles[a] = tiles[b]; tiles[b] = t;
      }
      if (isSolvable(tiles, n) && !isSolvedTiles(tiles)) break;
    }
    var out = [];
    tiles.forEach(function (v, idx) {
      if (v) out.push({ x: idx % n, y: Math.floor(idx / n), w: 1, h: 1, kind: 'num', label: String(v), num: v });
    });
    return out;
  }

  /* ---------- 方块华容道 ---------- */
  var SHU_NAMES = ['张飞', '赵云', '马超', '黄忠', '周仓'];
  var HENG_NAMES = ['关羽', '魏延'];
  function parseGrid(rows) {
    var map = {}, order = [];
    for (var y = 0; y < rows.length; y++) for (var x = 0; x < rows[y].length; x++) {
      var ch = rows[y][x]; if (ch === '.') continue;
      if (!map[ch]) { map[ch] = { x: x, y: y, w: 1, h: 1 }; order.push(ch); }
      var b = map[ch];
      b.w = Math.max(b.w, x - b.x + 1); b.h = Math.max(b.h, y - b.y + 1);
    }
    var si = 0, hi = 0;
    return order.map(function (ch) {
      var b = map[ch];
      if (b.w === 2 && b.h === 2) { b.kind = 'cao'; b.label = '曹操'; b.em = '🐯'; }
      else if (b.w === 2) { b.kind = 'heng'; b.label = HENG_NAMES[hi++ % HENG_NAMES.length]; }
      else if (b.h === 2) { b.kind = 'shu'; b.label = SHU_NAMES[si++ % SHU_NAMES.length]; }
      else { b.kind = 'bing'; b.label = '兵'; }
      return b;
    });
  }

  /* ---------- 选关 ---------- */
  function starsHtml(n) {
    var s = '';
    for (var k = 1; k <= 3; k++) s += '<i' + (k <= n ? ' class="on"' : '') + '>★</i>';
    return s;
  }
  function showPicker() {
    held = null;
    $play.hidden = true;
    $moves.hidden = true;
    $picker.hidden = false;
    var p = KG.load() || {}, st = p.stars || {};
    var age = +profile.age || 8;
    var def = lv ? lv.id : null;
    if (!def) {
      // 小一点的孩子先玩数字 3×3，大一点的从第一个没过的华容道开始
      def = age < 9 ? 'n3' : null;
      for (var i = 0; !def && i < levels.length; i++) if (levels[i].type === 'block' && !st[levels[i].id]) def = levels[i].id;
      def = def || levels[0].id;
    }
    $list.innerHTML = levels.map(function (l, i) {
      var sub = l.type === 'number' ? '数字推盘' : '华容道 · 最少 ' + l.par + ' 步';
      var best = p.best && p.best[l.id] ? ' · 最好 ' + p.best[l.id] + ' 步' : '';
      return '<button class="kl-item" data-nav data-lv="' + i + '"' + (l.id === def ? ' data-autofocus' : '') + '><b>' + l.name + '</b><small>' + sub + best + '</small><span class="st">' + starsHtml(st[l.id] || 0) + '</span></button>';
    }).join('');
    KG.nav.refresh($list.querySelector('[data-autofocus]'));
  }
  $list.addEventListener('click', function (e) {
    var b = e.target.closest('[data-lv]'); if (!b) return;
    KG.sfx('tap');
    startLevel(levels[+b.getAttribute('data-lv')]);
  });

  /* ---------- 开局 ---------- */
  function startLevel(l, sameLayout) {
    lv = l;
    $list.innerHTML = '';
    if (l.type === 'number') {
      W = H = l.size;
      blocks = sameLayout && initial ? cloneBlocks(initial) : genNumber(l.size);
      setMsg('把数字按 1、2、3…的顺序排好，点挨着空格的数字就能移动');
    } else {
      W = 4; H = 5;
      blocks = parseGrid(l.grid);
      setMsg(KG.isDpad() ? '按确认键选中方块，用方向键推动，再按确认放下' : '点一下方块，再滑动它或点旁边的空格');
    }
    initial = cloneBlocks(blocks);
    history = []; moves = 0; held = null; solved = false;
    $picker.hidden = true;
    $play.hidden = false;
    $moves.hidden = false;
    build();
    layout();
    updateMoves();
    KG.nav.refresh($board.querySelector('.kl-blk'));
    KG.say(l.type === 'number'
      ? { key: 'prompt_klotski_2', zh: '把数字按顺序排好' }
      : { key: 'prompt_klotski_1', zh: '推动方块，帮曹操从下面的出口走出去' });
  }
  function cloneBlocks(arr) {
    return arr.map(function (b) { return { x: b.x, y: b.y, w: b.w, h: b.h, kind: b.kind, label: b.label, em: b.em, num: b.num }; });
  }

  function build() {
    var h = '';
    if (lv.type === 'block') h += '<div class="kl-exit" id="exit">出口</div>';
    blocks.forEach(function (b, i) {
      var inner = b.kind === 'cao' && profile.ageTier !== 'sn' ? '<span class="em">' + b.em + '</span><span>' + b.label + '</span>' : '<span>' + b.label + '</span>';
      h += '<button class="kl-blk ' + b.kind + '" data-nav data-b="' + i + '" aria-label="' + b.label + '">' + inner + '</button>';
    });
    $board.innerHTML = h;
    blocks.forEach(function (b, i) { b.el = $board.querySelector('[data-b="' + i + '"]'); });
  }

  function layout() {
    if (!lv || $play.hidden) return;
    var w = $wrap.clientWidth - 24, hh = $wrap.clientHeight - 30;
    cell = Math.floor(Math.min(w / W, hh / H));
    cell = Math.max(48, Math.min(cell, 120));
    $board.style.width = cell * W + 'px';
    $board.style.height = cell * H + 'px';
    var fs = lv.type === 'number' ? Math.round(cell * 0.45) : Math.round(cell * 0.24);
    blocks.forEach(function (b) {
      b.el.style.width = (b.w * cell - GAP * 2) + 'px';
      b.el.style.height = (b.h * cell - GAP * 2) + 'px';
      b.el.style.fontSize = (b.kind === 'cao' ? Math.round(fs * 1.3) : fs) + 'px';
      place(b);
    });
    var ex = document.getElementById('exit');
    if (ex) { ex.style.left = cell + 'px'; ex.style.width = cell * 2 + 'px'; }
  }
  function place(b) {
    b.el.style.left = (b.x * cell + GAP) + 'px';
    b.el.style.top = (b.y * cell + GAP) + 'px';
    if (b.kind === 'num') b.el.classList.toggle('home', b.x + b.y * W === b.num - 1);
  }
  function updateMoves() { $moves.textContent = moves + ' 步'; }
  function setMsg(t) { $msg.textContent = t; }

  /* ---------- 移动 ---------- */
  function canMove(b, dx, dy) {
    var nx = b.x + dx, ny = b.y + dy;
    if (nx < 0 || ny < 0 || nx + b.w > W || ny + b.h > H) return false;
    for (var i = 0; i < blocks.length; i++) {
      var o = blocks[i];
      if (o === b) continue;
      if (nx < o.x + o.w && nx + b.w > o.x && ny < o.y + o.h && ny + b.h > o.y) return false;
    }
    return true;
  }
  function doMove(b, dx, dy, record) {
    b.x += dx; b.y += dy;
    place(b);
    if (record !== false) { history.push([blocks.indexOf(b), dx, dy]); moves++; }
    updateMoves();
  }
  function tryMove(b, dx, dy) {
    if (solved || KG.paused) return false;
    if (!canMove(b, dx, dy)) { KG.sfx('tap'); KG.shake(b.el); return false; }
    KG.sfx('drop');
    doMove(b, dx, dy);
    checkWin();
    return true;
  }

  /** 数字推盘：点和空格同一行/列的数字，一次滑过去。 */
  function blankCell() {
    var occ = {};
    blocks.forEach(function (b) { occ[b.x + ',' + b.y] = 1; });
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) if (!occ[x + ',' + y]) return [x, y];
    return null;
  }
  function blockAt(x, y) {
    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i];
      if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) return b;
    }
    return null;
  }
  function slideNumber(b) {
    if (solved) return;
    var e = blankCell(); if (!e) return;
    var dx = 0, dy = 0;
    if (b.y === e[1]) dx = e[0] > b.x ? 1 : -1;
    else if (b.x === e[0]) dy = e[1] > b.y ? 1 : -1;
    else { KG.sfx('tap'); KG.shake(b.el); return; }
    // 从挨着空格的那块开始依次滑动
    var x = e[0] - dx, y = e[1] - dy, chain = [];
    while (true) {
      var t = blockAt(x, y);
      chain.push(t);
      if (t === b) break;
      x -= dx; y -= dy;
    }
    KG.sfx('drop');
    chain.forEach(function (t) { doMove(t, dx, dy); });
    checkWin();
  }

  function setHeld(b) {
    if (held) held.el.classList.remove('held');
    held = b;
    if (b) { b.el.classList.add('held'); KG.sfx('pick'); }
  }

  /* 点击（触屏点按或遥控器确认） */
  $board.addEventListener('click', function (e) {
    if (suppressClick || solved || KG.paused) return;
    var el = e.target.closest('.kl-blk');
    if (el) {
      var b = blocks[+el.getAttribute('data-b')];
      if (lv.type === 'number') { slideNumber(b); return; }
      if (held === b) { held.el.classList.remove('held'); held = null; KG.sfx('tap'); }
      else setHeld(b);
      return;
    }
    // 点空格：把选中的方块朝那个方向推一格
    if (!held || lv.type === 'number') return;
    var r = $board.getBoundingClientRect();
    var cx = Math.floor((e.clientX - r.left) / cell), cy = Math.floor((e.clientY - r.top) / cell);
    var dx = 0, dy = 0;
    if (cx >= held.x && cx < held.x + held.w) dy = cy < held.y ? -1 : (cy >= held.y + held.h ? 1 : 0);
    else if (cy >= held.y && cy < held.y + held.h) dx = cx < held.x ? -1 : 1;
    if (dx || dy) tryMove(held, dx, dy);
  });

  /* 滑动 */
  var swipe = null;
  $board.addEventListener('pointerdown', function (e) {
    var el = e.target.closest('.kl-blk');
    if (!el || swipe) return;
    swipe = { id: e.pointerId, x: e.clientX, y: e.clientY, b: blocks[+el.getAttribute('data-b')] };
  });
  function endSwipe(e) {
    if (!swipe || e.pointerId !== swipe.id) return;
    var s = swipe; swipe = null;
    if (e.type === 'pointercancel') return;
    var dx = e.clientX - s.x, dy = e.clientY - s.y;
    if (Math.abs(dx) < 24 && Math.abs(dy) < 24) return;
    suppressClick = true;
    setTimeout(function () { suppressClick = false; }, 80);
    var mx = 0, my = 0;
    if (Math.abs(dx) > Math.abs(dy)) mx = dx > 0 ? 1 : -1; else my = dy > 0 ? 1 : -1;
    if (lv.type === 'number') {
      var e0 = blankCell();
      if (e0 && e0[0] === s.b.x + mx && e0[1] === s.b.y + my) slideNumber(s.b);
      else { KG.sfx('tap'); KG.shake(s.b.el); }
      return;
    }
    if (held !== s.b) setHeld(s.b);
    // 滑得远就多推几格
    var steps = Math.max(1, Math.min(3, Math.round(Math.max(Math.abs(dx), Math.abs(dy)) / cell)));
    for (var i = 0; i < steps; i++) if (!tryMove(s.b, mx, my) || solved) break;
  }
  $board.addEventListener('pointerup', endSwipe);
  $board.addEventListener('pointercancel', endSwipe);

  /* 遥控器：选中方块后方向键推动 */
  function onInput(key) {
    if (!lv || $play.hidden || document.querySelector('.kg-overlay')) return false;
    if (!held) return false;
    var d = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] }[key];
    if (d) { tryMove(held, d[0], d[1]); return true; }
    if (key === 'back') { held.el.classList.remove('held'); held = null; KG.sfx('tap'); return true; }
    return false; // ok：交给焦点导航点击，放下方块
  }

  /* ---------- 工具 ---------- */
  document.querySelector('.kl-tools').addEventListener('click', function (e) {
    var b = e.target.closest('[data-tool]'); if (!b || KG.paused) return;
    var t = b.getAttribute('data-tool');
    KG.sfx('tap');
    if (t === 'pick') { showPicker(); return; }
    if (solved) return;
    if (t === 'undo') {
      var h = history.pop();
      if (!h) { setMsg('已经是最开始啦'); return; }
      doMove(blocks[h[0]], -h[1], -h[2], false);
      moves = Math.max(0, moves - 1);
      updateMoves();
    } else if (t === 'reset') {
      if (held) { held.el.classList.remove('held'); held = null; }
      blocks.forEach(function (bk, i) { bk.x = initial[i].x; bk.y = initial[i].y; place(bk); });
      history = []; moves = 0;
      updateMoves();
    }
  });

  /* ---------- 过关 ---------- */
  function checkWin() {
    var ok;
    if (lv.type === 'number') ok = blocks.every(function (b) { return b.x + b.y * W === b.num - 1; });
    else ok = blocks.some(function (b) { return b.kind === 'cao' && b.x === 1 && b.y === H - 2; });
    if (!ok) return;
    solved = true;
    if (held) { held.el.classList.remove('held'); held = null; }
    var stars;
    if (lv.type === 'number') stars = moves <= lv.starMoves[0] ? 3 : (moves <= lv.starMoves[1] ? 2 : 1);
    else stars = moves <= Math.ceil(lv.par * 1.3) + 2 ? 3 : (moves <= lv.par * 2.2 ? 2 : 1);
    var p = KG.recordStars(lv.id, stars);
    p.best = p.best || {};
    var prev = p.best[lv.id];
    if (!prev || moves < prev) p.best[lv.id] = moves;
    KG.save(p);
    if (lv.type === 'block') {
      var cao = blocks.filter(function (b) { return b.kind === 'cao'; })[0];
      cao.el.classList.add('out');
      cao.el.style.top = (H * cell + GAP) + 'px';
    }
    var idx = levels.indexOf(lv), next = levels[idx + 1];
    var text = '用了 ' + moves + ' 步' + (lv.type === 'block' ? '（最少 ' + lv.par + ' 步）' : '') + (prev && moves < prev ? '，新纪录！' : '');
    var cur = lv;
    setTimeout(function () {
      KG.showWin({
        stars: stars,
        text: text,
        onReplay: function () { startLevel(cur); },
        onNext: next ? function () { startLevel(next); } : function () { showPicker(); },
        nextText: next ? '下一个：' + next.name : '选谜题'
      });
    }, 700);
  }

  function onBack() {
    if (!$play.hidden) { showPicker(); return true; }
    return false;
  }

  var resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(layout, 120);
  });

  loadJSON('levels.json', function (data) {
    levels = data.levels || [];
    showPicker();
  }, function (err) {
    KG.log('levels.json 加载失败：' + err);
    $picker.hidden = false;
    $list.innerHTML = '<p class="kg-msg">谜题加载失败，请返回重试</p>';
  });

})();
