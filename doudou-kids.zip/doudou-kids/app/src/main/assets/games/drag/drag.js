/*
 * 豆豆乐园 拖拽引擎（ES2015，不使用 async/await、?.、??、对象展开、Array.flat）
 *
 * index.html?set=<name> 读取 sets/<name>.json。关卡数据格式：
 *
 * 套装 { title, rule: pair|classify|sort, layout: row|train|seq|size|scene|puzzle,
 *        place?, pad?, board?, wrongHint{key,zh}, wrongHintTq?, levels: [关卡] }
 * 关卡 { prompt{key,zh} | [每个阶段一条], promptTq?, items, targets, rounds?: [小题],
 *        show?(题目区图案), intro?(说完玩法后再读一条), complete?(完成时读),
 *        group?(seq 布局按几个一组), scene?, puzzle?{pic, cols, rows, speech}, shuffle?, shuffleTargets? }
 *   有 rounds 时，关卡里的每个小题依次进行，字段先找小题、再找关卡、再找套装。
 * 物品 { id, match: 目标 key | [key…] | null(干扰项), art, artTq?, speech{key,zh,en}, stage?, frame? }
 * 目标 { id, key?(默认 id), art?, artTq?, label?, frame?, color?, place?: over|stack|inside,
 *        cap?, count?(放入后读总数), contents?[art](预先放好的), fixed?(只展示), scale?(size 布局),
 *        x?, y?, size?, spots?[{x,y}](scene 布局，百分比) }
 * 图案 art { emoji, count?, silhouette?, scale?, char?, row?, text, font?: num|latin|cn, small?,
 *        color?, dots?, shape?, hole?, label? }
 */
(function () {
  'use strict';

  var KG = window.KidsGame;
  var SET = String(KG.params.get('set') || 'train').replace(/[^A-Za-z0-9_-]/g, '');
  var TQ = KG.profile.ageTier !== 'qm';

  var NUM_ZH = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十'];
  var NUM_EN = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty'];
  function numSpeech(n) { return { key: 'num_' + n, zh: NUM_ZH[n] || String(n), en: NUM_EN[n] || String(n) }; }

  /* ---------- 小工具 ---------- */
  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); }
  function tierPick(o, f) {
    if (!o) return undefined;
    if (TQ && o[f + 'Tq'] !== undefined) return o[f + 'Tq'];
    return o[f];
  }
  function each(list, fn) { Array.prototype.forEach.call(list, fn); }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  /** 等语音读完，但最多等 ms 毫秒（音频卡住时不让游戏停住）。 */
  function settle(p, ms) {
    return Promise.race([Promise.resolve(p).catch(function () { /* ignore */ }), wait(ms)]);
  }
  function cssPx(name, dflt) {
    var v = parseFloat(getComputedStyle(document.documentElement).getPropertyValue(name));
    return v > 0 ? v : dflt;
  }

  function xhrJSON(url) {
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open('GET', url, true);
      x.onload = function () {
        if (x.status === 200 || x.status === 0) {
          try { resolve(JSON.parse(x.responseText)); } catch (e) { reject(e); }
        } else reject(new Error('HTTP ' + x.status));
      };
      x.onerror = function () { reject(new Error('xhr failed ' + url)); };
      x.send();
    });
  }
  function loadJSON(url) {
    if (!window.fetch) return xhrJSON(url);
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).catch(function () { return xhrJSON(url); });
  }

  /* ---------- 画图：形状、点点、图片 ---------- */
  function starPoints() {
    var pts = [];
    for (var i = 0; i < 10; i++) {
      var r = i % 2 ? 20 : 47, a = -Math.PI / 2 + i * Math.PI / 5;
      pts.push((50 + r * Math.cos(a)).toFixed(1) + ',' + (54 + r * Math.sin(a)).toFixed(1));
    }
    return pts.join(' ');
  }
  var STAR_PTS = starPoints();
  var SHAPES = {
    circle: function (a) { return '<circle cx="50" cy="50" r="44" ' + a + '/>'; },
    oval: function (a) { return '<ellipse cx="50" cy="50" rx="46" ry="30" ' + a + '/>'; },
    square: function (a) { return '<rect x="9" y="9" width="82" height="82" rx="8" ' + a + '/>'; },
    rectangle: function (a) { return '<rect x="4" y="25" width="92" height="50" rx="7" ' + a + '/>'; },
    triangle: function (a) { return '<path d="M50 7L95 90H5Z" stroke-linejoin="round" ' + a + '/>'; },
    star: function (a) { return '<polygon points="' + STAR_PTS + '" stroke-linejoin="round" ' + a + '/>'; },
    heart: function (a) { return '<path d="M50 90C22 68 5 50 5 31 5 17 16 7 29 7c9 0 17 5 21 13 4-8 12-13 21-13 13 0 24 10 24 24 0 19-17 37-45 59Z" stroke-linejoin="round" ' + a + '/>'; }
  };
  function shapeSVG(name, color, hole, scale) {
    var f = SHAPES[name] || SHAPES.circle;
    var attrs = hole
      ? 'fill="rgba(60,40,26,.32)" stroke="rgba(60,40,26,.5)" stroke-width="4" stroke-dasharray="7 6"'
      : 'fill="' + (color || '#FF9F43') + '" stroke="rgba(0,0,0,.18)" stroke-width="4"';
    var st = scale && scale !== 1 ? ' style="width:calc(var(--emo) * ' + (1.15 * scale) + ');height:calc(var(--emo) * ' + (1.15 * scale) + ')"' : '';
    return '<svg class="dg-shape" viewBox="0 0 100 100"' + st + '>' + f(attrs) + '</svg>';
  }
  function dotsSVG(n, color) {
    var cols = Math.min(n, 5), rows = Math.ceil(n / 5), s = '';
    for (var i = 0; i < n; i++) {
      s += '<circle cx="' + (6 + (i % 5) * 12) + '" cy="' + (6 + Math.floor(i / 5) * 12) + '" r="4.6" fill="' + (color || '#4A3424') + '"/>';
    }
    return '<svg class="dg-dots" viewBox="0 0 ' + (cols * 12) + ' ' + (rows * 12) + '" style="width:calc(var(--dot) * ' + cols + ');height:calc(var(--dot) * ' + rows + ')">' + s + '</svg>';
  }

  /* 拼图用的画，坐标 0..120 */
  var PICS = {
    dog: function () {
      return '<rect width="120" height="120" fill="#BFE6FF"/><circle cx="104" cy="16" r="10" fill="#FFD84A"/>'
        + '<path d="M0 96Q30 86 60 94T120 92V120H0Z" fill="#9ED86B"/>'
        + '<circle cx="14" cy="104" r="4" fill="#F2678A"/><circle cx="108" cy="108" r="4" fill="#FFC94A"/>'
        + '<g transform="translate(6 6) scale(.9)">' + KG.dogSVG('happy', 120) + '</g>';
    },
    house: function () {
      return '<rect width="120" height="120" fill="#BFE6FF"/><circle cx="100" cy="18" r="11" fill="#FFD84A"/>'
        + '<ellipse cx="22" cy="22" rx="14" ry="6" fill="#fff"/><ellipse cx="32" cy="18" rx="9" ry="6" fill="#fff"/>'
        + '<rect y="96" width="120" height="24" fill="#8FD16A"/>'
        + '<rect x="78" y="26" width="11" height="22" fill="#9C5B3B"/>'
        + '<path d="M14 60L60 20L106 60Z" fill="#E8505B" stroke="#C93E49" stroke-width="3" stroke-linejoin="round"/>'
        + '<rect x="24" y="58" width="72" height="42" fill="#FFE2A8"/>'
        + '<rect x="52" y="72" width="17" height="28" rx="3" fill="#B8763E"/><circle cx="65" cy="87" r="1.8" fill="#FFD84A"/>'
        + '<rect x="31" y="66" width="15" height="15" fill="#7EC8F5" stroke="#fff" stroke-width="2.5"/>'
        + '<rect x="75" y="66" width="15" height="15" fill="#7EC8F5" stroke="#fff" stroke-width="2.5"/>'
        + '<circle cx="12" cy="106" r="4" fill="#F2678A"/><circle cx="108" cy="104" r="4" fill="#FFC94A"/>';
    },
    rocket: function () {
      return '<rect width="120" height="120" fill="#2B2F6B"/>'
        + '<circle cx="16" cy="18" r="2" fill="#fff"/><circle cx="100" cy="12" r="2.4" fill="#FFE066"/><circle cx="24" cy="64" r="1.8" fill="#fff"/>'
        + '<circle cx="106" cy="50" r="2" fill="#fff"/><circle cx="12" cy="100" r="2.2" fill="#FFE066"/><circle cx="96" cy="84" r="1.6" fill="#fff"/>'
        + '<circle cx="102" cy="104" r="12" fill="#F4C78C"/><ellipse cx="102" cy="104" rx="19" ry="4" fill="none" stroke="#FF9F43" stroke-width="2"/>'
        + '<path d="M48 82Q60 116 72 82Z" fill="#FFB020"/><path d="M53 82Q60 104 67 82Z" fill="#FFE066"/>'
        + '<path d="M44 62L28 88L45 83Z" fill="#E8505B"/><path d="M76 62L92 88L75 83Z" fill="#E8505B"/>'
        + '<path d="M60 8C78 24 82 50 78 84H42C38 50 42 24 60 8Z" fill="#F2F4F8"/>'
        + '<path d="M60 8C68 15 73 24 76 32H44C47 24 52 15 60 8Z" fill="#E8505B"/>'
        + '<circle cx="60" cy="50" r="10" fill="#4AA3EE" stroke="#9AA7B8" stroke-width="3.5"/>'
        + '<rect x="52" y="68" width="16" height="5" rx="2" fill="#9AA7B8"/>';
    }
  };
  function picSVG(pic, cls, vb) {
    var f = PICS[pic] || PICS.dog;
    return '<svg class="' + cls + '" viewBox="' + (vb || '0 0 120 120') + '" preserveAspectRatio="none">' + f() + '</svg>';
  }

  /* 场景：给小熊穿衣服，坐标 0..200 x 0..260 */
  var SCENES = {
    bear: {
      ratio: 200 / 260,
      svg: '<svg viewBox="0 0 200 260" class="dg-scene-svg">'
        + '<ellipse cx="100" cy="254" rx="74" ry="6" fill="rgba(0,0,0,.08)"/>'
        + '<circle cx="62" cy="28" r="17" fill="#A86B3C"/><circle cx="62" cy="28" r="9" fill="#E8B98A"/>'
        + '<circle cx="138" cy="28" r="17" fill="#A86B3C"/><circle cx="138" cy="28" r="9" fill="#E8B98A"/>'
        + '<ellipse cx="72" cy="226" rx="22" ry="26" fill="#A86B3C"/><ellipse cx="128" cy="226" rx="22" ry="26" fill="#A86B3C"/>'
        + '<ellipse cx="72" cy="244" rx="18" ry="10" fill="#E8B98A"/><ellipse cx="128" cy="244" rx="18" ry="10" fill="#E8B98A"/>'
        + '<ellipse cx="50" cy="150" rx="15" ry="34" transform="rotate(28 50 150)" fill="#A86B3C"/>'
        + '<ellipse cx="150" cy="150" rx="15" ry="34" transform="rotate(-28 150 150)" fill="#A86B3C"/>'
        + '<ellipse cx="100" cy="168" rx="54" ry="60" fill="#A86B3C"/><ellipse cx="100" cy="178" rx="33" ry="38" fill="#E8B98A"/>'
        + '<circle cx="38" cy="174" r="15" fill="#8E5830"/><circle cx="162" cy="174" r="15" fill="#8E5830"/>'
        + '<circle cx="100" cy="64" r="46" fill="#A86B3C"/>'
        + '<ellipse cx="100" cy="82" rx="19" ry="14" fill="#E8B98A"/><ellipse cx="100" cy="75" rx="7" ry="5" fill="#3B2A1E"/>'
        + '<path d="M100 80v5M100 85q-6 5-11 1M100 85q6 5 11 1" stroke="#3B2A1E" stroke-width="2.5" fill="none" stroke-linecap="round"/>'
        + '<circle cx="82" cy="58" r="5.5" fill="#3B2A1E"/><circle cx="118" cy="58" r="5.5" fill="#3B2A1E"/>'
        + '<circle cx="84" cy="56" r="1.8" fill="#fff"/><circle cx="120" cy="56" r="1.8" fill="#fff"/>'
        + '<circle cx="70" cy="76" r="6" fill="#F59E9E" opacity=".5"/><circle cx="130" cy="76" r="6" fill="#F59E9E" opacity=".5"/>'
        + '</svg>'
    }
  };

  var LOCO = '<svg class="dg-loco-svg" viewBox="0 0 100 92">'
    + '<circle cx="24" cy="6" r="5" fill="#fff" opacity=".9"/><circle cx="34" cy="3" r="3.5" fill="#fff" opacity=".7"/>'
    + '<rect x="12" y="12" width="22" height="8" rx="3" fill="#4A3424"/><rect x="16" y="18" width="14" height="20" rx="3" fill="#4A3424"/>'
    + '<rect x="6" y="36" width="64" height="36" rx="9" fill="#E8505B"/>'
    + '<rect x="54" y="12" width="38" height="60" rx="7" fill="#FF9F43"/><rect x="61" y="20" width="24" height="18" rx="4" fill="#BFE6FF"/>'
    + '<path d="M8 66L0 80H16Z" fill="#4A3424"/>'
    + '<circle cx="26" cy="77" r="11" fill="#3B2A1E"/><circle cx="26" cy="77" r="4" fill="#D8D8D8"/>'
    + '<circle cx="68" cy="75" r="14" fill="#3B2A1E"/><circle cx="68" cy="75" r="5" fill="#D8D8D8"/>'
    + '</svg>';

  /** 根据图案描述生成 HTML。 */
  function art(a) {
    if (!a) return '';
    if (typeof a === 'string') a = { emoji: a };
    var parts = [], sc = a.scale || 1, i;
    if (a.piece) {
      var p = a.piece;
      parts.push(picSVG(p.pic, 'dg-pic', p.x + ' ' + p.y + ' ' + p.w + ' ' + p.h));
    }
    if (a.shape) parts.push(shapeSVG(a.shape, a.color, a.hole, sc));
    if (a.dots) parts.push(dotsSVG(a.dots, a.color));
    if (a.emoji) {
      if (a.count) {
        var s = '';
        for (i = 0; i < a.count; i++) s += '<span class="dg-emoji">' + esc(a.emoji) + '</span>';
        parts.push('<span class="dg-count dg-n' + a.count + '">' + s + '</span>');
      } else {
        var st = sc !== 1 ? ' style="font-size:calc(var(--emo) * ' + sc + ')"' : '';
        parts.push('<span class="dg-emoji' + (a.silhouette ? ' dg-sil' : '') + '"' + st + '>' + esc(a.emoji) + '</span>');
      }
    }
    if (a.char) parts.push('<span class="dg-char">' + esc(a.char) + '</span>');
    if (a.text !== undefined) {
      parts.push('<span class="dg-text dg-t-' + (a.font || 'num') + (a.small ? ' dg-t-sm' : '') + '"'
        + (a.color ? ' style="color:' + esc(a.color) + '"' : '') + '>' + esc(a.text) + '</span>');
    }
    if (a.label) parts.push('<span class="dg-cap">' + esc(a.label) + '</span>');
    return '<span class="dg-art' + (a.piece ? ' dg-art-fill' : '') + (a.row ? ' dg-art-row' : '') + '">' + parts.join('') + '</span>';
  }

  /* ---------- 状态 ---------- */
  var state = {
    set: null, li: 0, ri: 0, round: null, stage: 0, maxStage: 0,
    mistakes: 0, streak: 0, items: [], targets: [], sel: null, done: false,
    mode: 'drag', token: 0
  };
  var E = {};
  var sayGen = 0;
  var pending = null;

  function levels() { return state.set.levels; }
  function roundsOf(lv) { return lv.rounds && lv.rounds.length ? lv.rounds : [lv]; }
  /** 依次在小题、关卡、套装上找字段。 */
  function opt(name, dflt) {
    var srcs = [state.round, levels()[state.li], state.set];
    for (var i = 0; i < srcs.length; i++) {
      var v = tierPick(srcs[i], name);
      if (v !== undefined) return v;
    }
    return dflt;
  }

  function speak(list) {
    sayGen++;
    return KG.sayAll(list.filter(function (x) { return !!x; }));
  }
  /** 当前这条语音读完后执行 fn；期间如果又读了别的，就不执行。 */
  function afterSpeech(p, fn) {
    var g = sayGen, tok = state.token;
    settle(p, 6000).then(function () { if (g === sayGen && tok === state.token && !KG.paused) fn(); });
  }
  function whenActive(fn) { if (KG.paused) pending = fn; else fn(); }

  /* ---------- 操作模式 ---------- */
  function loadMode() {
    var p = KG.load();
    state.mode = p && p.mode === 'tap' ? 'tap' : 'drag';
  }
  function saveMode() {
    var p = KG.load() || {};
    p.mode = state.mode;
    KG.save(p);
  }
  function setMode(m, byUser) {
    state.mode = m === 'tap' ? 'tap' : 'drag';
    each(document.querySelectorAll('.dg-seg-btn'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-mode') === state.mode);
    });
    document.documentElement.classList.toggle('dg-tapmode', state.mode === 'tap');
    deselect();
    refreshLocks();
    if (byUser) {
      KG.sfx('tap');
      saveMode();
      KG.toast(state.mode === 'tap' ? '先点一下东西，再点要放的地方' : '按住东西，拖到要放的地方');
    }
  }
  function mountHeader(title) {
    var seg = '<div class="dg-seg" role="group" aria-label="操作方式">'
      + '<button type="button" class="dg-seg-btn" data-mode="drag">拖拽</button>'
      + '<button type="button" class="dg-seg-btn" data-mode="tap">点选</button></div>';
    var h = KG.mountHeader(title, seg);
    h.querySelector('.dg-seg').addEventListener('click', function (e) {
      var b = e.target.closest('[data-mode]');
      if (b && b.getAttribute('data-mode') !== state.mode) setMode(b.getAttribute('data-mode'), true);
    });
  }

  /* ---------- 界面骨架 ---------- */
  function buildShell() {
    var main = KG.el('<main class="kg-main dg-main"><div class="dg-stage">'
      + '<div class="dg-top"><div class="kg-prompt dg-prompt"><div class="dg-dogcol">' + KG.dogSVG('happy', 52)
      + '<div class="dg-level"></div></div><div class="kg-bubble dg-bubble">……</div></div></div>'
      + '<div class="dg-show"></div><div class="dg-board"></div><div class="dg-tray"></div>'
      + '</div></main>');
    document.body.appendChild(main);
    E.main = main;
    E.stage = main.querySelector('.dg-stage');
    E.top = main.querySelector('.dg-top');
    E.prompt = main.querySelector('.dg-prompt');
    E.bubble = main.querySelector('.dg-bubble');
    E.level = main.querySelector('.dg-level');
    E.show = main.querySelector('.dg-show');
    E.board = main.querySelector('.dg-board');
    E.tray = main.querySelector('.dg-tray');
    // 点豆豆或气泡，再听一遍玩法
    E.prompt.addEventListener('click', function () {
      if (!KG.paused && state.set && !state.done) sayPrompt();
    });
  }

  /* ---------- 关卡流程 ---------- */
  function firstLevel() {
    var n = levels().length;
    var q = parseInt(KG.params.get('level'), 10);
    if (q >= 1 && q <= n) return q - 1;
    var p = KG.load(), st = (p && p.stars) || {};
    for (var i = 0; i < n; i++) if (!st['L' + (i + 1)]) return i;
    return 0;
  }
  function startLevel(li) {
    state.li = li;
    state.ri = 0;
    state.mistakes = 0;
    startRound();
  }
  function startRound() {
    state.round = roundsOf(levels()[state.li])[state.ri];
    state.stage = 0;
    state.streak = 0;
    state.done = false;
    state.sel = null;
    build();
    sayPrompt();
  }
  function promptFor(stage) {
    var p = opt('prompt');
    if (Array.isArray(p)) return p[Math.min(stage, p.length - 1)];
    return stage === 0 ? p : null;
  }
  function sayPrompt() {
    var p = promptFor(state.stage);
    if (p) E.bubble.textContent = p.zh;
    var list = [p];
    if (state.stage === 0) list.push(opt('intro'));
    return speak(list);
  }

  function puzzleData(pz) {
    var items = [], targets = [], w = 120 / pz.cols, h = 120 / pz.rows;
    for (var r = 0; r < pz.rows; r++) {
      for (var c = 0; c < pz.cols; c++) {
        var i = r * pz.cols + c;
        targets.push({ id: 'c' + i, frame: 'cell', r: r, c: c });
        items.push({ id: 'p' + i, match: 'c' + i, frame: 'piece', speech: pz.speech,
          art: { piece: { pic: pz.pic, x: +(c * w).toFixed(3), y: +(r * h).toFixed(3), w: +w.toFixed(3), h: +h.toFixed(3) } } });
      }
    }
    return { items: items, targets: targets };
  }

  function build() {
    state.token++;
    var r = state.round, rule = opt('rule', 'pair'), layout = opt('layout', 'row');
    E.stage.className = 'dg-stage dg-l-' + layout + ' dg-set-' + SET;
    E.board.className = 'dg-board' + (opt('board') ? ' dg-b-' + opt('board') : '');
    E.board.innerHTML = '';
    E.tray.innerHTML = '';
    E.board.removeAttribute('style');

    var nLv = levels().length, rs = roundsOf(levels()[state.li]);
    var dots = '';
    if (rs.length > 1) for (var i = 0; i < rs.length; i++) dots += i <= state.ri ? '●' : '○';
    E.level.textContent = (state.li + 1) + '/' + nLv + (dots ? ' ' + dots : '');

    var show = r.show;
    E.show.style.display = show ? '' : 'none';
    E.show.innerHTML = show ? art(show) : '';

    var pz = opt('puzzle');
    var data = layout === 'puzzle' && pz ? puzzleData(pz) : { items: r.items || [], targets: r.targets || [] };

    state.targets = data.targets.map(function (d, i) {
      var t = { d: d, i: i, key: d.key || d.id, fixed: !!d.fixed, count: 0, zones: [], slots: [], el: null };
      t.cap = d.cap !== undefined ? d.cap : (rule === 'classify' ? 999 : 1);
      t.place = d.place || opt('place') || (rule === 'classify' ? 'inside' : 'over');
      return t;
    });
    var torder = opt('shuffleTargets', false) ? KG.shuffle(state.targets) : state.targets.slice();
    renderBoard(layout, torder);

    state.items = data.items.map(function (d, i) {
      return { d: d, i: i, stage: d.stage || 0, placed: false, el: null };
    });
    state.maxStage = state.items.reduce(function (m, it) { return Math.max(m, it.stage); }, 0);
    var iorder = state.items.slice();
    if (opt('shuffle', true) && iorder.length > 1) {
      iorder = KG.shuffle(iorder);
      // 不要正好和目标同一个顺序
      if (iorder.every(function (x, i) { return x === state.items[i]; })) iorder.push(iorder.shift());
    }
    iorder.forEach(function (it) { E.tray.appendChild(makeItem(it)); });

    refreshStage();
    refreshLocks();
    fit();
  }

  function makeTarget(t) {
    var d = t.d, a = tierPick(d, 'art');
    var el = KG.el('<div class="dg-target dg-p-' + t.place + (d.frame ? ' dg-f-' + d.frame : '') + (t.fixed ? ' dg-fixed' : '') + '"></div>');
    if (d.color) el.style.setProperty('--tc', d.color);
    el.setAttribute('data-id', d.id);
    el.innerHTML = (d.label ? '<div class="dg-tlabel">' + esc(d.label) + '</div>' : '')
      + (a ? '<div class="dg-tart">' + art(a) + '</div>' : '')
      + (t.fixed ? '' : '<div class="dg-slot"></div>');
    t.el = el;
    if (!t.fixed) {
      el._t = t;
      t.zones.push(el);
      t.slots.push(el.querySelector('.dg-slot'));
      el.addEventListener('click', onTargetClick);
      if (d.contents) d.contents.forEach(function (c) { t.slots[0].appendChild(placedEl(c, false)); });
    }
    return el;
  }

  function renderBoard(layout, order) {
    var B = E.board;
    if (layout === 'train') {
      var tr = KG.el('<div class="dg-train"><div class="dg-loco">' + LOCO + '</div></div>');
      order.forEach(function (t) { tr.appendChild(makeTarget(t)); });
      B.appendChild(tr);
    } else if (layout === 'seq') {
      var g = opt('group', 0), grp = null;
      order.forEach(function (t, i) {
        if (!grp || (g && i % g === 0)) { grp = KG.el('<div class="dg-group"></div>'); B.appendChild(grp); }
        grp.appendChild(makeTarget(t));
      });
    } else if (layout === 'scene') {
      var sc = SCENES[opt('scene', 'bear')] || SCENES.bear;
      var box = KG.el('<div class="dg-scene"><div class="dg-scene-bg">' + sc.svg + '</div></div>');
      order.forEach(function (t) {
        var d = t.d, s = d.size || 30, hp = s * sc.ratio;
        var spots = d.spots || [{ x: d.x, y: d.y }];
        spots.forEach(function (p) {
          var z = KG.el('<div class="dg-target dg-zone dg-p-over"><div class="dg-slot"></div></div>');
          z.style.left = (p.x - s / 2) + '%';
          z.style.width = s + '%';
          z.style.top = (p.y - hp / 2) + '%';
          z.style.height = hp + '%';
          z._t = t;
          z.setAttribute('data-id', d.id);
          z.addEventListener('click', onTargetClick);
          t.zones.push(z);
          t.slots.push(z.querySelector('.dg-slot'));
          box.appendChild(z);
        });
        t.el = t.zones[0];
      });
      B.appendChild(box);
    } else if (layout === 'puzzle') {
      var pz = opt('puzzle');
      var grid = KG.el('<div class="dg-grid"><div class="dg-ghost">' + picSVG(pz.pic, 'dg-pic') + '</div></div>');
      order.forEach(function (t) {
        var el = makeTarget(t);
        el.style.left = (t.d.c * 100 / pz.cols) + '%';
        el.style.top = (t.d.r * 100 / pz.rows) + '%';
        el.style.width = (100 / pz.cols) + '%';
        el.style.height = (100 / pz.rows) + '%';
        grid.appendChild(el);
      });
      B.appendChild(grid);
    } else {
      order.forEach(function (t) { B.appendChild(makeTarget(t)); });
    }
  }

  function makeItem(it) {
    var el = KG.el('<div class="dg-item' + (it.d.frame ? ' dg-f-' + it.d.frame : '') + '" role="button"></div>');
    el.innerHTML = art(tierPick(it.d, 'art'));
    el.setAttribute('data-id', it.d.id);
    el._it = it;
    it.el = el;
    KG.draggable(el, { onStart: onDragStart, onDrop: onDrop });
    el.addEventListener('click', onItemClick);
    return el;
  }
  function placedEl(a, pop) {
    var el = KG.el('<div class="dg-placed' + (pop ? ' kg-pop' : '') + '"></div>');
    el.innerHTML = art(a);
    return el;
  }

  function refreshStage() {
    state.items.forEach(function (it) {
      it.el.classList.toggle('dg-later', it.stage > state.stage);
      it.el.classList.toggle('dg-past', it.stage < state.stage);
    });
  }
  function refreshLocks() {
    state.items.forEach(function (it) {
      var lock = it.placed || state.done || it.stage !== state.stage || state.mode === 'tap';
      if (it.el) it.el.classList.toggle('kg-locked', lock);
    });
  }

  /* ---------- 尺寸自适应（拼图、场景、大小排序） ---------- */
  function fit() {
    if (!state.set || !E.main) return;
    var layout = opt('layout', 'row');
    if (layout !== 'puzzle' && layout !== 'scene' && layout !== 'size') return;
    var cs = getComputedStyle(E.main);
    var W = E.main.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    var itemPx = cssPx('--item', 72), targetPx = cssPx('--target', 88);

    if (layout === 'size') {
      var sum = 0, mx = 0, n = 0;
      state.targets.forEach(function (t) { if (!t.fixed) { sum += t.d.scale || 1; mx = Math.max(mx, t.d.scale || 1); n++; } });
      var unit = Math.min((W - 6 * (n - 1) - 4) / sum, targetPx * 1.3 / mx);
      state.targets.forEach(function (t) {
        var s = (t.d.scale || 1) * unit;
        t.el.style.width = s + 'px';
        t.el.style.height = s + 'px';
      });
      E.board.style.setProperty('--emo', (unit * 0.78) + 'px');
      return;
    }

    if (layout === 'puzzle') {
      var pz = opt('puzzle'), cw = 120 / pz.cols, ch = 120 / pz.rows, k = itemPx * 1.05 / Math.max(cw, ch);
      state.items.forEach(function (it) {
        it.el.style.width = (cw * k) + 'px';
        it.el.style.height = (ch * k) + 'px';
      });
    }

    var H = E.main.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
    var used = 0, parts = 1;
    [E.top, E.show, E.tray].forEach(function (x) {
      if (x.style.display !== 'none' && x.offsetHeight) { used += x.offsetHeight; parts++; }
    });
    var avail = H - used - 12 * (parts - 1) - 6;

    if (layout === 'puzzle') {
      var G = Math.max(180, Math.min(W, avail, 520));
      var grid = E.board.querySelector('.dg-grid');
      grid.style.width = G + 'px';
      grid.style.height = G + 'px';
    } else {
      var sc = SCENES[opt('scene', 'bear')] || SCENES.bear;
      var sw = Math.max(180, Math.min(W, avail * sc.ratio, 440));
      var box = E.board.querySelector('.dg-scene');
      box.style.width = sw + 'px';
      box.style.height = (sw / sc.ratio) + 'px';
      state.targets.forEach(function (t) {
        var px = sw * (t.d.size || 30) / 100;
        t.zones.forEach(function (z) { z.style.setProperty('--emo', (px * 0.82) + 'px'); });
      });
    }
  }

  /* ---------- 判断与放置 ---------- */
  function matches(it, t) {
    if (t.fixed) return false;
    var m = it.d.match;
    if (m === undefined || m === null) return false;
    return Array.isArray(m) ? m.indexOf(t.key) >= 0 : m === t.key;
  }
  function freeTargetFor(it) {
    for (var i = 0; i < state.targets.length; i++) {
      var t = state.targets[i];
      if (matches(it, t) && t.count < t.cap) return t;
    }
    return null;
  }
  function allZones() {
    return state.targets.reduce(function (acc, t) { return acc.concat(t.zones); }, []);
  }
  function needed(stage) {
    return state.items.filter(function (it) {
      return it.stage === stage && !it.placed && it.d.match !== undefined && it.d.match !== null;
    });
  }

  function deselect() {
    if (state.sel && state.sel.el) state.sel.el.classList.remove('kg-lifted');
    state.sel = null;
  }
  function clearHints() {
    each(E.stage.querySelectorAll('.kg-hint'), function (x) { x.classList.remove('kg-hint'); });
  }
  function shakeEl(el) {
    KG.shake(el);
    setTimeout(function () { el.classList.remove('kg-shake'); }, 500);
  }
  function showHint(it) {
    clearHints();
    var t = freeTargetFor(it);
    if (!t) {
      // 拿的是干扰项：提示一个正确的物品和它的位置
      var other = needed(state.stage).filter(function (x) { return freeTargetFor(x); })[0];
      if (!other) return;
      other.el.classList.add('kg-hint');
      t = freeTargetFor(other);
    }
    t.zones.forEach(function (z) { z.classList.add('kg-hint'); });
  }

  function attempt(it, t) {
    if (matches(it, t) && t.count < t.cap) { place(it, t); return true; }
    wrong(it, t);
    return false;
  }

  function place(it, t) {
    it.placed = true;
    t.count++;
    if (state.sel === it) state.sel = null;
    it.el.classList.remove('kg-lifted');
    it.el.classList.add('dg-gone');
    var a = tierPick(it.d, 'art');
    t.slots.forEach(function (s) {
      if (t.place !== 'inside') s.innerHTML = '';
      s.appendChild(placedEl(a, true));
    });
    t.zones.forEach(function (z) { z.classList.add('dg-filled'); });
    clearHints();
    state.streak = 0;
    refreshLocks();
    KG.sfx('ok');
    var tail = it.d.speech;
    if (t.d.count) tail = numSpeech(t.count + (t.d.contents ? t.d.contents.length : 0));
    var p = speak([KG.praiseItem(), tail]);
    checkProgress(p);
  }

  function wrong(it, t) {
    state.mistakes++;
    state.streak++;
    KG.sfx('wrong');
    t.zones.forEach(shakeEl);
    speak([opt('wrongHint') || KG.hintItem()]);
    if (state.streak >= 3) showHint(it);
  }

  function checkProgress(p) {
    if (needed(state.stage).length) return;
    if (state.stage < state.maxStage) {
      // 进入下一个阶段（例如先放苹果，再选答案）
      state.stage++;
      refreshStage();
      refreshLocks();
      fit();
      var np = promptFor(state.stage);
      if (np) E.bubble.textContent = np.zh;
      afterSpeech(p, sayPrompt);
      return;
    }
    state.done = true;
    deselect();
    refreshLocks();
    var tok = state.token, comp = state.round.complete;
    settle(p, 6000).then(function () {
      if (tok !== state.token) return;
      if (comp) return settle(speak([comp]), 5000);
    }).then(function () { return wait(300); }).then(function () {
      if (tok === state.token) whenActive(roundDone);
    });
  }

  function roundDone() {
    if (state.ri < roundsOf(levels()[state.li]).length - 1) {
      state.ri++;
      KG.sfx('pop');
      startRound();
      return;
    }
    var li = state.li, m = state.mistakes;
    var stars = m <= 1 ? 3 : (m <= 3 ? 2 : 1);
    KG.recordStars('L' + (li + 1), stars);
    var last = li >= levels().length - 1;
    KG.showWin({
      stars: stars,
      text: last ? '所有关卡都完成啦！' : '第' + (li + 1) + '关完成',
      onReplay: function () { startLevel(li); },
      onNext: last ? undefined : function () { startLevel(li + 1); }
    });
  }

  /* ---------- 输入 ---------- */
  function onDragStart(el) {
    var it = el._it;
    if (!it) return;
    deselect();
    speak([it.d.speech]);
  }
  function onDrop(x, y, el) {
    var it = el._it;
    if (!it || it.placed || state.done || KG.paused) return false;
    var z = KG.findTarget(x, y, allZones(), opt('pad', 44));
    if (!z) { KG.sfx('drop'); return false; }
    return attempt(it, z._t);
  }
  function onItemClick() {
    var it = this._it;
    if (!it || it.placed || state.done || KG.paused || it.stage !== state.stage) return;
    if (state.mode !== 'tap') { speak([it.d.speech]); return; }
    if (state.sel === it) { deselect(); KG.sfx('tap'); return; }
    deselect();
    state.sel = it;
    it.el.classList.add('kg-lifted');
    KG.sfx('pick');
    speak([it.d.speech]);
  }
  function onTargetClick() {
    var t = this._t;
    if (!t || state.done || KG.paused || state.mode !== 'tap') return;
    var it = state.sel;
    if (!it) { KG.sfx('tap'); return; }
    if (!attempt(it, t)) {
      // 和拖拽模式的“弹回去”一致：放下物品，摇一摇
      deselect();
      shakeEl(it.el);
    }
  }

  function onPause() { /* 库已停止语音；拖拽和点选都没有计时，无需处理 */ }
  function onResume() {
    var f = pending;
    pending = null;
    if (f) f();
  }

  /* ---------- 启动 ---------- */
  KG.init({ id: 'drag-' + SET, nav: false, onPause: onPause, onResume: onResume });
  loadMode();
  buildShell();
  loadJSON('sets/' + SET + '.json').then(function (data) {
    if (!data || !data.levels || !data.levels.length) throw new Error('empty set ' + SET);
    state.set = data;
    document.title = data.title || document.title;
    mountHeader(data.title || '小游戏');
    setMode(state.mode, false);
    var rt = 0;
    window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(fit, 120); });
    startLevel(firstLevel());
  }).catch(function (err) {
    KG.log('drag: ' + (err && err.message ? err.message : err));
    if (!document.querySelector('.kg-header')) mountHeader('小游戏');
    E.bubble.textContent = '哎呀，这个游戏没有找到';
  });
})();
