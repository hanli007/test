/* 戳泡泡：泡泡慢慢往上飘，点一下就破；有的泡泡里有数字、颜色或小动物，破了会读出名字。没有分数，没有失败。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var NUMS = [
    { key: 'num_1', zh: '一', en: 'one', t: '1' }, { key: 'num_2', zh: '二', en: 'two', t: '2' },
    { key: 'num_3', zh: '三', en: 'three', t: '3' }, { key: 'num_4', zh: '四', en: 'four', t: '4' },
    { key: 'num_5', zh: '五', en: 'five', t: '5' }, { key: 'num_6', zh: '六', en: 'six', t: '6' },
    { key: 'num_7', zh: '七', en: 'seven', t: '7' }, { key: 'num_8', zh: '八', en: 'eight', t: '8' },
    { key: 'num_9', zh: '九', en: 'nine', t: '9' }
  ];
  var COLORS = [
    { key: 'color_red', zh: '红色', en: 'red', c: '#EF4444' },
    { key: 'color_orange', zh: '橙色', en: 'orange', c: '#FB923C' },
    { key: 'color_yellow', zh: '黄色', en: 'yellow', c: '#FACC15' },
    { key: 'color_green', zh: '绿色', en: 'green', c: '#4ADE80' },
    { key: 'color_blue', zh: '蓝色', en: 'blue', c: '#3B82F6' },
    { key: 'color_purple', zh: '紫色', en: 'purple', c: '#A78BFA' },
    { key: 'color_pink', zh: '粉色', en: 'pink', c: '#F9A8D4' },
    { key: 'color_brown', zh: '棕色', en: 'brown', c: '#A47148' }
  ];
  var ANIMALS = [
    { key: 'animal_dog', zh: '小狗', en: 'dog', e: '🐶' },
    { key: 'animal_cat', zh: '小猫', en: 'cat', e: '🐱' },
    { key: 'animal_duck', zh: '小鸭', en: 'duck', e: '🦆' },
    { key: 'animal_pig', zh: '小猪', en: 'pig', e: '🐷' },
    { key: 'animal_frog', zh: '青蛙', en: 'frog', e: '🐸' },
    { key: 'animal_fish', zh: '小鱼', en: 'fish', e: '🐟' },
    { key: 'animal_rabbit', zh: '小兔', en: 'rabbit', e: '🐰' },
    { key: 'animal_bear', zh: '小熊', en: 'bear', e: '🐻' }
  ];
  var PROMPT = { key: 'prompt_bubbles_1', zh: '戳一戳泡泡吧' };

  var young = KG.profile.ageTier === 'qm';
  var MAX = young ? 7 : 9;
  var SPAWN_EVERY = young ? 1.3 : 1.0; // 秒

  var field = document.getElementById('field');
  var W = 0, H = 0;
  var bubbles = [];
  var running = false, raf = 0, last = 0, spawnAcc = 0;

  function measure() {
    var r = field.getBoundingClientRect();
    W = r.width; H = r.height;
  }

  function randf(a, b) { return a + Math.random() * (b - a); }

  function spawn(startY) {
    if (!W || !H) return;
    var size = Math.round(Math.min(180, Math.max(88, Math.min(W, H) * randf(0.22, 0.3))));
    var roll = Math.random();
    var item = null, inner = '';
    if (roll < 0.2) {
      item = KG.pick(NUMS);
      inner = '<span class="num" style="font-size:' + Math.round(size * 0.5) + 'px">' + item.t + '</span>';
    } else if (roll < 0.4) {
      item = KG.pick(COLORS);
      inner = '<span class="dot" style="background:' + item.c + '"></span>';
    } else if (roll < 0.6) {
      item = KG.pick(ANIMALS);
      inner = '<span style="font-size:' + Math.round(size * 0.48) + 'px">' + item.e + '</span>';
    }
    var el = KG.el('<div class="bubble" style="width:' + size + 'px;height:' + size + 'px">' + inner + '</div>');
    var b = {
      el: el, item: item, size: size,
      x: randf(0, Math.max(0, W - size)),
      y: startY === undefined ? H + 10 : startY,
      vy: H / randf(young ? 11 : 9, young ? 15 : 12), // 从底飘到顶约 9–15 秒
      amp: randf(8, 22), freq: randf(0.6, 1.2), phase: randf(0, 6.28),
      popped: false
    };
    // 不要正好叠在上一个泡泡上
    var prev = bubbles[bubbles.length - 1];
    if (prev && Math.abs(prev.x - b.x) < size * 0.6 && Math.abs(prev.y - b.y) < size) {
      b.x = (b.x + W / 2) % Math.max(1, W - size);
    }
    el.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      pop(b);
    });
    place(b);
    field.appendChild(el);
    bubbles.push(b);
  }

  function place(b) {
    var x = b.x + Math.sin(b.phase * b.freq) * b.amp;
    x = Math.max(0, Math.min(W - b.size, x));
    b.el.style.webkitTransform = b.el.style.transform = 'translate(' + x.toFixed(1) + 'px,' + b.y.toFixed(1) + 'px)';
    b.cx = x + b.size / 2;
    b.cy = b.y + b.size / 2;
  }

  function removeBubble(b) {
    var i = bubbles.indexOf(b);
    if (i >= 0) bubbles.splice(i, 1);
  }

  function pop(b) {
    if (b.popped || KG.paused) return;
    b.popped = true;
    removeBubble(b);
    KG.sfx('pop');
    b.el.classList.add('popping');
    splash(b.cx, b.cy);
    setTimeout(function () { if (b.el.parentNode) b.el.parentNode.removeChild(b.el); }, 320);
    if (b.item) KG.say({ key: b.item.key, zh: b.item.zh, en: b.item.en });
  }

  function splash(cx, cy) {
    for (var i = 0; i < 6; i++) {
      var a = i / 6 * Math.PI * 2;
      var d = KG.el('<i class="splash"></i>');
      d.style.left = cx + 'px';
      d.style.top = cy + 'px';
      d.style.setProperty('--dx', Math.round(Math.cos(a) * 46) + 'px');
      d.style.setProperty('--dy', Math.round(Math.sin(a) * 46) + 'px');
      field.appendChild(d);
      (function (n) { setTimeout(function () { if (n.parentNode) n.parentNode.removeChild(n); }, 500); })(d);
    }
  }

  function frame(t) {
    if (!running) return;
    if (!W || !H) measure();
    if (!last) last = t;
    var dt = Math.min(0.05, (t - last) / 1000);
    last = t;
    spawnAcc += dt;
    if (spawnAcc >= SPAWN_EVERY) {
      spawnAcc = 0;
      if (bubbles.length < MAX) spawn();
    }
    for (var i = bubbles.length - 1; i >= 0; i--) {
      var b = bubbles[i];
      b.y -= b.vy * dt;
      b.phase += dt;
      if (b.y < -b.size - 10) {
        bubbles.splice(i, 1);
        if (b.el.parentNode) b.el.parentNode.removeChild(b.el);
        continue;
      }
      place(b);
    }
    raf = requestAnimationFrame(frame);
  }

  function start() {
    if (running) return;
    running = true;
    last = 0;
    raf = requestAnimationFrame(frame);
  }
  function stop() {
    running = false;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
  }

  /* ---------- 启动 ---------- */
  KG.init({
    id: 'bubbles',
    nav: false,
    onPause: stop,
    onResume: start
  });
  KG.mountHeader('戳泡泡');

  window.addEventListener('resize', measure);
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) stop();
    else if (!KG.paused) start();
  });

  measure();
  // 开局先放几个泡泡，屏幕不空
  for (var i = 0; i < 3; i++) spawn(H * (0.25 + i * 0.25));
  start();
  KG.say(PROMPT);
})();
