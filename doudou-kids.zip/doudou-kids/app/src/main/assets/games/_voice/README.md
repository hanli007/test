# 预录语音

游戏通过 `KidsGame.say({ key, zh, en })` 读语音。播放顺序：

1. `zh/<key>.mp3`，找不到时用系统 TTS 读 `zh`
2. 家长开启英文读音时：`en/<key>.mp3`，找不到时用系统 TTS 读 `en`

所以这个目录可以先空着，全部走 TTS；录好一条放一条，立刻生效。

## 目录

```
_voice/
├── zh/num_1.mp3     「一」
├── en/num_1.mp3     「one」
└── ...
```

## key 命名约定

| 前缀 | 用途 | 例子 |
|---|---|---|
| `num_<n>` | 数字 0–20 | `num_3` 三 / three |
| `color_<name>` | 颜色 | `color_red` 红色 / red |
| `shape_<name>` | 形状 | `shape_circle` 圆形 / circle |
| `animal_<name>` | 动物 | `animal_dog` 小狗 / dog |
| `food_<name>` | 食物、水果 | `food_banana` 香蕉 / banana |
| `body_<name>` | 身体部位、衣物 | `body_head` 头 / head |
| `vehicle_<name>` | 交通工具 | `vehicle_bus` 公交车 / bus |
| `letter_<x>` | 字母 | `letter_a` A |
| `item_<name>` | 其他物品 | `item_bottle` 瓶子 / bottle |
| `prompt_<game>_<n>` | 玩法说明，只有中文 | `prompt_train_1` |
| `praise_<n>` / `hint_<n>` / `win_<n>` | 表扬、提示、通关，只有中文 | `praise_1` 真棒！ |

## 生成录音清单

运行 `python3 tools/voice/collect_voice_lines.py`，会扫描所有游戏，输出需要录制的全部语音到 `tools/voice/voice-lines.csv`（key、中文、英文、出现在哪些游戏）。可以按清单用 TTS 批量生成，或用自己的声音模型录制。

格式要求：mp3，单声道，22.05kHz 或 44.1kHz，句首句尾留白不超过 0.1 秒，音量统一到约 -16 LUFS。
