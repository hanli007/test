/* 涂色：选一幅线稿 → 选颜色 → 点区域填色。颜色自动保存；全部涂满时庆祝。
 * 遥控器：每个区域中心放一个透明按钮（.rp，带 data-nav），由 KidsGame.nav 按位置移动焦点，确认键填色。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var COLORS = [
    { id: 'red', c: '#EF4444', say: { key: 'color_red', zh: '红色', en: 'red' } },
    { id: 'orange', c: '#FB923C', say: { key: 'color_orange', zh: '橙色', en: 'orange' } },
    { id: 'yellow', c: '#FACC15', say: { key: 'color_yellow', zh: '黄色', en: 'yellow' } },
    { id: 'green', c: '#4ADE80', say: { key: 'color_green', zh: '绿色', en: 'green' } },
    { id: 'blue', c: '#3B82F6', say: { key: 'color_blue', zh: '蓝色', en: 'blue' } },
    { id: 'purple', c: '#A78BFA', say: { key: 'color_purple', zh: '紫色', en: 'purple' } },
    { id: 'pink', c: '#F9A8D4', say: { key: 'color_pink', zh: '粉色', en: 'pink' } },
    { id: 'brown', c: '#A47148', say: { key: 'color_brown', zh: '棕色', en: 'brown' } }
  ];
  var COLOR_BY_ID = {};
  COLORS.forEach(function (c) { COLOR_BY_ID[c.id] = c; });
  var EMPTY = '#FFFFFF';
  var INK = '#4A3424';

  function starPts(cx, cy, R, r) {
    var pts = [];
    for (var i = 0; i < 10; i++) {
      var a = -Math.PI / 2 + i * Math.PI / 5, d = i % 2 ? r : R;
      pts.push((cx + Math.cos(a) * d).toFixed(1) + ',' + (cy + Math.sin(a) * d).toFixed(1));
    }
    return pts.join(' ');
  }

  /* 线稿，viewBox 0 0 200 200。regions 按绘制顺序（后画的在上面）；p 是遥控器焦点点的位置。 */
  var PICS = [
    { id: 'puppy', say: { key: 'animal_dog', zh: '小狗', en: 'dog' },
      regions: [
        { s: '<ellipse cx="100" cy="165" rx="52" ry="30"/>', p: [100, 178] },
        { s: '<ellipse cx="50" cy="78" rx="17" ry="36" transform="rotate(20 50 78)"/>', p: [38, 88] },
        { s: '<ellipse cx="150" cy="78" rx="17" ry="36" transform="rotate(-20 150 78)"/>', p: [162, 88] },
        { s: '<circle cx="100" cy="88" r="50"/>', p: [120, 56] },
        { s: '<ellipse cx="78" cy="76" rx="16" ry="14"/>', p: [70, 72] },
        { s: '<ellipse cx="100" cy="112" rx="26" ry="19"/>', p: [100, 121] },
        { s: '<path d="M62 128 Q100 150 138 128 L140 140 Q100 162 60 140 Z"/>', p: [100, 145] }
      ],
      deco: '<circle cx="80" cy="82" r="6" fill="' + INK + '"/><circle cx="120" cy="82" r="6" fill="' + INK + '"/>'
        + '<circle cx="82" cy="80" r="2" fill="#fff"/><circle cx="122" cy="80" r="2" fill="#fff"/>'
        + '<ellipse cx="100" cy="103" rx="8" ry="6" fill="' + INK + '"/>'
        + '<path d="M100 109v5M100 114q-7 7-13 1M100 114q7 7 13 1" stroke="' + INK + '" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
    },
    { id: 'house', say: { key: 'item_house', zh: '房子', en: 'house' },
      regions: [
        { s: '<circle cx="34" cy="34" r="18"/>', p: [34, 34] },
        { s: '<rect x="128" y="44" width="18" height="36"/>', p: [137, 55] },
        { s: '<path d="M32 100 L100 40 L168 100 Z"/>', p: [100, 78] },
        { s: '<rect x="46" y="100" width="108" height="76"/>', p: [134, 158] },
        { s: '<rect x="88" y="128" width="26" height="48" rx="3"/>', p: [101, 150] },
        { s: '<rect x="56" y="112" width="24" height="24" rx="2"/>', p: [68, 124] },
        { s: '<rect x="122" y="112" width="24" height="24" rx="2"/>', p: [134, 124] },
        { s: '<rect x="8" y="176" width="184" height="16" rx="8"/>', p: [30, 184] }
      ],
      deco: '<path d="M68 112v24M56 124h24M134 112v24M122 124h24" stroke="' + INK + '" stroke-width="2.5"/>'
        + '<circle cx="108" cy="154" r="2.6" fill="' + INK + '"/>'
        + '<path d="M34 5v8M34 55v8M5 34h8M55 34h8M14 14l5 5M49 49l5 5M54 14l-5 5M19 49l-5 5" stroke="' + INK + '" stroke-width="2.5" stroke-linecap="round"/>'
    },
    { id: 'fish', say: { key: 'animal_fish', zh: '小鱼', en: 'fish' },
      regions: [
        { s: '<path d="M82 128 Q100 178 118 128 Z"/>', p: [100, 146] },
        { s: '<path d="M68 70 Q92 0 122 66 Z"/>', p: [95, 50] },
        { s: '<path d="M145 100 L190 66 L190 134 Z"/>', p: [178, 100] },
        { s: '<ellipse cx="95" cy="100" rx="60" ry="38"/>', p: [78, 118] },
        { s: '<path d="M104 63 Q92 100 104 137 L120 134 Q108 100 120 66 Z"/>', p: [108, 100] },
        { s: '<circle cx="34" cy="56" r="12"/>', p: [34, 56] },
        { s: '<circle cx="22" cy="26" r="9"/>', p: [22, 26] }
      ],
      deco: '<circle cx="60" cy="92" r="7" fill="' + INK + '"/><circle cx="62" cy="90" r="2.4" fill="#fff"/>'
        + '<path d="M40 108q6 4 12 0M78 84q-8 16 0 32" stroke="' + INK + '" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
    },
    { id: 'flower', say: { key: 'item_flower', zh: '小花', en: 'flower' },
      regions: [
        { s: '<rect x="95" y="100" width="10" height="80"/>', p: [100, 160] },
        { s: '<ellipse cx="76" cy="146" rx="22" ry="10" transform="rotate(30 76 146)"/>', p: [74, 145] },
        { s: '<ellipse cx="124" cy="134" rx="22" ry="10" transform="rotate(-30 124 134)"/>', p: [126, 133] },
        { s: '<path d="M64 170 L136 170 L126 198 L74 198 Z"/>', p: [100, 186] },
        { s: '<circle cx="100" cy="48" r="22"/>', p: [100, 38] },
        { s: '<circle cx="130.4" cy="70.1" r="22"/>', p: [140, 67] },
        { s: '<circle cx="118.8" cy="105.9" r="22"/>', p: [125, 114] },
        { s: '<circle cx="81.2" cy="105.9" r="22"/>', p: [75, 114] },
        { s: '<circle cx="69.6" cy="70.1" r="22"/>', p: [60, 67] },
        { s: '<circle cx="100" cy="80" r="18"/>', p: [100, 80] }
      ],
      deco: '<circle cx="94" cy="76" r="2.4" fill="' + INK + '"/><circle cx="106" cy="76" r="2.4" fill="' + INK + '"/>'
        + '<path d="M93 84q7 6 14 0" stroke="' + INK + '" stroke-width="2.4" fill="none" stroke-linecap="round"/>'
    },
    { id: 'car', say: { key: 'vehicle_car', zh: '小汽车', en: 'car' },
      regions: [
        { s: '<rect x="6" y="152" width="188" height="12" rx="6"/>', p: [24, 158] },
        { s: '<path d="M18 132 L18 108 Q18 96 32 96 L58 96 L78 64 L136 64 L158 96 L170 97 Q184 99 184 114 L184 132 Z"/>', p: [92, 112] },
        { s: '<path d="M82 72 L103 72 L103 94 L68 94 Z"/>', p: [90, 84] },
        { s: '<path d="M109 72 L132 72 L148 94 L109 94 Z"/>', p: [124, 84] },
        { s: '<circle cx="56" cy="134" r="18"/>', p: [56, 134] },
        { s: '<circle cx="146" cy="134" r="18"/>', p: [146, 134] },
        { s: '<circle cx="176" cy="110" r="7"/>', p: [176, 110] }
      ],
      deco: '<path d="M106 96V128M112 106h9" stroke="' + INK + '" stroke-width="2.6" stroke-linecap="round"/>'
        + '<circle cx="56" cy="134" r="6" fill="#fff" stroke="' + INK + '" stroke-width="2.5"/>'
        + '<circle cx="146" cy="134" r="6" fill="#fff" stroke="' + INK + '" stroke-width="2.5"/>'
    },
    { id: 'rocket', say: { key: 'vehicle_rocket', zh: '火箭', en: 'rocket' },
      regions: [
        { s: '<path d="M80 148 Q100 196 120 148 Z"/>', p: [100, 164] },
        { s: '<path d="M72 112 L40 162 L72 148 Z"/>', p: [60, 142] },
        { s: '<path d="M128 112 L160 162 L128 148 Z"/>', p: [140, 142] },
        { s: '<path d="M100 18 Q132 50 130 110 L130 150 L70 150 L70 110 Q68 50 100 18 Z"/>', p: [100, 128] },
        { s: '<path d="M100 18 Q116 32 123 58 L77 58 Q84 32 100 18 Z"/>', p: [100, 42] },
        { s: '<circle cx="100" cy="90" r="16"/>', p: [100, 90] },
        { s: '<polygon points="' + starPts(36, 46, 16, 7) + '"/>', p: [36, 47] },
        { s: '<polygon points="' + starPts(166, 72, 13, 5.5) + '"/>', p: [166, 73] }
      ],
      deco: '<path d="M91 86q3-6 9-7" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round"/>'
    }
  ];

  var PROMPT_PICK = { key: 'prompt_coloring_1', zh: '选一幅画来涂颜色吧' };
  var PROMPT_PAINT = { key: 'prompt_coloring_2', zh: '先选颜色，再点一点画' };

  var main = document.getElementById('main');
  var screen = 'pick';
  var data = KG.load() || {};
  data.pics = data.pics || {};
  var pic = null, fills = null, cur = COLORS[0], lastPic = 0;
  var canvasEl = null;

  function fillsOf(p) {
    var saved = data.pics[p.id];
    var arr = [];
    for (var i = 0; i < p.regions.length; i++) arr.push(saved && saved[i] && COLOR_BY_ID[saved[i]] ? saved[i] : null);
    return arr;
  }
  function isDone(arr) {
    for (var i = 0; i < arr.length; i++) if (!arr[i]) return false;
    return true;
  }

  function svgHTML(p, arr) {
    var html = '<svg viewBox="0 0 200 200" aria-hidden="true">';
    p.regions.forEach(function (r, i) {
      var fill = arr[i] ? COLOR_BY_ID[arr[i]].c : EMPTY;
      html += r.s.replace(/^<(\w+)/, '<$1 class="rg" data-r="' + i + '" fill="' + fill + '"');
    });
    html += '<g class="deco">' + p.deco + '</g></svg>';
    return html;
  }

  /* ---------- 选画 ---------- */
  function renderPicker() {
    screen = 'pick';
    var html = '<div class="kg-prompt">' + KG.dogSVG('happy', 56) + '<div class="kg-bubble">选一幅画吧</div></div><div class="pics">';
    PICS.forEach(function (p, i) {
      var arr = fillsOf(p);
      html += '<button class="thumb" data-nav data-i="' + i + '">' + svgHTML(p, arr) + (isDone(arr) ? '<span class="done">★</span>' : '') + '</button>';
    });
    html += '</div>';
    main.innerHTML = html;
    Array.prototype.forEach.call(main.querySelectorAll('.thumb'), function (b) {
      b.addEventListener('click', function () { KG.sfx('tap'); openPic(+b.getAttribute('data-i')); });
    });
    KG.nav.refresh(main.querySelectorAll('.thumb')[lastPic]);
  }

  /* ---------- 涂色 ---------- */
  function openPic(i) {
    screen = 'paint';
    lastPic = i;
    pic = PICS[i];
    fills = fillsOf(pic);
    var html = '<div class="paint"><div class="canvas">' + svgHTML(pic, fills);
    if (KG.nav.enabled) {
      pic.regions.forEach(function (r, k) {
        html += '<button class="rp" data-nav data-r="' + k + '" style="left:' + (r.p[0] / 2) + '%;top:' + (r.p[1] / 2) + '%" aria-label="区域"></button>';
      });
    }
    html += '</div><div class="palette">';
    COLORS.forEach(function (c, k) {
      html += '<button class="sw" data-nav data-c="' + k + '" style="background:' + c.c + '" aria-label="' + c.say.zh + '"></button>';
    });
    html += '</div></div>';
    main.innerHTML = html;
    canvasEl = main.querySelector('.canvas');

    canvasEl.querySelector('svg').addEventListener('click', function (e) {
      var r = e.target && e.target.getAttribute && e.target.getAttribute('data-r');
      if (r !== null && r !== undefined && r !== '') fillRegion(+r);
    });
    Array.prototype.forEach.call(canvasEl.querySelectorAll('.rp'), function (b) {
      b.addEventListener('click', function () { fillRegion(+b.getAttribute('data-r')); });
    });
    Array.prototype.forEach.call(main.querySelectorAll('.sw'), function (b) {
      b.addEventListener('click', function () { selectColor(COLORS[+b.getAttribute('data-c')], true); });
    });
    selectColor(cur, false);
    KG.nav.refresh(main.querySelector('.sw.on'));
    updateHl();
    KG.sayAll([pic.say, PROMPT_PAINT]);
  }

  function selectColor(c, speak) {
    cur = c;
    Array.prototype.forEach.call(main.querySelectorAll('.sw'), function (b) {
      b.classList.toggle('on', COLORS[+b.getAttribute('data-c')] === c);
    });
    canvasEl.style.setProperty('--cur', c.c);
    if (speak) { KG.sfx('pick'); KG.say(c.say); }
  }

  function fillRegion(i) {
    if (screen !== 'paint' || KG.paused) return;
    var wasDone = isDone(fills);
    fills[i] = cur.id;
    var el = canvasEl.querySelector('.rg[data-r="' + i + '"]');
    if (el) el.setAttribute('fill', cur.c);
    KG.sfx('drop');
    data.pics[pic.id] = fills.slice();
    KG.save(data);
    if (!wasDone && isDone(fills)) {
      KG.recordStars(pic.id, 3);
      // recordStars 会重新读写存档，这里同步一下内存里的副本
      data = KG.load() || data;
      data.pics = data.pics || {};
      data.pics[pic.id] = fills.slice();
      setTimeout(celebrate, 500);
    }
  }

  function celebrate() {
    if (screen !== 'paint') return;
    KG.showWin({
      replayText: '继续涂',
      onReplay: function () { KG.nav.refresh(main.querySelector('.sw.on')); },
      nextText: '换一幅',
      onNext: function () { backToPicker(); }
    });
  }

  /** 遥控器焦点落在某个区域的焦点点上时，给对应区域描一圈虚线。 */
  function updateHl() {
    if (screen !== 'paint' || !canvasEl) return;
    var f = KG.nav.current();
    var r = f && f.classList.contains('rp') ? f.getAttribute('data-r') : null;
    Array.prototype.forEach.call(canvasEl.querySelectorAll('.rg'), function (g) {
      g.classList.toggle('hl', g.getAttribute('data-r') === r);
    });
  }

  function backToPicker() {
    KG.stopSay();
    renderPicker();
  }

  /* ---------- 启动 ---------- */
  KG.init({
    id: 'coloring',
    nav: true,
    onInput: function () {
      // 让 KidsGame.nav 先移动焦点，再更新高亮
      setTimeout(updateHl, 0);
      return false;
    },
    onBack: function () {
      if (screen === 'paint') { backToPicker(); return true; }
      return false;
    },
    onPause: function () {},
    onResume: function () {}
  });
  var header = KG.mountHeader('涂色');
  // 涂色时，顶栏返回键先回到选画
  header.addEventListener('click', function (e) {
    if (screen === 'paint' && e.target.closest && e.target.closest('.kg-back')) {
      e.stopPropagation();
      backToPicker();
    }
  }, true);

  renderPicker();
  KG.say(PROMPT_PICK);
})();
