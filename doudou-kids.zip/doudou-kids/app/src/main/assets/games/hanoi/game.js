/* 汉诺塔：点（或 OK）一根柱子拿起最上面的圆盘，再点另一根放下。 */
(function () {
  'use strict';
  var KG = window.KidsGame;
  var COLORS = ['#F2A65A', '#E8D36A', '#7FCDB9', '#6FA8FF', '#A991E8', '#EF8FA8', '#9CC97A'];

  var main = document.getElementById('main');
  var pegEls = Array.prototype.slice.call(document.querySelectorAll('.hn-peg'));
  var countsEl = document.getElementById('counts');
  var msgEl = document.getElementById('msg');
  var bDemo = document.getElementById('bDemo');

  var n = 3, pegs = [[], [], []], held = -1, moves = 0, done = false;
  var demo = null; // {steps, i, timer}

  KG.init({ id: 'hanoi', nav: true, onPause: pauseDemo, onResume: resumeDemo });
  KG.mountHeader('汉诺塔');

  var data = KG.load() || {};
  if (data.n >= 3 && data.n <= 7) n = data.n;

  // 圆盘数量选择
  var chips = '<span style="color:var(--muted);font-size:15px">圆盘</span>';
  for (var k = 3; k <= 7; k++) chips += '<button class="kg-chip" data-nav data-n="' + k + '">' + k + '</button>';
  var chipRow = KG.el('<div class="kg-row hn-chips" style="gap:8px;align-items:center">' + chips + '</div>');
  main.insertBefore(chipRow, countsEl);
  chipRow.addEventListener('click', function (e) {
    var b = e.target.closest('[data-n]');
    if (!b) return;
    n = +b.getAttribute('data-n');
    var d = KG.load() || {};
    d.n = n;
    KG.save(d);
    KG.sfx('tap');
    reset();
  });

  function minMoves() { return Math.pow(2, n) - 1; }
  function best() { var d = KG.load() || {}; return d.best ? d.best[n] : 0; }

  function reset() {
    stopDemo();
    pegs = [[], [], []];
    for (var i = n; i >= 1; i--) pegs[0].push(i);
    held = -1; moves = 0; done = false;
    msgEl.textContent = '把所有圆盘移到 C 柱。一次只能移一个，大盘不能压在小盘上。';
    render();
  }

  function render() {
    var b = best();
    countsEl.innerHTML = '<span>最少 <b>' + minMoves() + '</b> 步</span><span>你的步数 <b>' + moves + '</b></span>'
      + (b ? '<span>最佳 <b>' + b + '</b></span>' : '');
    Array.prototype.forEach.call(chipRow.querySelectorAll('[data-n]'), function (c) {
      c.classList.toggle('on', +c.getAttribute('data-n') === n);
    });
    var pegH = pegEls[0].clientHeight || 260;
    var w = pegEls[0].clientWidth || 100;
    var dh = Math.max(14, Math.min(30, Math.floor((pegH * 0.72 - 30) / 7)));
    pegEls.forEach(function (el, p) {
      var html = '';
      pegs[p].forEach(function (size, idx) {
        var width = Math.round(w * (0.26 + 0.66 * (size - 1) / 6));
        var up = p === held && idx === pegs[p].length - 1;
        html += '<i class="hn-disc' + (up ? ' up' : '') + '" style="width:' + width + 'px;height:' + dh + 'px;background:' + COLORS[size - 1] + '">' + size + '</i>';
      });
      el.querySelector('.hn-stack').innerHTML = html;
      el.classList.toggle('target', held >= 0 && p !== held);
    });
    bDemo.textContent = demo ? '停止演示' : '演示';
  }
  window.addEventListener('resize', render);

  function canMove(from, to) {
    var a = pegs[from], b = pegs[to];
    return a.length > 0 && (b.length === 0 || b[b.length - 1] > a[a.length - 1]);
  }
  function doMove(from, to) {
    pegs[to].push(pegs[from].pop());
    moves++;
  }

  function tapPeg(p) {
    if (demo) { KG.toast('正在演示，点「停止演示」后再玩'); return; }
    if (done) { reset(); return; }
    if (held < 0) {
      if (!pegs[p].length) { KG.toast('这根柱子上没有圆盘'); return; }
      held = p;
      KG.sfx('pick');
    } else if (held === p) {
      held = -1;
      KG.sfx('drop');
    } else if (!canMove(held, p)) {
      KG.shake(pegEls[p]);
      KG.sfx('drop');
      KG.toast('大盘不能压在小盘上');
      held = -1;
    } else {
      doMove(held, p);
      held = -1;
      KG.sfx('drop');
      if (pegs[2].length === n) win();
    }
    render();
  }

  function win() {
    done = true;
    var min = minMoves();
    var stars = moves === min ? 3 : (moves <= Math.ceil(min * 1.5) ? 2 : 1);
    var d = KG.load() || {};
    d.best = d.best || {};
    var isBest = !d.best[n] || moves < d.best[n];
    if (isBest) d.best[n] = moves;
    KG.save(d);
    KG.recordStars('n' + n, stars);
    msgEl.textContent = '完成！';
    setTimeout(function () {
      KG.showWin({
        title: moves === min ? '完美！' : '完成！',
        text: n + ' 个圆盘用了 ' + moves + ' 步，最少需要 ' + min + ' 步' + (isBest ? '（新纪录）' : ''),
        stars: stars,
        onReplay: reset,
        nextText: n < 7 ? '试试 ' + (n + 1) + ' 个' : undefined,
        onNext: n < 7 ? function () { n++; var dd = KG.load() || {}; dd.n = n; KG.save(dd); reset(); } : undefined
      });
    }, 300);
  }

  /* ---------- 演示：递归求最优解 ---------- */
  function solveSteps(k, from, to, via, out) {
    if (k === 0) return;
    solveSteps(k - 1, from, via, to, out);
    out.push([from, to]);
    solveSteps(k - 1, via, to, from, out);
  }
  function startDemo() {
    reset();
    var steps = [];
    solveSteps(n, 0, 2, 1, steps);
    demo = { steps: steps, i: 0, timer: null };
    msgEl.textContent = '演示：先把上面 ' + (n - 1) + ' 个移到 B，再把最大的移到 C，最后把 B 上的移到 C。';
    resumeDemo();
    render();
  }
  function demoTick() {
    if (!demo) return;
    var s = demo.steps[demo.i++];
    doMove(s[0], s[1]);
    KG.sfx('tap');
    if (demo.i >= demo.steps.length) {
      clearInterval(demo.timer);
      demo = null;
      done = true;
      msgEl.textContent = '演示完成：共 ' + moves + ' 步，就是最少步数 2^' + n + ' − 1。点任意柱子自己试试！';
    }
    render();
  }
  function pauseDemo() { if (demo && demo.timer) { clearInterval(demo.timer); demo.timer = null; } }
  function resumeDemo() {
    if (demo && !demo.timer) demo.timer = setInterval(demoTick, n >= 6 ? 280 : 520);
  }
  function stopDemo() { pauseDemo(); demo = null; }

  pegEls.forEach(function (el, p) { el.addEventListener('click', function () { tapPeg(p); }); });
  document.getElementById('bReset').addEventListener('click', function () { KG.sfx('tap'); reset(); });
  bDemo.addEventListener('click', function () {
    if (demo) { reset(); return; }
    startDemo();
  });

  reset();
  KG.nav.refresh();
})();
