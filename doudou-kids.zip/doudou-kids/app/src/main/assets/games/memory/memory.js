/* 记忆翻牌：翻开两张一样的牌。4 / 8 / 12 / 16 张，按步数评星，保存每种张数的最好成绩。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var ITEMS = [
    { e: '🐶', key: 'animal_dog', zh: '小狗', en: 'dog' },
    { e: '🐱', key: 'animal_cat', zh: '小猫', en: 'cat' },
    { e: '🐰', key: 'animal_rabbit', zh: '小兔子', en: 'rabbit' },
    { e: '🐼', key: 'animal_panda', zh: '熊猫', en: 'panda' },
    { e: '🦁', key: 'animal_lion', zh: '狮子', en: 'lion' },
    { e: '🐸', key: 'animal_frog', zh: '青蛙', en: 'frog' },
    { e: '🐵', key: 'animal_monkey', zh: '猴子', en: 'monkey' },
    { e: '🐷', key: 'animal_pig', zh: '小猪', en: 'pig' },
    { e: '🐘', key: 'animal_elephant', zh: '大象', en: 'elephant' },
    { e: '🍎', key: 'food_apple', zh: '苹果', en: 'apple' },
    { e: '🍌', key: 'food_banana', zh: '香蕉', en: 'banana' },
    { e: '🍇', key: 'food_grape', zh: '葡萄', en: 'grapes' },
    { e: '🍉', key: 'food_watermelon', zh: '西瓜', en: 'watermelon' },
    { e: '🍓', key: 'food_strawberry', zh: '草莓', en: 'strawberry' },
    { e: '🚗', key: 'vehicle_car', zh: '汽车', en: 'car' },
    { e: '🚌', key: 'vehicle_bus', zh: '公交车', en: 'bus' },
    { e: '🚀', key: 'vehicle_rocket', zh: '火箭', en: 'rocket' },
    { e: '⭐', key: 'item_star', zh: '星星', en: 'star' },
    { e: '⚽', key: 'item_football', zh: '足球', en: 'football' },
    { e: '🌸', key: 'item_flower', zh: '花', en: 'flower' }
  ];
  var SIZES = [4, 8, 12, 16];

  var profile = KG.init({ id: 'memory', nav: true, onPause: onPause, onResume: onResume });
  var tier = profile.ageTier;
  var saved = KG.load() || {};
  var size = tier === 'qm' ? 4 : (tier === 'tq' ? 8 : 12);
  if (saved.lastSize && SIZES.indexOf(saved.lastSize) >= 0) size = saved.lastSize;

  KG.mountHeader('记忆翻牌', '<span class="kg-chip" id="stat"></span>');
  var $stat = document.getElementById('stat');
  var $sizes = document.getElementById('sizes');
  var $wrap = document.getElementById('wrap');
  var $board = document.getElementById('board');

  var cards = [], first = null, lock = false, moves = 0, found = 0;
  var flipBackTimer = null, flipBackFn = null, winTimer = null;

  /* ---------- 难度按钮 ---------- */
  function renderSizes() {
    $sizes.innerHTML = SIZES.map(function (n) {
      return '<button class="mem-size' + (n === size ? ' on' : '') + '" data-nav data-size="' + n + '">' + n + ' 张</button>';
    }).join('');
  }
  $sizes.addEventListener('click', function (e) {
    var b = e.target.closest('[data-size]'); if (!b) return;
    var n = +b.getAttribute('data-size');
    KG.sfx('tap');
    if (n === size) return;
    size = n;
    renderSizes();
    KG.nav.refresh($sizes.querySelector('[data-size="' + n + '"]'));
    newGame();
  });

  /* ---------- 牌面 ---------- */
  function newGame() {
    clearTimers();
    var pairs = size / 2;
    var picked = KG.shuffle(ITEMS).slice(0, pairs);
    var deck = [];
    picked.forEach(function (it) { deck.push(it, it); });
    deck = KG.shuffle(deck);
    cards = deck.map(function (it, i) { return { i: i, item: it, up: false, done: false, el: null }; });
    first = null; lock = false; moves = 0; found = 0;
    saved.lastSize = size;
    KG.save(saved);

    var back = tier === 'sn' ? '<b>?</b>' : KG.dogSVG('happy', 48);
    $board.innerHTML = cards.map(function (c) {
      return '<button class="mem-card" data-nav data-i="' + c.i + '" aria-label="第' + (c.i + 1) + '张牌"><span class="mem-inner">'
        + '<span class="mem-face mem-back">' + back + '</span>'
        + '<span class="mem-face mem-front"><span>' + c.item.e + '</span></span></span></button>';
    }).join('');
    Array.prototype.forEach.call($board.children, function (el, i) { cards[i].el = el; });
    layout();
    updateStat();
    KG.nav.refresh($board.firstChild);
    if (tier === 'qm') KG.say({ key: 'prompt_memory_1', zh: '翻开两张一样的牌' });
  }

  /** 选能让方牌最大的列数。 */
  function layout() {
    var n = cards.length; if (!n) return;
    var gap = 10;
    var w = $wrap.clientWidth - 8, h = $wrap.clientHeight - 8;
    var best = 0, bestCols = 1;
    for (var cols = 1; cols <= n; cols++) {
      var rows = Math.ceil(n / cols);
      var s = Math.min((w - gap * (cols - 1)) / cols, (h - gap * (rows - 1)) / rows);
      if (s > best) { best = s; bestCols = cols; }
    }
    var cell = Math.max(40, Math.floor(Math.min(best, 170)));
    $board.style.gridTemplateColumns = 'repeat(' + bestCols + ',' + cell + 'px)';
    cards.forEach(function (c) {
      c.el.style.width = cell + 'px';
      c.el.style.height = cell + 'px';
      c.el.querySelector('.mem-front').style.fontSize = Math.round(cell * 0.58) + 'px';
      var b = c.el.querySelector('.mem-back b');
      if (b) b.style.fontSize = Math.round(cell * 0.45) + 'px';
      var dog = c.el.querySelector('.mem-back svg');
      if (dog) { dog.setAttribute('width', Math.round(cell * 0.55)); dog.setAttribute('height', Math.round(cell * 0.55)); }
    });
  }

  function updateStat() {
    $stat.textContent = moves + ' 步 · ' + found + '/' + (cards.length / 2) + ' 对';
  }

  function setUp(c, up) {
    c.up = up;
    c.el.classList.toggle('up', up);
  }

  $board.addEventListener('click', function (e) {
    var el = e.target.closest('.mem-card'); if (!el) return;
    onCard(cards[+el.getAttribute('data-i')]);
  });

  function onCard(c) {
    if (!c || lock || c.up || c.done || KG.paused) return;
    KG.sfx('tap');
    setUp(c, true);
    if (!first) {
      first = c;
      KG.say(c.item);
      return;
    }
    var a = first;
    first = null;
    moves++;
    if (a.item === c.item) {
      a.done = c.done = true;
      a.el.classList.add('done'); c.el.classList.add('done');
      found++;
      updateStat();
      KG.sfx('ok');
      KG.sayAll(tier === 'sn' ? [c.item] : [KG.praiseItem(), c.item]);
      if (found === cards.length / 2) winTimer = setTimeout(win, 900);
    } else {
      updateStat();
      KG.say(c.item);
      lock = true;
      flipBackFn = function () {
        flipBackTimer = null; flipBackFn = null;
        setUp(a, false); setUp(c, false);
        lock = false;
      };
      flipBackTimer = setTimeout(flipBackFn, 1100);
    }
  }

  function starsFor(pairs, m) {
    if (m <= Math.ceil(pairs * 1.6) + 1) return 3;
    if (m <= Math.ceil(pairs * 2.5) + 1) return 2;
    return 1;
  }

  function win() {
    winTimer = null;
    var pairs = cards.length / 2;
    var stars = starsFor(pairs, moves);
    var p = KG.recordStars('n' + size, stars);
    p.best = p.best || {};
    var prev = p.best[size];
    var isBest = !prev || moves < prev;
    if (isBest) p.best[size] = moves;
    p.lastSize = size;
    KG.save(p);
    saved = p;
    var text = '用了 ' + moves + ' 步' + (isBest ? (prev ? '，新纪录！' : '') : '，最好成绩 ' + prev + ' 步');
    var idx = SIZES.indexOf(size);
    var nextSize = idx < SIZES.length - 1 ? SIZES[idx + 1] : 0;
    KG.showWin({
      stars: stars,
      text: text,
      onReplay: newGame,
      onNext: nextSize ? function () { size = nextSize; renderSizes(); newGame(); } : null,
      nextText: nextSize ? '试试 ' + nextSize + ' 张' : ''
    });
  }

  function clearTimers() {
    if (flipBackTimer) clearTimeout(flipBackTimer);
    if (winTimer) clearTimeout(winTimer);
    flipBackTimer = flipBackFn = winTimer = null;
  }

  function onPause() {
    if (flipBackTimer) { clearTimeout(flipBackTimer); flipBackTimer = null; }
    if (winTimer) { clearTimeout(winTimer); winTimer = 'paused'; }
  }
  function onResume() {
    if (flipBackFn && !flipBackTimer) flipBackTimer = setTimeout(flipBackFn, 600);
    if (winTimer === 'paused') winTimer = setTimeout(win, 300);
  }

  var resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(layout, 120);
  });

  renderSizes();
  newGame();
})();
