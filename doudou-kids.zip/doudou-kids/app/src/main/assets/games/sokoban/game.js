/* 推箱子：滑动 / 方向键盘 / 点格子走过去（触屏），方向键移动、OK 打开菜单（电视）。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var main = document.getElementById('main');
  var wrap = document.getElementById('wrap');
  var stage = document.getElementById('stage');
  var boardEl = document.getElementById('board');
  var infoEl = document.getElementById('info');
  var tipEl = document.getElementById('tip');

  var levels = [], cur = 0;
  var L = null;             // {w, h, wall[], goal[], inside[]}
  var boxes = [], player = 0, moves = 0, pushes = 0, history = [], won = false;
  var boxEls = [], playerEl = null, cs = 32;
  var walkTimer = null;

  KG.init({ id: 'sokoban', nav: true, onInput: onInput, onPause: stopWalk });
  KG.mountHeader('推箱子', '<button class="kg-chip" data-nav id="bLevels">选关</button>');
  document.getElementById('bLevels').addEventListener('click', showLevels);
  tipEl.textContent = KG.isDpad() ? '方向键移动 · OK 键打开菜单（撤销、重来、选关）' : '滑动屏幕、按方向键或点格子来移动';

  /* ---------- 加载关卡 ---------- */
  function loadJSON(url, cb) {
    function xhr() {
      var x = new XMLHttpRequest();
      x.open('GET', url);
      x.onload = function () { try { cb(JSON.parse(x.responseText)); } catch (e) { cb(null); } };
      x.onerror = function () { cb(null); };
      x.send();
    }
    if (window.fetch) {
      fetch(url).then(function (r) { return r.json(); }).then(cb, xhr);
    } else xhr();
  }

  function data() { return KG.load() || {}; }

  loadJSON('levels.json', function (json) {
    if (!json || !json.levels) { infoEl.textContent = '关卡加载失败'; return; }
    levels = json.levels;
    var d = data();
    cur = typeof d.cur === 'number' && d.cur < levels.length ? d.cur : 0;
    startLevel(cur);
  });

  function parse(map) {
    var h = map.length, w = 0, i, x, y;
    for (i = 0; i < h; i++) w = Math.max(w, map[i].length);
    var res = { w: w, h: h, wall: [], goal: [], inside: [], boxes: [], player: 0 };
    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        var ch = map[y][x] || ' ', k = y * w + x;
        res.wall[k] = ch === '#';
        res.goal[k] = ch === '.' || ch === '*' || ch === '+';
        if (ch === '$' || ch === '*') res.boxes.push(k);
        if (ch === '@' || ch === '+') res.player = k;
      }
    }
    // 从玩家出发能到达的格子才画地板
    var q = [res.player];
    res.inside[res.player] = true;
    while (q.length) {
      var p = q.pop();
      [-1, 1, -w, w].forEach(function (dd) {
        var np = p + dd;
        if (np >= 0 && np < w * h && !res.wall[np] && !res.inside[np]) { res.inside[np] = true; q.push(np); }
      });
    }
    return res;
  }

  function startLevel(i) {
    stopWalk();
    cur = i;
    var d = data();
    d.cur = i;
    KG.save(d);
    L = parse(levels[i].map);
    boxes = L.boxes.slice();
    player = L.player;
    moves = 0; pushes = 0; history = []; won = false;
    build();
    KG.nav.refresh(stage);
  }

  /* ---------- 绘制 ---------- */
  function build() {
    var html = '', k;
    for (k = 0; k < L.w * L.h; k++) {
      if (L.wall[k]) html += '<i class="sb-wall" data-k="' + k + '"></i>';
      else if (L.inside[k]) html += '<i class="sb-floor' + (L.goal[k] ? ' sb-goal' : '') + '" data-k="' + k + '"></i>';
    }
    boxes.forEach(function () { html += '<i class="sb-box"></i>'; });
    html += '<i class="sb-player"><b class="l"></b><b class="r"></b></i>';
    boardEl.innerHTML = html;
    boxEls = Array.prototype.slice.call(boardEl.querySelectorAll('.sb-box'));
    playerEl = boardEl.querySelector('.sb-player');
    layout();
  }
  function place(el, k, inset) {
    var x = k % L.w, y = Math.floor(k / L.w);
    el.style.transform = 'translate(' + (x * cs + inset) + 'px,' + (y * cs + inset) + 'px)';
  }
  function layout() {
    if (!L) return;
    var land = main.clientWidth > main.clientHeight * 1.15;
    wrap.classList.toggle('land', land);
    var W = stage.clientWidth - 8, H = stage.clientHeight - 8;
    cs = Math.max(16, Math.min(64, Math.floor(Math.min(W / L.w, H / L.h))));
    boardEl.style.width = cs * L.w + 'px';
    boardEl.style.height = cs * L.h + 'px';
    Array.prototype.forEach.call(boardEl.querySelectorAll('[data-k]'), function (el) {
      var k = +el.getAttribute('data-k'), wall = el.classList.contains('sb-wall');
      el.style.width = el.style.height = (wall ? cs - 2 : cs) + 'px';
      place(el, k, wall ? 1 : 0);
    });
    boxEls.concat([playerEl]).forEach(function (el) { el.style.width = el.style.height = cs + 'px'; });
    // 布局时不要动画
    boxEls.concat([playerEl]).forEach(function (el) { el.style.transition = 'none'; });
    render();
    void boardEl.offsetWidth;
    boxEls.concat([playerEl]).forEach(function (el) { el.style.transition = ''; });
  }
  window.addEventListener('resize', layout);

  function render() {
    var onGoal = 0;
    boxes.forEach(function (b, i) {
      place(boxEls[i], b, 0);
      var on = !!L.goal[b];
      if (on) onGoal++;
      boxEls[i].classList.toggle('on', on);
    });
    place(playerEl, player, 0);
    var best = (data().best || {})[cur];
    infoEl.innerHTML = '<span><b>第 ' + (cur + 1) + ' 关</b> ' + (levels[cur].name || '') + '</span>'
      + '<span>步数 <b>' + moves + '</b></span>'
      + '<span>箱子 <b>' + onGoal + '/' + boxes.length + '</b></span>'
      + '<span>最佳 <b>' + (best || '—') + '</b></span>';
  }

  /* ---------- 移动 ---------- */
  function delta(dir) { return dir === 'up' ? -L.w : dir === 'down' ? L.w : dir === 'left' ? -1 : 1; }
  function step(dir) {
    if (!L || won) return false;
    var d = delta(dir), np = player + d;
    if (L.wall[np]) return false;
    var bi = boxes.indexOf(np);
    if (bi >= 0) {
      var nb = np + d;
      if (L.wall[nb] || boxes.indexOf(nb) >= 0) return false;
      boxes[bi] = nb;
      pushes++;
      KG.sfx(L.goal[nb] ? 'pop' : 'tap');
    }
    history.push({ p: player, bi: bi, d: d });
    player = np;
    moves++;
    render();
    checkWin();
    return true;
  }
  function undo() {
    stopWalk();
    var h = history.pop();
    if (!h || won) { if (!h) KG.toast('已经是开始的样子了'); return; }
    player = h.p;
    if (h.bi >= 0) { boxes[h.bi] -= h.d; pushes--; }
    moves--;
    KG.sfx('drop');
    render();
  }
  function restart() { KG.sfx('tap'); startLevel(cur); }

  function checkWin() {
    for (var i = 0; i < boxes.length; i++) if (!L.goal[boxes[i]]) return;
    won = true;
    stopWalk();
    var par = levels[cur].par || moves;
    var stars = moves <= par ? 3 : (moves <= Math.ceil(par * 1.5) ? 2 : 1);
    var d = data();
    d.best = d.best || {};
    var isBest = !d.best[cur] || moves < d.best[cur];
    if (isBest) d.best[cur] = moves;
    var hasNext = cur + 1 < levels.length;
    if (hasNext) d.cur = cur + 1;
    KG.save(d);
    KG.recordStars('L' + (cur + 1), stars);
    var lv = cur;
    setTimeout(function () {
      KG.showWin({
        title: '第 ' + (lv + 1) + ' 关完成',
        text: '用了 ' + moves + ' 步（最少 ' + par + ' 步）' + (isBest ? '，新纪录' : ''),
        stars: stars,
        onReplay: function () { startLevel(lv); },
        onNext: hasNext ? function () { startLevel(lv + 1); } : undefined
      });
      if (!hasNext) KG.toast('全部关卡都完成了，真厉害！');
    }, 260);
  }

  /* 点格子：走到那里（不推箱子） */
  function walkTo(target) {
    stopWalk();
    if (!L.inside[target] || boxes.indexOf(target) >= 0 || target === player) return;
    var prev = {}, q = [player], dirs = ['up', 'down', 'left', 'right'];
    prev[player] = -1;
    while (q.length && prev[target] === undefined) {
      var p = q.shift();
      for (var i = 0; i < 4; i++) {
        var np = p + delta(dirs[i]);
        if (prev[np] !== undefined || L.wall[np] || boxes.indexOf(np) >= 0 || !L.inside[np]) continue;
        prev[np] = p;
        q.push(np);
      }
    }
    if (prev[target] === undefined) return;
    var path = [];
    for (var c = target; c !== player; c = prev[c]) path.unshift(c);
    walkTimer = setInterval(function () {
      var nxt = path.shift();
      if (nxt === undefined) { stopWalk(); return; }
      var dd = nxt - player;
      step(dd === -L.w ? 'up' : dd === L.w ? 'down' : dd === -1 ? 'left' : 'right');
    }, 90);
  }
  function stopWalk() { if (walkTimer) { clearInterval(walkTimer); walkTimer = null; } }

  /* ---------- 触屏：滑动 + 点击 ---------- */
  var sp = null;
  stage.addEventListener('pointerdown', function (e) {
    if (sp) return;
    sp = { id: e.pointerId, x: e.clientX, y: e.clientY };
  });
  function endSwipe(e) {
    if (!sp || e.pointerId !== sp.id) return;
    var dx = e.clientX - sp.x, dy = e.clientY - sp.y;
    sp = null;
    if (e.type === 'pointercancel' || !L) return;
    if (Math.abs(dx) + Math.abs(dy) > 24) {
      stopWalk();
      if (Math.abs(dx) > Math.abs(dy)) step(dx > 0 ? 'right' : 'left');
      else step(dy > 0 ? 'down' : 'up');
      return;
    }
    var r = boardEl.getBoundingClientRect();
    var x = Math.floor((e.clientX - r.left) / cs), y = Math.floor((e.clientY - r.top) / cs);
    if (x < 0 || y < 0 || x >= L.w || y >= L.h) return;
    var k = y * L.w + x, px = player % L.w, py = Math.floor(player / L.w);
    if (Math.abs(x - px) + Math.abs(y - py) === 1) {
      stopWalk();
      step(x > px ? 'right' : x < px ? 'left' : y > py ? 'down' : 'up');
    } else walkTo(k);
  }
  stage.addEventListener('pointerup', endSwipe);
  stage.addEventListener('pointercancel', endSwipe);

  /* 屏幕方向键：按住连续移动 */
  var repeat = null;
  function stopRepeat() { if (repeat) { clearTimeout(repeat.t); clearInterval(repeat.i); repeat = null; } }
  Array.prototype.forEach.call(document.querySelectorAll('.sb-arrow'), function (b) {
    var dir = b.getAttribute('data-dir');
    b.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      stopRepeat(); stopWalk();
      step(dir);
      var r = { t: 0, i: 0 };
      r.t = setTimeout(function () { r.i = setInterval(function () { step(dir); }, 150); }, 380);
      repeat = r;
    });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) { b.addEventListener(ev, stopRepeat); });
  });
  document.getElementById('bUndo').addEventListener('click', undo);
  document.getElementById('bRestart').addEventListener('click', restart);

  // 外接键盘的撤销 / 重来
  document.addEventListener('keydown', function (e) {
    if (document.querySelector('.kg-overlay')) return;
    if (e.key === 'z' || e.key === 'Z' || e.key === 'Backspace') { undo(); e.preventDefault(); }
    else if (e.key === 'r' || e.key === 'R') restart();
  });

  /* ---------- 遥控器 ---------- */
  function onInput(key) {
    if (!L || document.querySelector('.kg-overlay')) return false;
    var onBoard = !KG.nav.enabled || KG.nav.current() === stage;
    if (!onBoard) return false;
    if (key === 'up' || key === 'down' || key === 'left' || key === 'right') { stopWalk(); step(key); return true; }
    if (key === 'ok' && KG.nav.enabled) { showMenu(); return true; }
    return false;
  }

  function overlay(html, onBack) {
    var ov = KG.el('<div class="kg-overlay"><div class="kg-card sb-ov-card">' + html + '</div></div>');
    ov._onBack = function () { close(); if (onBack) onBack(); };
    function close() { ov.remove(); KG.nav.refresh(stage); }
    ov._close = close;
    document.body.appendChild(ov);
    if (KG.nav.enabled) KG.nav.focus(ov.querySelector('[data-autofocus]') || ov.querySelector('[data-nav]'));
    return ov;
  }
  function showMenu() {
    var ov = overlay('<h2>菜单</h2><div class="sb-menu">'
      + '<button class="kg-btn" data-nav data-autofocus data-a="undo">撤销一步</button>'
      + '<button class="kg-btn ghost" data-nav data-a="resume">继续</button>'
      + '<button class="kg-btn ghost" data-nav data-a="restart">重新开始</button>'
      + '<button class="kg-btn ghost" data-nav data-a="levels">选择关卡</button>'
      + '<button class="kg-btn ghost" data-nav data-a="exit">退出游戏</button></div>');
    ov.addEventListener('click', function (e) {
      var b = e.target.closest('[data-a]');
      if (!b) return;
      var a = b.getAttribute('data-a');
      ov._close();
      if (a === 'undo') undo();
      else if (a === 'restart') restart();
      else if (a === 'levels') showLevels();
      else if (a === 'exit') KG.exit();
    });
  }
  function showLevels() {
    if (!levels.length) return;
    var d = data(), best = d.best || {}, stars = d.stars || {}, html = '<h2>选择关卡</h2><div class="sb-levels">';
    levels.forEach(function (lv, i) {
      var st = stars['L' + (i + 1)] || 0, s = '';
      for (var j = 0; j < st; j++) s += '★';
      html += '<button class="sb-lv' + (best[i] ? ' done' : '') + (i === cur ? ' cur' : '') + '" data-nav data-i="' + i + '"'
        + (i === cur ? ' data-autofocus' : '') + '>' + (i + 1) + '<small>' + (s || (best[i] ? '✓' : '')) + '</small></button>';
    });
    html += '</div><button class="kg-btn ghost" data-nav data-close>关闭</button>';
    var ov = overlay(html);
    ov.addEventListener('click', function (e) {
      var b = e.target.closest('[data-i]');
      if (b) { ov._close(); startLevel(+b.getAttribute('data-i')); return; }
      if (e.target.closest('[data-close]')) ov._close();
    });
  }
})();
