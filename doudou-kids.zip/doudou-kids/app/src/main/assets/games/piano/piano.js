/* 动物钢琴：8 个琴键（C 大调音阶），自由弹 / 跟着弹《小星星》。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var KEYS = [
    { f: 261.63, c: '#EF4444', a: '🐶' },
    { f: 293.66, c: '#FB923C', a: '🐱' },
    { f: 329.63, c: '#F5B800', a: '🐥' },
    { f: 349.23, c: '#3FBF5A', a: '🐸' },
    { f: 392.00, c: '#2DB7C4', a: '🐰' },
    { f: 440.00, c: '#3B82F6', a: '🐼' },
    { f: 493.88, c: '#9B6BEA', a: '🐻' },
    { f: 523.25, c: '#F472B6', a: '🐷' }
  ];
  // 《小星星》（公有领域），0=C 1=D 2=E 3=F 4=G 5=A；每 7 个音一句
  var TWINKLE = [0, 0, 4, 4, 5, 5, 4, 3, 3, 2, 2, 1, 1, 0,
    4, 4, 3, 3, 2, 2, 1, 4, 4, 3, 3, 2, 2, 1,
    0, 0, 4, 4, 5, 5, 4, 3, 3, 2, 2, 1, 1, 0];
  var PHRASE = 7;
  // 启蒙档只弹前两句，其余档弹完整首
  var SONG = KG.profile.ageTier === 'qm' ? TWINKLE.slice(0, 14) : TWINKLE;

  var PROMPT_FREE = { key: 'prompt_piano_1', zh: '按一按琴键，听听小动物唱歌' };
  var PROMPT_FOLLOW = { key: 'prompt_piano_2', zh: '跟着亮亮的琴键弹一弹吧' };

  var main = document.getElementById('main');
  var keysEl = document.getElementById('keys');
  var fillEl = document.getElementById('songFill');
  var keyEls = [];
  var follow = false, pos = 0, finishing = false;
  var demoTimers = [], demoing = false;
  var lastPointer = 0;

  /* ---------- 琴键 ---------- */
  KEYS.forEach(function (k, i) {
    var b = KG.el('<button class="key" data-nav style="--kc:' + k.c + '"><div class="face"><div class="ani"><span>' + k.a + '</span></div><div class="pad"></div></div></button>');
    b.style.background = k.c; // 旧 WebView 不支持 CSS 变量时兜底
    b.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      lastPointer = Date.now();
      press(i);
    });
    // 遥控器确认键会触发 click；触屏已在 pointerdown 中处理过，忽略随后的 click
    b.addEventListener('click', function () {
      if (Date.now() - lastPointer < 800) return;
      press(i);
    });
    keysEl.appendChild(b);
    keyEls.push(b);
  });

  function sound(i) {
    KG.note(KEYS[i].f, 0.5);
    var b = keyEls[i], ani = b.querySelector('.ani');
    b.classList.add('down');
    setTimeout(function () { b.classList.remove('down'); }, 160);
    ani.classList.remove('hop');
    void ani.offsetWidth;
    ani.classList.add('hop');
  }

  function press(i) {
    if (KG.paused) return;
    sound(i);
    if (!follow || finishing || demoing) return;
    if (i === SONG[pos]) {
      pos++;
      updateFollow();
      if (pos >= SONG.length) {
        finishing = true;
        setTimeout(finishSong, 700);
      }
    }
  }

  /* ---------- 跟着弹 ---------- */
  function updateFollow() {
    keyEls.forEach(function (b, i) {
      b.classList.toggle('target', follow && !demoing && pos < SONG.length && SONG[pos] === i);
    });
    fillEl.style.width = (follow ? Math.round(pos / SONG.length * 100) : 0) + '%';
  }

  function setMode(isFollow) {
    stopDemo();
    follow = isFollow;
    pos = 0;
    finishing = false;
    main.classList.toggle('follow', follow);
    modeBtn.querySelector('.ico').textContent = follow ? '🎹' : '🎵';
    modeBtn.querySelector('.txt').textContent = follow ? '自由弹' : '跟着弹';
    listenBtn.classList.toggle('hide', !follow);
    updateFollow();
    KG.say(follow ? PROMPT_FOLLOW : PROMPT_FREE);
    if (!KG.nav.current() || !document.body.contains(KG.nav.current())) KG.nav.refresh(keyEls[SONG[0]]);
  }

  function finishSong() {
    finishing = false;
    follow = false;
    updateFollow();
    KG.recordStars('twinkle', 3);
    KG.showWin({
      replayText: '再弹一次',
      onReplay: function () { setMode(true); KG.nav.refresh(keyEls[SONG[0]]); }
    });
    // 关闭弹层回到自由弹（“再弹一次”会重新进入跟着弹）
    main.classList.remove('follow');
    modeBtn.querySelector('.ico').textContent = '🎵';
    modeBtn.querySelector('.txt').textContent = '跟着弹';
    listenBtn.classList.add('hide');
  }

  /** 示范：从当前这一句的开头弹到句末，琴键依次亮起。 */
  function demo() {
    if (!follow || demoing) return;
    KG.stopSay();
    demoing = true;
    updateFollow();
    var start = Math.floor(Math.min(pos, SONG.length - 1) / PHRASE) * PHRASE;
    var end = Math.min(start + PHRASE, SONG.length);
    var t = 300;
    for (var n = start; n < end; n++) {
      (function (i, last) {
        demoTimers.push(setTimeout(function () {
          keyEls.forEach(function (b) { b.classList.remove('demo'); });
          keyEls[i].classList.add('demo');
          sound(i);
        }, t));
        if (last) {
          demoTimers.push(setTimeout(function () {
            keyEls[i].classList.remove('demo');
            demoing = false;
            demoTimers = [];
            updateFollow();
          }, t + 700));
        }
      })(SONG[n], n === end - 1);
      t += (n % PHRASE === PHRASE - 1) ? 900 : 480;
    }
  }

  function stopDemo() {
    demoTimers.forEach(clearTimeout);
    demoTimers = [];
    demoing = false;
    keyEls.forEach(function (b) { b.classList.remove('demo'); });
    updateFollow();
  }

  /* ---------- 启动 ---------- */
  KG.init({
    id: 'piano',
    nav: true,
    onPause: function () { stopDemo(); },
    onResume: function () {}
  });
  var header = KG.mountHeader('动物钢琴',
    '<button class="kg-btn ghost pbtn hide" data-nav data-act="listen"><span class="ico">👂</span><span class="txt">听一听</span></button>'
    + '<button class="kg-btn pbtn" data-nav data-act="mode"><span class="ico">🎵</span><span class="txt">跟着弹</span></button>');
  var modeBtn = header.querySelector('[data-act="mode"]');
  var listenBtn = header.querySelector('[data-act="listen"]');
  modeBtn.addEventListener('click', function () { KG.sfx('tap'); setMode(!follow); });
  listenBtn.addEventListener('click', function () { demo(); });

  KG.nav.refresh(keyEls[0]);
  KG.say(PROMPT_FREE);
})();
