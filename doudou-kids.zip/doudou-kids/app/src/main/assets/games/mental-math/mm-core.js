/* 口算挑战：出题核心（纯逻辑，不依赖页面；node 下也可直接 require 测试）。 */
(function (root) {
  'use strict';

  /* ---------- 有理数 ---------- */
  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { var t = a % b; a = b; b = t; } return a || 1; }
  function R(n, d) {
    if (d === undefined) d = 1;
    if (d < 0) { n = -n; d = -d; }
    var g = gcd(n, d);
    return { n: n / g, d: d / g };
  }
  function add(a, b) { return R(a.n * b.d + b.n * a.d, a.d * b.d); }
  function sub(a, b) { return R(a.n * b.d - b.n * a.d, a.d * b.d); }
  function mul(a, b) { return R(a.n * b.n, a.d * b.d); }
  function div(a, b) { return b.n === 0 ? null : R(a.n * b.d, a.d * b.n); }
  function eq(a, b) { return a.n * b.d === b.n * a.d; }
  function cmp(a, b) { return a.n * b.d - b.n * a.d; }

  function rand(min, max) { return min + Math.floor(Math.random() * (max - min + 1)); }
  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

  /** 有限小数的位数，不是有限小数（或超过 6 位）返回 -1。 */
  function decPlaces(r) {
    var n = Math.abs(r.n), d = r.d;
    for (var p = 0; p <= 6; p++) {
      if (n % d === 0) return p;
      n *= 10;
    }
    return -1;
  }
  function fmtDec(r) {
    var p = decPlaces(r);
    if (p <= 0) return p === 0 ? String(r.n / r.d) : fmtFrac(r);
    return (r.n / r.d).toFixed(p);
  }
  function fmtFrac(r) { return r.d === 1 ? String(r.n) : r.n + '/' + r.d; }
  function fmt(r, kind) { return kind === 'frac' ? fmtFrac(r) : (kind === 'dec' ? fmtDec(r) : String(r.n / r.d)); }

  /** 把孩子输入的 "12" "3.5" "3/4" 解析成有理数，不合法返回 null。 */
  function parseAnswer(s) {
    s = String(s || '');
    var m;
    if ((m = /^(\d+)\/(\d+)$/.exec(s))) {
      var d = parseInt(m[2], 10);
      return d === 0 ? null : R(parseInt(m[1], 10), d);
    }
    if ((m = /^(\d*)\.(\d+)$/.exec(s)) || (m = /^(\d+)\.$/.exec(s))) {
      var ip = m[1] || '0', fp = m[2] || '';
      var scale = Math.pow(10, fp.length);
      return R(parseInt(ip, 10) * scale + (fp ? parseInt(fp, 10) : 0), scale);
    }
    if (/^\d+$/.test(s)) return R(parseInt(s, 10), 1);
    return null;
  }

  /* ---------- 变量取值 ---------- */
  function genVar(spec, vals) {
    if (Array.isArray(spec)) return { v: R(rand(spec[0], spec[1]), 1), type: 'int' };
    if (spec.den) {
      // 同分母：沿用另一个字母约分前的分母
      var same = spec.sameDen && vals[spec.sameDen];
      var den = same && same.rawDen ? same.rawDen : pick(spec.den);
      var num = rand(1, den - 1);
      return { v: R(num, den), type: 'frac', rawNum: num, rawDen: den };
    }
    var scale = Math.pow(10, spec.places || 1);
    var k = rand(Math.round(spec.min * scale), Math.round(spec.max * scale));
    return { v: R(k, scale), type: 'dec' };
  }

  /* ---------- 算式模板求值：+ - × ÷ 和括号 ---------- */
  function evalTemplate(t, vals, kind) {
    var i = 0;
    function peek() { return t.charAt(i); }
    function factor() {
      var c = peek();
      if (c === '(') { i++; var v = expr(); if (v === null) return null; i++; return v; }
      i++;
      return vals[c] ? vals[c].v : null;
    }
    function term() {
      var v = factor();
      while (v !== null && (peek() === '×' || peek() === '÷')) {
        var op = t.charAt(i++), r = factor();
        if (r === null) return null;
        if (op === '×') v = mul(v, r);
        else {
          v = div(v, r);
          if (v === null) return null;
          if (kind === 'int' && v.d !== 1) return null;
          if (kind === 'dec' && decPlaces(v) < 0) return null;
        }
      }
      return v;
    }
    function expr() {
      var v = term();
      while (v !== null && (peek() === '+' || peek() === '-')) {
        var op = t.charAt(i++), r = term();
        if (r === null) return null;
        v = op === '+' ? add(v, r) : sub(v, r);
        if (v.n < 0) return null;
      }
      return v;
    }
    return expr();
  }

  function genExpr(type) {
    var letters = Object.keys(type.vars);
    var vals = {}, kind = 'int';
    letters.forEach(function (k) {
      var g = genVar(type.vars[k], vals);
      vals[k] = g;
      if (g.type === 'frac') kind = 'frac';
      else if (g.type === 'dec' && kind !== 'frac') kind = 'dec';
    });
    var ans = evalTemplate(type.t, vals, kind);
    if (ans === null) return null;
    if (kind === 'int' && ans.d !== 1) return null;
    var min = type.min === undefined ? 0 : type.min, max = type.max;
    if (cmp(ans, R(Math.round(min * 1000), 1000)) < 0) return null;
    if (max !== undefined && cmp(ans, R(Math.round(max * 1000), 1000)) > 0) return null;
    // 小数题：不出整数加整数这种退化题
    if (kind === 'dec' && letters.every(function (k) { return vals[k].type !== 'dec' || vals[k].v.d === 1; })) return null;
    var tokens = [];
    for (var i = 0; i < type.t.length; i++) {
      var c = type.t.charAt(i);
      if (vals[c]) {
        var g = vals[c];
        if (g.type === 'frac') tokens.push({ t: 'frac', n: g.rawNum, d: g.rawDen });
        else tokens.push({ t: 'num', s: g.type === 'dec' ? fmtDec(g.v) : String(g.v.n) });
      } else if (c === '(' || c === ')') tokens.push({ t: 'paren', s: c });
      else tokens.push({ t: 'op', s: c === '-' ? '−' : c });
    }
    tokens.push({ t: 'op', s: '=' }, { t: 'ans' });
    return { tokens: tokens, answer: ans, kind: kind };
  }

  function genPercentOf(type) {
    var pct = pick(type.pct);
    var b = type.base || [20, 400];
    var base = rand(b[0], b[1]);
    if ((base * pct) % 100 !== 0) return null;
    return {
      tokens: [{ t: 'num', s: String(base) }, { t: 'text', s: '的' }, { t: 'num', s: pct + '%' }, { t: 'text', s: '是' }, { t: 'ans' }],
      answer: R(base * pct / 100, 1), kind: 'int'
    };
  }

  function genToPercent(type) {
    var tokens, pctVal;
    if (type.from === 'fraction') {
      var den = pick(type.den || [2, 4, 5, 10, 20, 25]);
      var num = rand(1, den - 1);
      if ((num * 100) % den !== 0) return null;
      pctVal = num * 100 / den;
      tokens = [{ t: 'frac', n: num, d: den }];
    } else {
      var k = rand(1, 99);
      pctVal = k;
      tokens = [{ t: 'num', s: fmtDec(R(k, 100)) }];
    }
    tokens.push({ t: 'op', s: '=' }, { t: 'ans' }, { t: 'text', s: '%' });
    return { tokens: tokens, answer: R(pctVal, 1), kind: 'int' };
  }

  var GENS = { expr: genExpr, percentOf: genPercentOf, toPercent: genToPercent };

  function pickType(types) {
    var total = 0;
    types.forEach(function (t) { total += t.weight || 1; });
    var x = Math.random() * total;
    for (var i = 0; i < types.length; i++) {
      x -= types[i].weight || 1;
      if (x < 0) return types[i];
    }
    return types[types.length - 1];
  }

  function questionText(q) {
    return q.tokens.map(function (tk) {
      if (tk.t === 'frac') return tk.n + '/' + tk.d;
      if (tk.t === 'ans') return '?';
      return tk.s;
    }).join(' ');
  }

  /** 生成一题；avoid 为已出题目文本的集合（对象），避免一轮内重复。 */
  function generate(grade, avoid) {
    avoid = avoid || {};
    var last = null;
    for (var attempt = 0; attempt < 2000; attempt++) {
      var type = pickType(grade.types);
      var gen = GENS[type.kind];
      if (!gen) continue;
      var q = gen(type);
      if (!q) continue;
      q.text = questionText(q);
      q.answerText = fmt(q.answer, q.kind);
      q.keys = { dot: q.kind === 'dec', slash: q.kind === 'frac' };
      last = q;
      if (!avoid[q.text]) return q;
    }
    if (last) return last;
    // 配置有误时的兜底
    var a = rand(1, 9), b = rand(1, 9);
    return {
      tokens: [{ t: 'num', s: String(a) }, { t: 'op', s: '+' }, { t: 'num', s: String(b) }, { t: 'op', s: '=' }, { t: 'ans' }],
      answer: R(a + b, 1), kind: 'int', text: a + ' + ' + b + ' = ?', answerText: String(a + b), keys: { dot: false, slash: false }
    };
  }

  function check(q, input) {
    var v = parseAnswer(input);
    return v !== null && eq(v, q.answer);
  }

  var api = { generate: generate, check: check, parseAnswer: parseAnswer, fmt: fmt, R: R };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.MMCore = api;
})(this);
