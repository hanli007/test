/* 口算挑战：选年级，每轮 10 题，屏幕数字键盘作答（电视遥控器也能用），不计时。 */
(function () {
  'use strict';
  var KG = window.KidsGame, C = window.MMCore;

  var profile = KG.init({ id: 'mental-math', nav: true, onBack: onBack, onPause: onPause, onResume: onResume });
  KG.mountHeader('口算挑战', '<span class="kg-chip" id="prog" hidden></span>');

  var $prog = document.getElementById('prog');
  var $picker = document.getElementById('picker'), $grades = document.getElementById('grades');
  var $play = document.getElementById('play'), $dots = document.getElementById('dots');
  var $q = document.getElementById('q'), $msg = document.getElementById('msg');
  var $pad = document.getElementById('pad'), $ok = document.getElementById('okKey');
  var $zero = document.getElementById('zeroKey'), $dot = document.getElementById('dotKey'), $slash = document.getElementById('slashKey');

  var cfg = null, N = 10;
  var state = 'pick';        // pick | input | wait | review
  var grade = null, qi = 0, results = [], seen = {}, q = null, input = '';
  var advTimer = null, advPaused = false;

  function loadJSON(url, ok, fail) {
    function xhr() {
      try {
        var x = new XMLHttpRequest();
        x.open('GET', url, true);
        x.onload = function () {
          try { ok(JSON.parse(x.responseText)); } catch (e) { fail(e); }
        };
        x.onerror = function () { fail(new Error('xhr ' + url)); };
        x.send();
      } catch (e) { fail(e); }
    }
    if (window.fetch) {
      fetch(url).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }).then(ok, xhr);
    } else xhr();
  }

  /* ---------- 年级选择 ---------- */
  function defaultGrade() {
    var age = +profile.age || 7;
    return Math.max(1, Math.min(6, age - 5));
  }
  function showPicker(focusId) {
    clearAdv();
    state = 'pick';
    $prog.hidden = true;
    $play.hidden = true;
    $picker.hidden = false;
    var p = KG.load() || {};
    var stars = p.stars || {};
    var def = focusId || (grade ? grade.id : defaultGrade());
    $grades.innerHTML = cfg.grades.map(function (g, i) {
      var s = stars['g' + g.id] || 0, st = '';
      for (var k = 1; k <= 3; k++) st += '<i' + (k <= s ? ' class="on"' : '') + '>★</i>';
      return '<button class="mm-grade" data-nav data-g="' + i + '"' + (g.id === def ? ' data-autofocus' : '') + '>'
        + '<b>' + g.name + '</b><small>' + g.desc + '</small><span class="mm-st">' + st + '</span></button>';
    }).join('');
    KG.nav.refresh($grades.querySelector('[data-autofocus]'));
  }
  $grades.addEventListener('click', function (e) {
    var b = e.target.closest('[data-g]'); if (!b) return;
    KG.sfx('tap');
    startRound(cfg.grades[+b.getAttribute('data-g')]);
  });

  /* ---------- 一轮 ---------- */
  function startRound(g) {
    grade = g; qi = 0; results = []; seen = {};
    state = 'input';
    $picker.hidden = true;
    $grades.innerHTML = '';
    $play.hidden = false;
    $prog.hidden = false;
    nextQuestion();
    KG.nav.refresh($pad.querySelector('[data-autofocus]'));
    KG.say({ key: 'prompt_mentalmath_1', zh: '算一算，用数字键输入答案' });
  }

  function nextQuestion() {
    if (qi >= N) { finish(); return; }
    q = C.generate(grade, seen);
    seen[q.text] = 1;
    input = '';
    state = 'input';
    $ok.textContent = '确定';
    $msg.textContent = '';
    $prog.textContent = '第 ' + (qi + 1) + ' / ' + N + ' 题';
    renderQuestion();
    renderDots();
    $dot.hidden = !q.keys.dot;
    $slash.hidden = !q.keys.slash;
    $zero.style.gridColumn = 'span ' + (3 - (q.keys.dot ? 1 : 0) - (q.keys.slash ? 1 : 0));
    var cur = KG.nav.current();
    if (KG.nav.enabled && (!cur || cur.hidden)) KG.nav.focus($pad.querySelector('[data-autofocus]'));
  }

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
  function renderQuestion() {
    $q.innerHTML = q.tokens.map(function (tk) {
      if (tk.t === 'frac') return '<span class="mm-fr"><span>' + tk.n + '</span><span>' + tk.d + '</span></span>';
      if (tk.t === 'ans') return '<span class="mm-ans" id="ans">&nbsp;</span>';
      if (tk.t === 'text') return '<span class="mm-txt">' + esc(tk.s) + '</span>';
      return '<span>' + esc(tk.s) + '</span>';
    }).join('');
  }
  function ansEl() { return document.getElementById('ans'); }
  function renderInput() {
    var a = ansEl(); if (!a) return;
    a.className = 'mm-ans';
    a.innerHTML = input ? esc(input) : '&nbsp;';
  }
  function renderDots() {
    var h = '';
    for (var i = 0; i < N; i++) {
      var c = i < results.length ? (results[i] ? 'ok' : 'no') : (i === qi ? 'cur' : '');
      h += '<i class="' + c + '"></i>';
    }
    $dots.innerHTML = h;
  }

  function speakable(r, kind) {
    if (kind === 'frac' && r.d !== 1) return r.d + '分之' + r.n;
    return C.fmt(r, kind);
  }

  $pad.addEventListener('click', function (e) {
    var b = e.target.closest('[data-k]'); if (!b) return;
    press(b.getAttribute('data-k'));
  });

  function press(k) {
    if (KG.paused || state === 'pick' || state === 'wait') return;
    if (state === 'review') {
      if (k === 'ok') { KG.sfx('tap'); qi++; nextQuestion(); }
      return;
    }
    if (k === 'ok') { submit(); return; }
    KG.sfx('tap');
    if (k === 'del') input = input.slice(0, -1);
    else if (k === 'clear') input = '';
    else if (input.length < 8) {
      if (k === '.' && (input.indexOf('.') >= 0 || input.indexOf('/') >= 0)) return;
      if (k === '/' && (input === '' || input.indexOf('/') >= 0 || input.indexOf('.') >= 0)) return;
      if (/^\d$/.test(k) && input === '0') input = '';
      input += k;
    }
    $msg.textContent = '';
    renderInput();
  }

  function submit() {
    if (!input || C.parseAnswer(input) === null) {
      $msg.textContent = input ? '答案写得不完整哦' : '先用数字键输入答案哦';
      KG.shake(ansEl());
      return;
    }
    var a = ansEl();
    if (C.check(q, input)) {
      results.push(true);
      state = 'wait';
      a.className = 'mm-ans right';
      KG.sfx('ok');
      KG.say(KG.praiseItem());
      renderDots();
      advTimer = setTimeout(advance, 1000);
    } else {
      results.push(false);
      state = 'review';
      a.className = 'mm-ans fix';
      a.textContent = q.answerText;
      $msg.textContent = '你写的是 ' + input + '，正确答案是 ' + q.answerText;
      $ok.textContent = '下一题';
      KG.sfx('drop');
      KG.say({ zh: '没关系，正确答案是' + speakable(q.answer, q.kind) });
      renderDots();
      if (KG.nav.enabled) KG.nav.focus($ok);
    }
  }

  function advance() {
    advTimer = null;
    qi++;
    nextQuestion();
  }
  function clearAdv() {
    if (advTimer) clearTimeout(advTimer);
    advTimer = null; advPaused = false;
  }

  function finish() {
    state = 'pick';
    var right = results.filter(function (x) { return x; }).length;
    var stars = right >= 9 ? 3 : (right >= 7 ? 2 : 1);
    var p = KG.recordStars('g' + grade.id, stars);
    p.best = p.best || {};
    if (!p.best['g' + grade.id] || p.best['g' + grade.id] < right) p.best['g' + grade.id] = right;
    KG.save(p);
    var g = grade;
    KG.showWin({
      title: right === N ? '全部答对！' : '完成！',
      text: grade.name + '：答对 ' + right + ' / ' + N + ' 题',
      stars: stars,
      replayText: '再来一轮',
      onReplay: function () { startRound(g); },
      onNext: function () { showPicker(g.id); },
      nextText: '换个年级'
    });
  }

  function onBack() {
    if (state !== 'pick' && cfg) { showPicker(); return true; }
    return false;
  }
  function onPause() {
    if (advTimer) { clearTimeout(advTimer); advTimer = null; advPaused = true; }
  }
  function onResume() {
    if (advPaused) { advPaused = false; advTimer = setTimeout(advance, 400); }
  }

  // 平板外接键盘 / 桌面调试：数字键直接输入
  document.addEventListener('keydown', function (e) {
    if ($play.hidden || document.querySelector('.kg-overlay')) return;
    if (/^[0-9./]$/.test(e.key)) press(e.key);
    else if (e.key === 'Backspace') press('del');
    else if (e.key === 'Enter' && !KG.nav.enabled) press('ok');
  });

  loadJSON('grades.json', function (data) {
    cfg = data;
    N = data.questionsPerRound || 10;
    showPicker();
  }, function (err) {
    KG.log('grades.json 加载失败：' + err);
    $grades.innerHTML = '<p class="kg-msg">题库加载失败，请返回重试</p>';
  });
})();
