/*
 * 打字练习：英文指法，从基准键到句子。
 * 物理键盘（蓝牙 / USB）和屏幕软键盘都通过隐藏输入框的 input 事件读取字符。
 * 速度按国际惯例计算：每 5 个正确字符算 1 个词（WPM）。
 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var LESSONS = [
    { id: 'home', title: '基准键', desc: 'A S D F J K L ;，手指放好的位置', keys: 'asdfjkl;' },
    { id: 'home2', title: '基准键加 G H', desc: '食指向中间伸一下', keys: 'asdfghjkl;' },
    { id: 'top', title: '上排键', desc: 'Q W E R T Y U I O P', keys: 'qwertyuiop' + 'asdfjkl' },
    { id: 'bottom', title: '下排键', desc: 'Z X C V B N M , .', keys: 'zxcvbnm,.' + 'asdfjkl' },
    { id: 'all', title: '全部字母', desc: '26 个字母混合练习', keys: 'abcdefghijklmnopqrstuvwxyz' },
    { id: 'words', title: '常用单词', desc: '简单的英文单词', words: true },
    { id: 'sentences', title: '英文句子', desc: '完整的短句，含大写和标点', sentences: true }
  ];
  var WORDS = ['cat', 'dog', 'sun', 'moon', 'star', 'fish', 'bird', 'tree', 'book', 'milk', 'apple', 'happy',
    'water', 'green', 'house', 'school', 'friend', 'family', 'music', 'river', 'paper', 'light', 'smile', 'cloud',
    'panda', 'tiger', 'orange', 'yellow', 'purple', 'window', 'garden', 'flower', 'pencil', 'rabbit', 'monkey'];
  var SENTENCES = ['I like to read books.', 'The sun is very bright today.', 'My cat sleeps on the bed.',
    'We go to school every day.', 'She has a red kite.', 'Birds can fly in the sky.', 'Please close the door.',
    'Thank you for your help.', 'The panda eats bamboo.', 'Let us play in the park.', 'I can swim and run.',
    'It is cold in winter.', 'He drinks a glass of milk.', 'The river flows to the sea.'];

  // 每个键由哪根手指负责（颜色用于键盘示意图底边）
  var FINGER = {};
  var FINGER_COLORS = ['#F2678A', '#FF9F43', '#3FBF84', '#4AA3EE', '#4AA3EE', '#3FBF84', '#FF9F43', '#F2678A'];
  [['qaz', 0], ['wsx', 1], ['edc', 2], ['rfvtgb', 3], ['yhnujm', 4], ['ik,', 5], ['ol.', 6], ['p;/', 7]].forEach(function (g) {
    g[0].split('').forEach(function (c) { FINGER[c] = g[1]; });
  });
  var ROWS = ['qwertyuiop', 'asdfghjkl;', 'zxcvbnm,./'];

  var pickEl = document.getElementById('pick');
  var playEl = document.getElementById('play');
  var textEl = document.getElementById('text');
  var kbEl = document.getElementById('kb');
  var statsEl = document.getElementById('stats');
  var msgEl = document.getElementById('msg');
  var sink = document.getElementById('sink');

  var lesson = null, target = '', pos = 0, errAt = -1, correct = 0, errors = 0;
  var startedAt = 0, pausedMs = 0, pauseStart = 0, tick = null, lastInputAt = 0, noKbTimer = null;

  KG.init({
    id: 'typing', nav: true,
    onBack: function () {
      if (!playEl.hidden) { showPick(); return true; }
      return false;
    },
    onPause: function () { pauseStart = Date.now(); },
    onResume: function () { if (pauseStart) { pausedMs += Date.now() - pauseStart; pauseStart = 0; } focusSink(); }
  });
  var header = KG.mountHeader('打字练习');
  // 练习中按顶栏返回键回到课程列表，而不是退出游戏
  header.querySelector('.kg-back').addEventListener('click', function (e) {
    if (!playEl.hidden) { e.stopImmediatePropagation(); showPick(); }
  }, true);

  function esc(c) { return c === '<' ? '&lt;' : c === '>' ? '&gt;' : c === '&' ? '&amp;' : c; }

  /* ---------- 课程列表 ---------- */
  function showPick() {
    stopTimers();
    playEl.hidden = true;
    pickEl.hidden = false;
    var p = KG.load() || {};
    var stars = p.stars || {}, best = p.best || {};
    var html = '<h2>选一课开始</h2><p>把左手食指放在 F、右手食指放在 J（键上有小凸起），其余手指依次放好。</p><div class="ty-lessons">';
    LESSONS.forEach(function (l, i) {
      var st = stars[l.id] ? new Array(stars[l.id] + 1).join('★') : '';
      var b = best[l.id] ? ' · 最快 ' + best[l.id] + ' WPM' : '';
      html += '<button class="ty-lesson" data-nav' + (i === 0 ? ' data-autofocus' : '') + ' data-i="' + i + '"><span class="n">' + (i + 1) + '</span>'
        + '<span class="t"><b>' + l.title + '</b><span>' + l.desc + b + '</span></span><span class="s">' + st + '</span></button>';
    });
    pickEl.innerHTML = html + '</div>';
    KG.nav.refresh();
  }
  pickEl.addEventListener('click', function (e) {
    var b = e.target.closest('[data-i]');
    if (b) start(LESSONS[+b.getAttribute('data-i')]);
  });

  /* ---------- 生成练习文本 ---------- */
  function makeText(l) {
    if (l.sentences) return KG.shuffle(SENTENCES).slice(0, 2).join(' ');
    if (l.words) return KG.shuffle(WORDS).slice(0, 8).join(' ');
    var keys = l.keys.split(''), groups = [];
    while (groups.join(' ').length < 40) {
      var len = KG.rand(3, 5), g = '';
      for (var i = 0; i < len; i++) g += KG.pick(keys);
      groups.push(g);
    }
    return groups.join(' ');
  }

  /* ---------- 练习 ---------- */
  function start(l) {
    lesson = l;
    target = makeText(l);
    pos = 0; errAt = -1; correct = 0; errors = 0;
    startedAt = 0; pausedMs = 0; pauseStart = 0;
    pickEl.hidden = true;
    playEl.hidden = false;
    msgEl.innerHTML = '';
    render();
    focusSink();
    lastInputAt = 0;
    clearTimeout(noKbTimer);
    noKbTimer = setTimeout(function () {
      if (!lastInputAt) {
        msgEl.innerHTML = '没有检测到键盘输入。可以连接蓝牙或 USB 键盘，也可以用屏幕键盘练习。<br>'
          + '<button class="kg-btn ghost" data-nav id="bSoft">打开屏幕键盘</button>';
        var b = document.getElementById('bSoft');
        b.addEventListener('click', function () { focusSink(); });
        KG.nav.refresh(b);
      }
    }, 8000);
    tick = setInterval(renderStats, 1000);
  }

  function focusSink() {
    if (playEl.hidden) return;
    try { sink.focus(); } catch (e) { /* ignore */ }
  }
  document.addEventListener('pointerdown', function () { setTimeout(focusSink, 0); });

  function stopTimers() {
    clearInterval(tick); tick = null;
    clearTimeout(noKbTimer); noKbTimer = null;
  }

  function elapsedMin() {
    if (!startedAt) return 0;
    var now = pauseStart || Date.now();
    return Math.max(0, now - startedAt - pausedMs) / 60000;
  }
  function wpm() {
    var m = elapsedMin();
    return m > 0.05 ? Math.round(correct / 5 / m) : 0;
  }
  function accuracy() {
    var total = correct + errors;
    return total ? Math.round(correct / total * 100) : 100;
  }

  function renderStats() {
    if (playEl.hidden) return;
    statsEl.innerHTML = '<div class="ty-stat"><b>' + wpm() + '</b>WPM</div>'
      + '<div class="ty-stat"><b>' + accuracy() + '%</b>正确率</div>'
      + '<div class="ty-stat"><b>' + pos + '/' + target.length + '</b>进度</div>';
  }

  function render() {
    var html = '';
    for (var i = 0; i < target.length; i++) {
      var c = target[i], cls = i < pos ? 'done' : (i === pos ? (errAt === pos ? 'err' : 'cur') : 'todo');
      html += '<span class="' + cls + '">' + (c === ' ' && i === pos ? '&nbsp;' : esc(c)) + '</span>';
    }
    textEl.innerHTML = html;
    renderKeyboard(target[pos]);
    renderStats();
  }

  function renderKeyboard(next) {
    var lower = next ? next.toLowerCase() : '';
    var html = '';
    ROWS.forEach(function (row) {
      html += '<div class="ty-row">';
      row.split('').forEach(function (k) {
        var f = FINGER[k];
        var home = (k === 'f' || k === 'j') ? ' home' : '';
        html += '<span class="ty-key' + home + (k === lower ? ' next' : '') + '" style="--fc:' + (f === undefined ? 'var(--soft)' : FINGER_COLORS[f]) + '">' + esc(k) + '</span>';
      });
      html += '</div>';
    });
    html += '<div class="ty-row"><span class="ty-key space' + (next === ' ' ? ' next' : '') + '">空格</span></div>';
    kbEl.innerHTML = html;
  }

  function onChar(c) {
    if (playEl.hidden || KG.paused || pos >= target.length) return;
    lastInputAt = Date.now();
    if (msgEl.querySelector('#bSoft')) msgEl.innerHTML = '';
    if (!startedAt) startedAt = Date.now();
    if (c === target[pos]) {
      correct++;
      pos++;
      errAt = -1;
      KG.sfx('tap');
      if (pos >= target.length) { render(); finish(); return; }
    } else {
      errors++;
      errAt = pos;
      KG.sfx('wrong');
    }
    render();
  }

  // 软键盘和大多数物理键盘都会触发 input；用完立即清空
  sink.addEventListener('input', function () {
    var v = sink.value;
    sink.value = '';
    for (var i = 0; i < v.length; i++) onChar(v[i]);
  });
  // 部分 WebView 对物理键盘的空格只触发 keydown
  sink.addEventListener('keydown', function (e) {
    lastInputAt = Date.now();
    if (e.key === ' ' && !sink.value) { e.preventDefault(); onChar(' '); }
  });

  function finish() {
    stopTimers();
    var acc = accuracy(), speed = wpm();
    var stars = acc >= 95 ? 3 : acc >= 85 ? 2 : 1;
    var p = KG.recordStars(lesson.id, stars);
    p.best = p.best || {};
    if (!p.best[lesson.id] || p.best[lesson.id] < speed) p.best[lesson.id] = speed;
    KG.save(p);
    try { sink.blur(); } catch (e) { /* ignore */ }
    var idx = LESSONS.indexOf(lesson);
    KG.showWin({
      title: '完成！',
      text: '速度 ' + speed + ' WPM · 正确率 ' + acc + '%',
      stars: stars,
      replayText: '再练一次',
      onReplay: function () { start(lesson); },
      onNext: idx + 1 < LESSONS.length ? function () { start(LESSONS[idx + 1]); } : null,
      nextText: '下一课'
    });
  }

  showPick();
})();
