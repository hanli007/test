/*
 * 豆豆乐园 H5 游戏共享库（ES2015，不使用 async/await、?.、??，兼容老电视 WebView）
 *
 * 原生桥（Android 注入 window.KidsBridge，均为字符串参数）：
 *   getProfile() -> JSON 字符串 {name, ageTier:"qm|tq|sn", age, input:"touch|dpad", englishVoice, sound}
 *   saveProgress(gameId, json) / loadProgress(gameId) -> json 或 ""
 *   speak(zh, en)   系统 TTS 兜底，先读中文再读英文，任一可为空
 *   stopSpeak()
 *   exit()
 *   log(msg)
 * 原生 -> 游戏：
 *   KidsGame._dispatchInput("up|down|left|right|ok|back")
 *   KidsGame._pause() / KidsGame._resume()
 *
 * 在桌面浏览器中直接打开也能运行：没有 KidsBridge 时用 localStorage 和 Web Speech API 代替，
 * 并可用 ?tier=qm|tq|sn&input=touch|dpad 模拟档案。
 */
(function () {
  'use strict';

  var B = window.KidsBridge || null;
  var DEFAULT_PROFILE = { name: '小明', ageTier: 'qm', age: 4, input: 'touch', englishVoice: true, sound: true };
  var params = new URLSearchParams(location.search);

  function readProfile() {
    var p = Object.assign({}, DEFAULT_PROFILE);
    try {
      if (B && B.getProfile) Object.assign(p, JSON.parse(B.getProfile()));
    } catch (e) { /* 使用默认档案 */ }
    if (params.get('tier')) p.ageTier = params.get('tier');
    if (params.get('input')) p.input = params.get('input');
    return p;
  }

  var KG = {
    profile: readProfile(),
    params: params,
    id: '',
    paused: false,
    _handlers: {}
  };

  /* ---------- 小工具 ---------- */
  KG.shuffle = function (arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  };
  KG.pick = function (arr) { return arr[Math.floor(Math.random() * arr.length)]; };
  KG.rand = function (min, max) { return min + Math.floor(Math.random() * (max - min + 1)); };
  KG.el = function (html) {
    var d = document.createElement('div');
    d.innerHTML = html.trim();
    return d.firstChild;
  };
  KG.log = function (msg) {
    if (B && B.log) B.log(String(msg)); else console.log('[KidsGame]', msg);
  };

  /* ---------- 音效（WebAudio 合成，不需要音频文件） ---------- */
  var audioCtx = null;
  function actx() {
    if (!audioCtx) {
      var C = window.AudioContext || window.webkitAudioContext;
      if (!C) return null;
      audioCtx = new C();
    }
    if (audioCtx.state === 'suspended') audioCtx.resume();
    return audioCtx;
  }
  function tone(freq, start, dur, type, vol) {
    var c = actx(); if (!c) return;
    var o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, c.currentTime + start);
    g.gain.setValueAtTime(0.0001, c.currentTime + start);
    g.gain.exponentialRampToValueAtTime(vol || 0.25, c.currentTime + start + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + start + dur);
    o.connect(g); g.connect(c.destination);
    o.start(c.currentTime + start);
    o.stop(c.currentTime + start + dur + 0.05);
  }
  var SFX = {
    tap: function () { tone(660, 0, 0.08, 'triangle', 0.18); },
    pick: function () { tone(520, 0, 0.08, 'sine'); tone(780, 0.06, 0.1, 'sine'); },
    drop: function () { tone(400, 0, 0.12, 'triangle'); },
    ok: function () { tone(660, 0, 0.1); tone(880, 0.1, 0.1); tone(1320, 0.2, 0.18); },
    wrong: function () { tone(300, 0, 0.15, 'sawtooth', 0.12); tone(240, 0.12, 0.2, 'sawtooth', 0.1); },
    win: function () { [523, 659, 784, 1047, 784, 1047].forEach(function (f, i) { tone(f, i * 0.12, 0.18, 'triangle', 0.22); }); },
    pop: function () { tone(900, 0, 0.05, 'square', 0.12); tone(1400, 0.03, 0.06, 'sine', 0.15); }
  };
  KG.sfx = function (name) {
    if (!KG.profile.sound) return;
    try { (SFX[name] || SFX.tap)(); } catch (e) { /* 忽略音频错误 */ }
  };
  /** 播放指定频率的音符，用于动物钢琴等。 */
  KG.note = function (freq, dur) { if (KG.profile.sound) tone(freq, 0, dur || 0.4, 'triangle', 0.25); };

  /* ---------- 语音：预录音频优先，TTS 兜底 ----------
   * 语音条目：{ key: "num_1", zh: "一", en: "one" }
   * 预录音频路径：games/_voice/zh/<key>.mp3、games/_voice/en/<key>.mp3
   * key 命名约定见 games/_voice/README.md。
   */
  var VOICE_ROOT = '../_voice/';
  var sayToken = 0;
  var currentAudio = null;

  function playFile(url) {
    return new Promise(function (resolve, reject) {
      var a = new Audio(url);
      currentAudio = a;
      var done = false;
      a.onended = function () { if (!done) { done = true; resolve(); } };
      a.onerror = function () { if (!done) { done = true; reject(new Error('missing ' + url)); } };
      var p = a.play();
      if (p && p.catch) p.catch(function (e) { if (!done) { done = true; reject(e); } });
    });
  }
  function ttsSpeak(zh, en) {
    if (B && B.speak) { B.speak(zh || '', en || ''); }
    else if (window.speechSynthesis) {
      if (zh) { var u1 = new SpeechSynthesisUtterance(zh); u1.lang = 'zh-CN'; speechSynthesis.speak(u1); }
      if (en) { var u2 = new SpeechSynthesisUtterance(en); u2.lang = 'en-US'; speechSynthesis.speak(u2); }
    }
    var ms = ((zh || '').length * 280) + ((en || '').length * 90) + 400;
    return new Promise(function (r) { setTimeout(r, ms); });
  }
  function sayPart(token, key, lang, text) {
    if (token !== sayToken || !text) return Promise.resolve();
    if (!key) return ttsSpeak(lang === 'zh' ? text : '', lang === 'en' ? text : '');
    return playFile(VOICE_ROOT + lang + '/' + key + '.mp3').catch(function () {
      if (token !== sayToken) return;
      return ttsSpeak(lang === 'zh' ? text : '', lang === 'en' ? text : '');
    });
  }
  /**
   * 读一条语音。item: {key?, zh, en?}；英文只在家长开启英文读音时播放。
   * 新的 say 会打断上一条。返回 Promise，读完时 resolve。
   */
  KG.say = function (item) {
    KG.stopSay();
    if (!KG.profile.sound || !item) return Promise.resolve();
    var token = ++sayToken;
    var en = KG.profile.englishVoice ? item.en : '';
    return sayPart(token, item.key, 'zh', item.zh).then(function () {
      return sayPart(token, item.key, 'en', en);
    });
  };
  /** 依次读多条，例如表扬 + 物品读音。 */
  KG.sayAll = function (items) {
    KG.stopSay();
    if (!KG.profile.sound) return Promise.resolve();
    var token = ++sayToken;
    return items.reduce(function (p, item) {
      return p.then(function () {
        if (token !== sayToken || !item) return;
        var en = KG.profile.englishVoice ? item.en : '';
        return sayPart(token, item.key, 'zh', item.zh).then(function () { return sayPart(token, item.key, 'en', en); });
      });
    }, Promise.resolve());
  };
  KG.stopSay = function () {
    sayToken++;
    if (currentAudio) { try { currentAudio.pause(); } catch (e) { /* ignore */ } currentAudio = null; }
    if (B && B.stopSpeak) B.stopSpeak();
    else if (window.speechSynthesis) speechSynthesis.cancel();
  };

  var PRAISES = [
    { key: 'praise_1', zh: '真棒！' }, { key: 'praise_2', zh: '对啦！' },
    { key: 'praise_3', zh: '太厉害了！' }, { key: 'praise_4', zh: '好样的！' }
  ];
  var HINTS = [{ key: 'hint_1', zh: '再试试看哦' }, { key: 'hint_2', zh: '没关系，再想一想' }];
  KG.praiseItem = function () { return KG.pick(PRAISES); };
  KG.hintItem = function () { return KG.pick(HINTS); };

  /* ---------- 进度 ---------- */
  KG.save = function (data) {
    var json = JSON.stringify(data);
    if (B && B.saveProgress) B.saveProgress(KG.id, json);
    else try { localStorage.setItem('kg_' + KG.id, json); } catch (e) { /* ignore */ }
  };
  KG.load = function () {
    var json = '';
    try {
      json = (B && B.loadProgress) ? B.loadProgress(KG.id) : (localStorage.getItem('kg_' + KG.id) || '');
      return json ? JSON.parse(json) : null;
    } catch (e) { return null; }
  };
  /** 记录一次通关（星级 1-3），保留每关最高星级。 */
  KG.recordStars = function (levelKey, stars) {
    var p = KG.load() || {};
    p.stars = p.stars || {};
    if (!p.stars[levelKey] || p.stars[levelKey] < stars) p.stars[levelKey] = stars;
    p.lastPlayed = Date.now();
    KG.save(p);
    return p;
  };

  /* ---------- 退出 ---------- */
  KG.exit = function () {
    KG.stopSay();
    if (B && B.exit) B.exit(); else history.back();
  };

  /* ---------- 遥控器输入与焦点导航 ---------- */
  KG.isDpad = function () { return KG.profile.input === 'dpad'; };
  var nav = {
    enabled: false,
    current: function () { return document.querySelector('.kg-focus'); },
    items: function () {
      var scope = document.querySelector('.kg-overlay') || document;
      return Array.prototype.filter.call(scope.querySelectorAll('[data-nav]'), function (x) {
        return x.offsetParent !== null && !x.disabled;
      });
    },
    focus: function (el) {
      Array.prototype.forEach.call(document.querySelectorAll('.kg-focus'), function (x) { x.classList.remove('kg-focus'); });
      if (el) {
        el.classList.add('kg-focus');
        if (el.scrollIntoView) el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      }
    },
    /** 重新渲染后调用：焦点不在可见元素上时，聚焦 preferred 或第一个元素。 */
    refresh: function (preferred) {
      if (!nav.enabled) return;
      var items = nav.items(), cur = nav.current();
      if (preferred && items.indexOf(preferred) >= 0) { nav.focus(preferred); return; }
      if (!cur || items.indexOf(cur) < 0) nav.focus(document.querySelector('[data-autofocus]') || items[0]);
    },
    move: function (dir) {
      var items = nav.items(), cur = nav.current();
      if (!cur || items.indexOf(cur) < 0) { nav.focus(items[0]); return; }
      var r0 = cur.getBoundingClientRect(), cx = r0.left + r0.width / 2, cy = r0.top + r0.height / 2;
      var best = null, bd = Infinity;
      items.forEach(function (it) {
        if (it === cur) return;
        var r = it.getBoundingClientRect();
        var dx = r.left + r.width / 2 - cx, dy = r.top + r.height / 2 - cy;
        if (dir === 'right' && dx <= 4) return;
        if (dir === 'left' && dx >= -4) return;
        if (dir === 'down' && dy <= 4) return;
        if (dir === 'up' && dy >= -4) return;
        var h = dir === 'left' || dir === 'right';
        var d = (h ? Math.abs(dx) : Math.abs(dy)) + (h ? Math.abs(dy) : Math.abs(dx)) * 2;
        if (d < bd) { bd = d; best = it; }
      });
      if (best) { nav.focus(best); KG.sfx('tap'); }
    }
  };
  KG.nav = nav;

  KG._dispatchInput = function (key) {
    if (KG.paused) return;
    var h = KG._handlers.onInput;
    if (h && h(key) === true) return; // 游戏自己处理了
    if (key === 'back') {
      var ov = document.querySelector('.kg-overlay');
      if (ov && ov._onBack) { ov._onBack(); return; }
      if (KG._handlers.onBack && KG._handlers.onBack() === true) return;
      KG.exit();
      return;
    }
    if (!nav.enabled) return;
    if (key === 'ok') { var c = nav.current(); if (c) c.click(); return; }
    nav.move(key);
  };
  KG._pause = function () {
    KG.paused = true; KG.stopSay();
    if (KG._handlers.onPause) KG._handlers.onPause();
  };
  KG._resume = function () {
    KG.paused = false;
    if (KG._handlers.onResume) KG._handlers.onResume();
  };
  // 桌面浏览器调试：键盘模拟遥控器（在 App 内由原生转发，WebView 不会收到这些按键）
  if (!B) {
    document.addEventListener('keydown', function (e) {
      var map = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', Enter: 'ok', Escape: 'back' };
      if (map[e.key]) { e.preventDefault(); KG._dispatchInput(map[e.key]); }
    });
  }

  /* ---------- 拖拽 ----------
   * KG.draggable(el, {
   *   onStart(el),               拿起时（会自动播放 pick 音效）
   *   onDrop(x, y, el) -> bool   松手时，返回 true 表示被接收（不回弹）
   * })
   * 只响应一根手指；移动超过 8px 才算拖拽，否则视为点击（不拦截 click）。
   */
  var activePointer = null;
  KG.draggable = function (el, opts) {
    var sx = 0, sy = 0, moved = false, pid = null;
    el.style.touchAction = 'none';
    el.addEventListener('pointerdown', function (e) {
      if (activePointer !== null || KG.paused || el.classList.contains('kg-locked')) return;
      activePointer = pid = e.pointerId;
      sx = e.clientX; sy = e.clientY; moved = false;
      try { el.setPointerCapture(pid); } catch (err) { /* ignore */ }
    });
    el.addEventListener('pointermove', function (e) {
      if (e.pointerId !== pid) return;
      var dx = e.clientX - sx, dy = e.clientY - sy;
      if (!moved && Math.abs(dx) + Math.abs(dy) > 8) {
        moved = true;
        el.classList.add('kg-dragging');
        KG.sfx('pick');
        if (opts.onStart) opts.onStart(el);
      }
      if (moved) el.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(1.08)';
    });
    function end(e) {
      if (e.pointerId !== pid) return;
      activePointer = pid = null;
      if (!moved) return;
      el._suppressClick = true;
      setTimeout(function () { el._suppressClick = false; }, 60);
      var accepted = opts.onDrop ? opts.onDrop(e.clientX, e.clientY, el) : false;
      el.classList.remove('kg-dragging');
      if (!accepted) KG.bounceBack(el);
      else el.style.transform = '';
    }
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
    el.addEventListener('click', function (e) { if (el._suppressClick) { e.stopImmediatePropagation(); e.preventDefault(); } }, true);
  };
  KG.bounceBack = function (el) {
    el.classList.add('kg-bounce');
    el.style.transform = '';
    setTimeout(function () { el.classList.remove('kg-bounce'); }, 420);
  };
  /** 在 targets 中找离 (x,y) 最近、且在 pad 像素吸附范围内的目标。 */
  KG.findTarget = function (x, y, targets, pad) {
    pad = pad === undefined ? 36 : pad;
    var best = null, bd = Infinity;
    Array.prototype.forEach.call(targets, function (t) {
      var r = t.getBoundingClientRect();
      if (x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad) {
        var d = Math.hypot(x - (r.left + r.width / 2), y - (r.top + r.height / 2));
        if (d < bd) { bd = d; best = t; }
      }
    });
    return best;
  };
  KG.shake = function (el) {
    el.classList.remove('kg-shake');
    void el.offsetWidth;
    el.classList.add('kg-shake');
  };

  /* ---------- 界面组件 ---------- */
  var DOG = {
    happy: '<ellipse cx="25" cy="52" rx="14" ry="27" transform="rotate(22 25 52)" fill="#B8763E"/><ellipse cx="95" cy="52" rx="14" ry="27" transform="rotate(-22 95 52)" fill="#B8763E"/><circle cx="60" cy="63" r="40" fill="#F4C78C"/><ellipse cx="44" cy="55" rx="14" ry="12" fill="#E2A563" opacity=".75"/><ellipse cx="60" cy="82" rx="25" ry="19" fill="#FFF3DF"/><circle cx="45" cy="57" r="5.8" fill="#3B2A1E"/><circle cx="75" cy="57" r="5.8" fill="#3B2A1E"/><circle cx="47" cy="55" r="2" fill="#fff"/><circle cx="77" cy="55" r="2" fill="#fff"/><path d="M55 85c0 9 10 9 10 0z" fill="#F27C8A"/><ellipse cx="60" cy="73" rx="7.5" ry="5.5" fill="#3B2A1E"/><path d="M60 78v4M60 82c-3 5-9 5-11 1M60 82c3 5 9 5 11 1" stroke="#3B2A1E" stroke-width="2.6" fill="none" stroke-linecap="round"/><circle cx="33" cy="74" r="5.5" fill="#F59E9E" opacity=".55"/><circle cx="87" cy="74" r="5.5" fill="#F59E9E" opacity=".55"/>',
    think: '<ellipse cx="25" cy="54" rx="14" ry="27" transform="rotate(16 25 54)" fill="#B8763E"/><ellipse cx="95" cy="54" rx="14" ry="27" transform="rotate(-16 95 54)" fill="#B8763E"/><circle cx="60" cy="63" r="40" fill="#F4C78C"/><ellipse cx="44" cy="55" rx="14" ry="12" fill="#E2A563" opacity=".75"/><ellipse cx="60" cy="82" rx="25" ry="19" fill="#FFF3DF"/><circle cx="47" cy="55" r="5.8" fill="#3B2A1E"/><circle cx="77" cy="55" r="5.8" fill="#3B2A1E"/><ellipse cx="60" cy="73" rx="7.5" ry="5.5" fill="#3B2A1E"/><path d="M53 85q7-3 14 0" stroke="#3B2A1E" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
  };
  KG.dogSVG = function (kind, size) {
    size = size || 64;
    return '<svg class="kg-dog" width="' + size + '" height="' + size + '" viewBox="0 0 120 120" aria-hidden="true">' + (DOG[kind] || DOG.happy) + '</svg>';
  };

  KG.mountHeader = function (title, rightHtml) {
    var h = KG.el('<header class="kg-header"><button class="kg-back" data-nav aria-label="返回"><svg width="26" height="26" viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><h1 class="kg-title"></h1><div class="kg-right"></div></header>');
    h.querySelector('.kg-title').textContent = title;
    if (rightHtml) h.querySelector('.kg-right').innerHTML = rightHtml;
    h.querySelector('.kg-back').addEventListener('click', function () { KG.exit(); });
    document.body.insertBefore(h, document.body.firstChild);
    return h;
  };

  KG.toast = function (text) {
    var old = document.querySelector('.kg-toast'); if (old) old.remove();
    var t = KG.el('<div class="kg-toast"></div>');
    t.textContent = text;
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2000);
  };

  /** 通关弹层。opts: {title, text, stars(0-3), replayText, onReplay, onNext, nextText} */
  KG.showWin = function (opts) {
    opts = opts || {};
    KG.sfx('win');
    var kid = KG.profile.ageTier !== 'sn';
    var conf = '';
    var cols = ['#FF9F43', '#3FBF84', '#4AA3EE', '#F2678A', '#FFC94A', '#A27FE6'];
    for (var i = 0; i < 18; i++) conf += '<i style="left:' + (4 + i * 5.3) + '%;background:' + cols[i % 6] + ';animation-delay:' + ((i * 137) % 1000 / 1000 * 1.6).toFixed(2) + 's"></i>';
    var stars = '';
    if (opts.stars) for (var s = 1; s <= 3; s++) stars += '<span class="kg-star' + (s <= opts.stars ? ' on' : '') + '">★</span>';
    var ov = KG.el('<div class="kg-overlay kg-win"><div class="kg-confetti">' + conf + '</div><div class="kg-win-card">'
      + (kid ? KG.dogSVG('happy', 120) : '')
      + '<h2></h2><p></p><div class="kg-stars">' + stars + '</div><div class="kg-row">'
      + (opts.onNext ? '<button class="kg-btn" data-nav data-autofocus data-act="next"></button>' : '')
      + '<button class="kg-btn' + (opts.onNext ? ' ghost' : '') + '" data-nav ' + (opts.onNext ? '' : 'data-autofocus ') + 'data-act="replay"></button>'
      + '<button class="kg-btn ghost" data-nav data-act="home">回首页</button></div></div></div>');
    ov.querySelector('h2').textContent = opts.title || (kid ? '太棒了！' : '完成！');
    ov.querySelector('p').textContent = opts.text || '';
    ov.querySelector('[data-act="replay"]').textContent = opts.replayText || '再玩一次';
    if (opts.onNext) ov.querySelector('[data-act="next"]').textContent = opts.nextText || '下一关';
    function close() { ov.remove(); nav.refresh(); }
    ov.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]'); if (!b) return;
      var a = b.getAttribute('data-act');
      close();
      if (a === 'home') KG.exit();
      else if (a === 'next' && opts.onNext) opts.onNext();
      else if (a === 'replay' && opts.onReplay) opts.onReplay();
    });
    ov._onBack = function () { close(); KG.exit(); };
    document.body.appendChild(ov);
    if (nav.enabled) nav.focus(ov.querySelector('[data-autofocus]'));
    if (kid) KG.say({ key: 'win_1', zh: '太棒了，你完成啦！' });
    return ov;
  };

  /* ---------- 初始化 ----------
   * KG.init({ id, nav: true|false, onInput(key) -> true 表示已处理, onBack() -> true 表示已处理, onPause, onResume })
   * nav 为 true 时启用 [data-nav] 元素的方向键焦点导航（电视）。
   */
  KG.init = function (opts) {
    KG.id = opts.id;
    KG._handlers = opts;
    nav.enabled = !!opts.nav && KG.isDpad();
    var root = document.documentElement;
    root.classList.add('tier-' + KG.profile.ageTier);
    root.classList.add('input-' + KG.profile.input);
    // 首次触摸时解锁 WebAudio
    document.addEventListener('pointerdown', function unlock() { actx(); document.removeEventListener('pointerdown', unlock); });
    return KG.profile;
  };

  window.KidsGame = KG;
})();
