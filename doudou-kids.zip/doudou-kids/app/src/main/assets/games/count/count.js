/* 数一数：点每个物品数数（每点一下读出下一个数字），数完从 3 个答案里选总数。每局 5 轮。 */
(function () {
  'use strict';
  var KG = window.KidsGame;

  var ZH = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十',
    '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十'];
  var EN = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
    'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty'];
  function numItem(n) { return { key: 'num_' + n, zh: ZH[n], en: EN[n] }; }

  var OBJECTS = ['🍎', '⭐', '🐟', '🦆', '🍓', '🚗', '🎈', '🐞', '🌸', '🍌', '🐥', '🧸'];
  var PROMPT_COUNT = { key: 'prompt_count_1', zh: '点一点，数一数有几个' };
  var PROMPT_TOTAL = { key: 'prompt_count_2', zh: '一共有几个呢？' };

  var ROUNDS = 5;
  var young = KG.profile.ageTier === 'qm';
  var MAXN = young ? 10 : 20;
  // 每轮的数量范围，由少到多
  var RANGES = young
    ? [[1, 4], [3, 6], [4, 8], [5, 10], [5, 10]]
    : [[3, 8], [5, 12], [8, 15], [10, 20], [10, 20]];

  var field = document.getElementById('field');
  var grid = document.getElementById('grid');
  var answersEl = document.getElementById('answers');
  var round = 0, n = 0, counted = 0, mistakes = 0, busy = false;
  var objEls = [];

  /* 暂停时推迟执行的定时器 */
  var queued = [];
  function later(fn, ms) {
    setTimeout(function () {
      if (KG.paused) queued.push(fn); else fn();
    }, ms);
  }

  /* ---------- 一轮 ---------- */
  function startSession() {
    round = 0;
    mistakes = 0;
    nextRound();
  }

  function nextRound() {
    if (round >= ROUNDS) { finish(); return; }
    var r = RANGES[round];
    n = KG.rand(r[0], r[1]);
    counted = 0;
    busy = false;
    round++;
    var emoji = KG.pick(OBJECTS);
    grid.innerHTML = '';
    objEls = [];
    for (var i = 0; i < n; i++) {
      var b = KG.el('<button class="obj" data-nav><span class="em">' + emoji + '</span></button>');
      b.addEventListener('click', onObj);
      grid.appendChild(b);
      objEls.push(b);
    }
    answersEl.classList.remove('show');
    answersEl.innerHTML = '';
    updateHeader();
    layout();
    KG.nav.refresh(objEls[0]);
    KG.say(PROMPT_COUNT);
  }

  /** 按区域大小给物品选一个尽量大的尺寸。 */
  function layout() {
    if (!objEls.length) return;
    var r = field.getBoundingClientRect();
    var s = 48, cols = 1;
    for (var t = 150; t >= 48; t -= 2) {
      var c = Math.floor(r.width / t);
      if (c < 1) continue;
      if (Math.ceil(objEls.length / c) * t <= r.height) { s = t; cols = c; break; }
    }
    if (s === 48) cols = Math.max(1, Math.floor(r.width / s));
    cols = Math.min(cols, objEls.length);
    grid.style.gridTemplateColumns = 'repeat(' + cols + ',' + s + 'px)';
    objEls.forEach(function (b) {
      b.style.width = b.style.height = (s - 10) + 'px';
      b.querySelector('.em').style.fontSize = Math.round(s * 0.56) + 'px';
    });
  }

  function onObj(e) {
    var b = e.currentTarget;
    if (busy) return;
    if (b.classList.contains('counted')) {
      // 已经数过：轻轻摇一下，不重复计数
      KG.shake(b);
      return;
    }
    counted++;
    b.classList.add('counted');
    var badge = KG.el('<span class="badge"></span>');
    badge.textContent = counted;
    b.appendChild(badge);
    var em = b.querySelector('.em');
    em.classList.remove('kg-pop');
    void em.offsetWidth;
    em.classList.add('kg-pop');
    KG.sfx('tap');
    updateHeader();
    if (counted < n) {
      KG.say(numItem(counted));
    } else {
      KG.sayAll([numItem(counted), PROMPT_TOTAL]);
      showAnswers();
    }
  }

  function showAnswers() {
    var pool = [];
    for (var d = -3; d <= 3; d++) {
      var v = n + d;
      if (d !== 0 && v >= 1 && v <= MAXN) pool.push(v);
    }
    // 优先选相差 1–2 的干扰项
    pool.sort(function (a, b) { return Math.abs(a - n) - Math.abs(b - n) || Math.random() - 0.5; });
    var near = KG.shuffle(pool.slice(0, Math.min(4, pool.length)));
    var opts = [n, near[0], near[1]].sort(function (a, b) { return a - b; });
    answersEl.innerHTML = '';
    opts.forEach(function (v) {
      var b = KG.el('<button class="ans" data-nav></button>');
      b.textContent = v;
      b.addEventListener('click', function () { choose(b, v); });
      answersEl.appendChild(b);
    });
    answersEl.classList.add('show');
    KG.nav.refresh(answersEl.firstChild);
  }

  function choose(b, v) {
    if (busy) return;
    if (v === n) {
      busy = true;
      b.classList.add('right', 'kg-pop');
      KG.sfx('ok');
      KG.sayAll([KG.praiseItem(), numItem(n)]);
      later(nextRound, 2200);
    } else {
      mistakes++;
      b.classList.add('tried');
      KG.shake(b);
      KG.say(KG.hintItem());
    }
  }

  function finish() {
    var stars = mistakes === 0 ? 3 : 2;
    KG.recordStars('count_' + KG.profile.ageTier, stars);
    KG.showWin({ stars: stars, onReplay: startSession });
  }

  function updateHeader() {
    counterEl.textContent = counted;
    var dots = '';
    for (var i = 1; i <= ROUNDS; i++) dots += '<i' + (i <= round ? ' class="on"' : '') + '></i>';
    dotsEl.innerHTML = dots;
  }

  /* ---------- 启动 ---------- */
  KG.init({
    id: 'count',
    nav: true,
    onPause: function () {},
    onResume: function () {
      var q = queued; queued = [];
      q.forEach(function (fn) { fn(); });
    }
  });
  var header = KG.mountHeader('数一数', '<div class="rdots"></div><div class="counter kg-big-num">0</div>');
  var dotsEl = header.querySelector('.rdots');
  var counterEl = header.querySelector('.counter');

  window.addEventListener('resize', layout);
  startSession();
})();
