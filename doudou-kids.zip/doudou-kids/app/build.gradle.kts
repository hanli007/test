import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// 激活码密钥从 local.properties 读取（不提交到仓库）：doudou.licenseSecret=一串足够长的随机字符
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val licenseSecret: String = localProps.getProperty("doudou.licenseSecret") ?: "DEV-ONLY-CHANGE-ME"

android {
    namespace = "com.doudou.kids"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.doudou.kids"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        buildConfigField("String", "LICENSE_SECRET", "\"$licenseSecret\"")
    }

    // standard：声明桌面（HOME）入口，可设为默认桌面。
    // guard：完全不声明 HOME，给拒绝安装「桌面类 app」的固件用（部分 TCL、海信，报 INSTALL_FAILED_USER_RESTRICTED），
    // 靠无障碍服务在厂商桌面出现时把豆豆乐园拉回来。做法参考 PlanYourTV（MIT），见方案 3.1.1。
    flavorDimensions += "home"
    productFlavors {
        create("standard") {
            dimension = "home"
            buildConfigField("boolean", "HOME_DECLARED", "true")
        }
        create("guard") {
            dimension = "home"
            versionNameSuffix = "-guard"
            buildConfigField("boolean", "HOME_DECLARED", "false")
        }
    }

    buildTypes {
        debug {
            // 调试包跳过激活，方便真机测试
            buildConfigField("boolean", "REQUIRE_ACTIVATION", "false")
        }
        release {
            buildConfigField("boolean", "REQUIRE_ACTIVATION", "true")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.process)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.foundation)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons)
    implementation(libs.compose.ui.tooling.preview)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    implementation(libs.media3.exoplayer)
    implementation(libs.media3.exoplayer.hls)
    implementation(libs.media3.ui)
    implementation(libs.androidx.webkit)
    implementation(libs.okhttp)
    implementation(libs.kotlinx.coroutines.android)

    implementation(libs.camerax.core)
    implementation(libs.camerax.camera2)
    implementation(libs.camerax.lifecycle)
    implementation(libs.mlkit.face)

    testImplementation(libs.junit)
    testImplementation(libs.org.json)
}
