#!/usr/bin/env python3
"""豆豆乐园激活码生成工具（作者用）。

算法必须与 app/src/main/java/com/doudou/kids/core/LicenseCodec.kt 保持一致：
    激活码 = Crockford Base32(HMAC-SHA256(密钥, "DDKIDS1|" + 规范化设备码)) 的前 16 位，每 4 位一组

密钥读取顺序：--secret 参数 → 环境变量 DOUDOU_LICENSE_SECRET → 工程根目录 local.properties 的 doudou.licenseSecret。

用法：
    python3 tools/license/gen_code.py ABCDE-12345
    python3 tools/license/gen_code.py ABCDE-12345 FGHJK-67890 --secret xxxx
    python3 tools/license/gen_code.py --verify ABCDE-12345 XXXX-XXXX-XXXX-XXXX
"""
import argparse
import hashlib
import hmac
import os
import sys
from pathlib import Path

ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
DEV_SECRET = "DEV-ONLY-CHANGE-ME"


def normalize(code: str) -> str:
    """大写，去掉分隔符；把容易看错的 O/I/L 换成 0/1/1。"""
    out = []
    for c in code.upper():
        if c == "O":
            out.append("0")
        elif c in "IL":
            out.append("1")
        elif c in ALPHABET:
            out.append(c)
    return "".join(out)


def base32(data: bytes) -> str:
    out, buf, bits = [], 0, 0
    for b in data:
        buf = (buf << 8) | b
        bits += 8
        while bits >= 5:
            out.append(ALPHABET[(buf >> (bits - 5)) & 31])
            bits -= 5
    if bits > 0:
        out.append(ALPHABET[(buf << (5 - bits)) & 31])
    return "".join(out)


def group(s: str, size: int) -> str:
    return "-".join(s[i:i + size] for i in range(0, len(s), size))


def activation_code(secret: str, device_code: str) -> str:
    mac = hmac.new(secret.encode("utf-8"), ("DDKIDS1|" + normalize(device_code)).encode("utf-8"), hashlib.sha256).digest()
    return group(base32(mac)[:16], 4)


def read_secret(arg: str | None) -> str:
    if arg:
        return arg
    env = os.environ.get("DOUDOU_LICENSE_SECRET")
    if env:
        return env
    props = Path(__file__).resolve().parents[2] / "local.properties"
    if props.exists():
        for line in props.read_text(encoding="utf-8").splitlines():
            key, sep, value = line.partition("=")
            if sep and key.strip() == "doudou.licenseSecret":
                return value.strip()
    return ""


def main() -> int:
    p = argparse.ArgumentParser(description="豆豆乐园激活码生成工具")
    p.add_argument("device_codes", nargs="*", help="app 激活页显示的设备码，格式 XXXXX-XXXXX")
    p.add_argument("--secret", help="激活码密钥（与编译时 local.properties 的 doudou.licenseSecret 相同）")
    p.add_argument("--verify", nargs=2, metavar=("DEVICE", "CODE"), help="检查一个激活码是否正确")
    p.add_argument("--allow-dev-secret", action="store_true", help="允许使用调试密钥（只用于测试）")
    a = p.parse_args()

    secret = read_secret(a.secret)
    if not secret:
        print("找不到密钥：请用 --secret、环境变量 DOUDOU_LICENSE_SECRET 或 local.properties 提供", file=sys.stderr)
        return 2
    if secret == DEV_SECRET and not a.allow_dev_secret:
        print("当前是调试密钥 DEV-ONLY-CHANGE-ME，正式包不会认这个码。确实要用请加 --allow-dev-secret", file=sys.stderr)
        return 2

    if a.verify:
        device, code = a.verify
        ok = hmac.compare_digest(normalize(code), normalize(activation_code(secret, device)))
        print("正确" if ok else "不正确")
        return 0 if ok else 1

    if not a.device_codes:
        p.print_help()
        return 2
    for d in a.device_codes:
        if len(normalize(d)) != 10:
            print(f"{d}\t设备码应为 10 位（XXXXX-XXXXX）", file=sys.stderr)
            continue
        print(f"{group(normalize(d), 5)}\t{activation_code(secret, d)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
