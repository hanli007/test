#!/usr/bin/env node
/*
 * 华容道关卡校验：node tools/games/validate-klotski.js [levels.json]
 * 对 type=block 的关卡做 BFS（每移动一格算一步），确认有解并核对 par；检查每块都是矩形。
 */
'use strict';
var fs = require('fs');
var path = require('path');
var file = process.argv[2] || path.join(__dirname, '../../app/src/main/assets/games/klotski/levels.json');
var data = JSON.parse(fs.readFileSync(file, 'utf8'));
var W = 4, H = 5;

function parse(rows) {
  var b = {}, err = null;
  for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
    var ch = rows[y][x]; if (ch === '.') continue;
    if (!b[ch]) b[ch] = { x: x, y: y, w: 1, h: 1, cells: 0 };
    var k = b[ch];
    k.w = Math.max(k.w, x - k.x + 1); k.h = Math.max(k.h, y - k.y + 1); k.cells++;
  }
  Object.keys(b).forEach(function (k) { if (b[k].w * b[k].h !== b[k].cells) err = '块 ' + k + ' 不是矩形'; });
  return { blocks: b, err: err };
}

function solve(rows) {
  var p = parse(rows); if (p.err) return p.err;
  var b = p.blocks, keys = Object.keys(b);
  var big = keys.filter(function (k) { return b[k].w === 2 && b[k].h === 2; });
  if (big.length !== 1) return '必须恰好一个 2×2 曹操';
  var bi = keys.indexOf(big[0]);
  function shape(s) { return s.w === 2 && s.h === 2 ? 'C' : s.w === 2 ? 'H' : s.h === 2 ? 'V' : 'S'; }
  function enc(pos) {
    var g = []; for (var i = 0; i < W * H; i++) g.push('.');
    keys.forEach(function (k, i) { var s = b[k]; for (var dy = 0; dy < s.h; dy++) for (var dx = 0; dx < s.w; dx++) g[(pos[i][1] + dy) * W + pos[i][0] + dx] = shape(s); });
    return g.join('');
  }
  var start = keys.map(function (k) { return [b[k].x, b[k].y]; });
  var seen = {}; seen[enc(start)] = 1;
  var q = [start], d = 0;
  while (q.length) {
    var nq = [];
    for (var qi = 0; qi < q.length; qi++) {
      var pos = q[qi];
      if (pos[bi][0] === 1 && pos[bi][1] === 3) return d;
      var occ = []; for (var o = 0; o < W * H; o++) occ.push(-1);
      keys.forEach(function (k, i) { var s = b[k]; for (var dy = 0; dy < s.h; dy++) for (var dx = 0; dx < s.w; dx++) occ[(pos[i][1] + dy) * W + pos[i][0] + dx] = i; });
      for (var i = 0; i < keys.length; i++) {
        var s = b[keys[i]];
        [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (m) {
          var nx = pos[i][0] + m[0], ny = pos[i][1] + m[1];
          if (nx < 0 || ny < 0 || nx + s.w > W || ny + s.h > H) return;
          for (var dy = 0; dy < s.h; dy++) for (var dx = 0; dx < s.w; dx++) {
            var v = occ[(ny + dy) * W + nx + dx]; if (v !== -1 && v !== i) return;
          }
          var np = pos.slice(); np[i] = [nx, ny];
          var e = enc(np);
          if (!seen[e]) { seen[e] = 1; nq.push(np); }
        });
      }
    }
    q = nq; d++;
  }
  return '无解';
}

var failed = false;
data.levels.forEach(function (lv) {
  if (lv.type !== 'block') { console.log(lv.id + ' ' + lv.name + '（数字推盘，游戏内只生成可解排列）'); return; }
  if (lv.grid.length !== H || lv.grid.some(function (r) { return r.length !== W; })) { console.log(lv.id + ' ✗ 尺寸必须 4×5'); failed = true; return; }
  var r = solve(lv.grid);
  if (typeof r !== 'number') { console.log(lv.id + ' ✗ ' + r); failed = true; return; }
  var ok = r === lv.par;
  if (!ok) failed = true;
  console.log(lv.id + ' ' + lv.name + ' 最少 ' + r + ' 步' + (ok ? ' ✓' : ' ✗ par 写的是 ' + lv.par));
});
console.log(failed ? '\n有问题，请修正。' : '\n全部可解。');
process.exit(failed ? 1 : 0);
