// 检查数独每个难度都能生成唯一解盘面：node tools/games/check-sudoku.js [每档次数]
var path = require('path');
var S = require(path.join(__dirname, '../../app/src/main/assets/games/sudoku/sudoku-core.js'));
var times = parseInt(process.argv[2] || '10', 10), bad = 0;
S.LEVEL_ORDER.forEach(function (lv) {
  var t0 = Date.now(), gv = [], sing = 0, maxMs = 0;
  for (var i = 0; i < times; i++) {
    var t1 = Date.now();
    var g = S.generate(lv);
    maxMs = Math.max(maxMs, Date.now() - t1);
    var cnt = S.countSolutions(g.puzzle, g.n, 2);
    var solved = S.solve(g.puzzle, g.n);
    if (cnt !== 1 || solved.join() !== g.solution.join()) { bad++; console.log('BAD', lv, cnt); }
    for (var k = 0; k < g.puzzle.length; k++) if (g.puzzle[k] && g.puzzle[k] !== g.solution[k]) { bad++; console.log('BAD given', lv); }
    if (S.solvableBySingles(g.puzzle, g.n)) sing++;
    gv.push(g.givens);
  }
  console.log(lv, 'n=' + S.LEVELS[lv].n, 'givens', Math.min.apply(null, gv) + '-' + Math.max.apply(null, gv),
    'singles-solvable', sing + '/' + times, 'avg ms', Math.round((Date.now() - t0) / times), 'max ms', maxMs);
});
if (bad) { console.log('FAILED', bad); process.exit(1); } else console.log('OK');
