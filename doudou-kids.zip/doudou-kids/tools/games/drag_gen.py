#!/usr/bin/env python3
"""Generate drag-engine level sets for 豆豆乐园 (games/drag/sets/*.json) and meta.json."""
import json, os

# 相对于本脚本定位：tools/games/ -> app/src/main/assets/games/drag
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'app', 'src', 'main', 'assets', 'games', 'drag'))
SETS = os.path.join(ROOT, 'sets')
os.makedirs(SETS, exist_ok=True)

NUM_ZH = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
NUM_EN = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten']
CN_COUNT = ['零', '一', '两', '三', '四', '五', '六', '七', '八', '九', '十']
DIGIT_COLORS = ['#4A3424', '#E8505B', '#FF8A1F', '#D99A00', '#3FA35B', '#2F7FD8', '#8E6BD9', '#E0508F', '#1597A8', '#B8763E', '#5468D4']


def num(n):
    return {'key': 'num_%d' % n, 'zh': NUM_ZH[n], 'en': NUM_EN[n]}


def sp(key, zh, en):
    return {'key': key, 'zh': zh, 'en': en}


# Shared speech catalogue: one key always has the same zh/en everywhere.
S = {
    'apple': sp('food_apple', '苹果', 'apple'), 'banana': sp('food_banana', '香蕉', 'banana'),
    'orange': sp('food_orange', '橙子', 'orange'), 'grape': sp('food_grape', '葡萄', 'grapes'),
    'strawberry': sp('food_strawberry', '草莓', 'strawberry'), 'carrot': sp('food_carrot', '胡萝卜', 'carrot'),
    'fishfood': sp('food_fish', '鱼', 'fish'), 'bamboo': sp('food_bamboo', '竹子', 'bamboo'),
    'cheese': sp('food_cheese', '奶酪', 'cheese'), 'honey': sp('food_honey', '蜂蜜', 'honey'),
    'bone': sp('item_bone', '骨头', 'bone'),
    'dog': sp('animal_dog', '小狗', 'dog'), 'cat': sp('animal_cat', '小猫', 'cat'),
    'rabbit': sp('animal_rabbit', '小兔子', 'rabbit'), 'fish': sp('animal_fish', '小鱼', 'fish'),
    'octopus': sp('animal_octopus', '章鱼', 'octopus'), 'whale': sp('animal_whale', '鲸鱼', 'whale'),
    'cow': sp('animal_cow', '奶牛', 'cow'), 'sheep': sp('animal_sheep', '小羊', 'sheep'),
    'bird': sp('animal_bird', '小鸟', 'bird'), 'eagle': sp('animal_eagle', '老鹰', 'eagle'),
    'monkey': sp('animal_monkey', '小猴子', 'monkey'), 'koala': sp('animal_koala', '考拉', 'koala'),
    'squirrel': sp('animal_squirrel', '松鼠', 'squirrel'), 'elephant': sp('animal_elephant', '大象', 'elephant'),
    'turtle': sp('animal_turtle', '乌龟', 'turtle'), 'bear': sp('animal_bear', '小熊', 'bear'),
    'panda': sp('animal_panda', '熊猫', 'panda'), 'pig': sp('animal_pig', '小猪', 'pig'),
    'bird2': sp('animal_bird', '小鸟', 'bird'), 'frog': sp('animal_frog', '青蛙', 'frog'),
    'duck': sp('animal_duck', '小鸭子', 'duck'), 'chick': sp('animal_chick', '小鸡', 'chick'),
    'car': sp('vehicle_car', '小汽车', 'car'), 'bus': sp('vehicle_bus', '公交车', 'bus'),
    'plane': sp('vehicle_plane', '飞机', 'airplane'), 'ship': sp('vehicle_ship', '轮船', 'ship'),
    'rocket': sp('vehicle_rocket', '火箭', 'rocket'),
    'ball': sp('item_ball', '皮球', 'ball'), 'teddy': sp('item_teddy', '玩具熊', 'teddy bear'),
    'balloon': sp('item_balloon', '气球', 'balloon'), 'sun': sp('item_sun', '太阳', 'sun'),
    'moon': sp('item_moon', '月亮', 'moon'), 'star': sp('item_star', '星星', 'star'),
    'house': sp('item_house', '房子', 'house'), 'book': sp('item_book', '书', 'book'),
    'egg': sp('food_egg', '鸡蛋', 'egg'), 'cake': sp('food_cake', '蛋糕', 'cake'), 'milk': sp('food_milk', '牛奶', 'milk'),
}
EMO = {
    'apple': '🍎', 'banana': '🍌', 'orange': '🍊', 'grape': '🍇', 'strawberry': '🍓', 'carrot': '🥕',
    'fishfood': '🐟', 'bamboo': '🎋', 'cheese': '🧀', 'honey': '🍯', 'bone': '🦴',
    'dog': '🐶', 'cat': '🐱', 'rabbit': '🐰', 'fish': '🐟', 'octopus': '🐙', 'whale': '🐳', 'cow': '🐄',
    'sheep': '🐑', 'bird': '🐦', 'eagle': '🦅', 'monkey': '🐒', 'koala': '🐨', 'squirrel': '🐿️',
    'elephant': '🐘', 'turtle': '🐢', 'bear': '🐻', 'panda': '🐼', 'pig': '🐷', 'frog': '🐸', 'duck': '🦆',
    'chick': '🐥', 'car': '🚗', 'bus': '🚌', 'plane': '✈️', 'ship': '🚢', 'rocket': '🚀',
    'ball': '⚽', 'teddy': '🧸', 'balloon': '🎈', 'sun': '☀️', 'moon': '🌙', 'star': '⭐', 'house': '🏠',
    'book': '📖', 'egg': '🥚', 'cake': '🎂', 'milk': '🥛',
}
SHAPE = {
    'circle': ('#E8505B', sp('shape_circle', '圆形', 'circle')),
    'square': ('#2F95EA', sp('shape_square', '正方形', 'square')),
    'triangle': ('#3FB26B', sp('shape_triangle', '三角形', 'triangle')),
    'star': ('#F5B800', sp('shape_star', '星形', 'star')),
    'heart': ('#EC5FA0', sp('shape_heart', '心形', 'heart')),
    'oval': ('#FF8A1F', sp('shape_oval', '椭圆形', 'oval')),
    'rectangle': ('#8E6BD9', sp('shape_rectangle', '长方形', 'rectangle')),
}
COLOR = {
    'red': ('#E8505B', sp('color_red', '红色', 'red')),
    'yellow': ('#F5B800', sp('color_yellow', '黄色', 'yellow')),
    'blue': ('#2F7FD8', sp('color_blue', '蓝色', 'blue')),
    'green': ('#3FA35B', sp('color_green', '绿色', 'green')),
}


def letter(ch):
    return sp('letter_' + ch.lower(), ch.upper(), ch.upper())


class Prompts:
    def __init__(self, name):
        self.name, self.n, self.seen = name, 0, {}

    def __call__(self, zh):
        if zh not in self.seen:
            self.n += 1
            self.seen[zh] = {'key': 'prompt_%s_%d' % (self.name, self.n), 'zh': zh}
        return dict(self.seen[zh])


def hint(name, zh, suffix=''):
    return {'key': 'hint_%s%s' % (name.replace('-', '_'), suffix), 'zh': zh}


def write(name, data):
    with open(os.path.join(SETS, name + '.json'), 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
        f.write('\n')


def digit_item(n):
    return {'id': 'n%d' % n, 'match': 't%d' % n, 'art': {'text': str(n), 'color': DIGIT_COLORS[n]}, 'speech': num(n)}


# 1. train ---------------------------------------------------------------
def gen_train():
    P = Prompts('train')
    cars = ['#4AA3EE', '#3FBF84', '#F2678A', '#A27FE6', '#FFB020']
    levels = []
    for n in (3, 4, 5):
        levels.append({
            'prompt': P('把数字送到对应的车厢吧'),
            'promptTq': P('数一数车厢上的点点，把数字送上车吧'),
            'targets': [{'id': 't%d' % i, 'frame': 'carriage', 'place': 'stack', 'color': cars[(i - 1) % 5],
                         'art': {'text': str(i), 'color': DIGIT_COLORS[i]}, 'artTq': {'dots': i, 'color': DIGIT_COLORS[i]}}
                        for i in range(1, n + 1)],
            'items': [digit_item(i) for i in range(1, n + 1)],
        })
    write('train', {'title': '小火车数字', 'rule': 'pair', 'layout': 'train',
                    'wrongHint': hint('train', '再看看车厢上的数字哦'),
                    'wrongHintTq': hint('train', '再数一数车厢上的点点哦', '_tq'),
                    'levels': levels})


# 2. count-match -----------------------------------------------------------
def gen_count():
    P = Prompts('count-match')
    levels = []
    for fruit, ns in (('apple', [1, 2, 3]), ('strawberry', [2, 3, 4]), ('orange', [3, 4, 5]), ('banana', [2, 4, 5, 6])):
        levels.append({
            'prompt': P('数一数盘子里有几个，把数字放到盘子下面'),
            'shuffleTargets': True,
            'targets': [{'id': 't%d' % n, 'frame': 'plate', 'place': 'stack', 'art': {'emoji': EMO[fruit], 'count': n}} for n in ns],
            'items': [digit_item(n) for n in ns],
        })
    write('count-match', {'title': '数量配对', 'rule': 'pair',
                          'wrongHint': hint('count-match', '再数一数盘子里有几个哦'), 'levels': levels})


# 3. feed-animals ----------------------------------------------------------
def gen_feed():
    P = Prompts('feed-animals')
    pairs = {'monkey': 'banana', 'rabbit': 'carrot', 'dog': 'bone', 'cat': 'fishfood', 'panda': 'bamboo',
             'mouse': 'cheese', 'bear': 'honey'}
    animal_emo = dict(EMO, mouse='🐭')
    levels = []
    for group in (['monkey', 'rabbit'], ['dog', 'cat', 'monkey'], ['panda', 'rabbit', 'dog', 'cat'],
                  ['mouse', 'bear', 'panda', 'monkey', 'cat']):
        levels.append({
            'prompt': P('小动物饿啦，把好吃的喂给它们吧'),
            'targets': [{'id': a, 'frame': 'animal', 'place': 'stack', 'art': {'emoji': animal_emo[a]}} for a in group],
            'items': [{'id': pairs[a], 'match': a, 'art': {'emoji': EMO[pairs[a]]}, 'speech': S[pairs[a]]} for a in group],
        })
    write('feed-animals', {'title': '喂小动物', 'rule': 'pair',
                           'wrongHint': hint('feed-animals', '想一想，它最爱吃什么呢？'), 'levels': levels})


# 4. basket ------------------------------------------------------------------
def gen_basket():
    P = Prompts('basket')
    levels = []
    for group in (['apple', 'banana', 'orange'], ['ball', 'teddy', 'car', 'balloon'],
                  ['strawberry', 'grape', 'ball', 'teddy', 'apple']):
        levels.append({
            'prompt': P('把东西都放进篮子里吧'),
            'targets': [{'id': 'basket', 'frame': 'basket', 'color': '#D9A066'}],
            'items': [{'id': k, 'match': 'basket', 'art': {'emoji': EMO[k]}, 'speech': S[k]} for k in group],
        })
    write('basket', {'title': '放进篮子', 'rule': 'classify', 'pad': 90,
                     'wrongHint': hint('basket', '放进篮子里吧'), 'levels': levels})


# 5. shape-box ---------------------------------------------------------------
def gen_shape():
    P = Prompts('shape-box')
    levels = []
    for group in (['circle', 'square', 'triangle'], ['circle', 'square', 'triangle', 'star'],
                  ['circle', 'square', 'triangle', 'star', 'heart'], ['circle', 'oval', 'square', 'rectangle', 'triangle']):
        levels.append({
            'prompt': P('把形状放进一样的洞洞里'),
            'shuffleTargets': True,
            'targets': [{'id': s, 'art': {'shape': s, 'hole': True}} for s in group],
            'items': [{'id': s, 'match': s, 'art': {'shape': s, 'color': SHAPE[s][0]}, 'speech': SHAPE[s][1]} for s in group],
        })
    write('shape-box', {'title': '形状盒', 'rule': 'pair', 'board': 'box',
                        'wrongHint': hint('shape-box', '看一看，洞洞是什么形状的？'), 'levels': levels})


# 6. animal-home -------------------------------------------------------------
def gen_home():
    P = Prompts('animal-home')
    homes = {'water': ('水里', '#8FD3FF', '🌊'), 'grass': ('草地', '#A8E07A', '🌱'),
             'sky': ('天空', '#CFE9FF', '☁️'), 'tree': ('树上', '#7CC47F', '🌳')}
    lives = {'fish': 'water', 'octopus': 'water', 'whale': 'water', 'rabbit': 'grass', 'cow': 'grass',
             'sheep': 'grass', 'eagle': 'sky', 'monkey': 'tree', 'koala': 'tree', 'squirrel': 'tree'}
    levels = []
    for hs, animals in ((['water', 'grass'], ['fish', 'rabbit', 'octopus', 'cow']),
                        (['water', 'grass', 'sky'], ['fish', 'sheep', 'bird', 'eagle', 'whale', 'rabbit']),
                        (['water', 'sky', 'grass', 'tree'], ['monkey', 'koala', 'fish', 'bird', 'cow', 'octopus', 'squirrel', 'sheep'])):
        items = []
        for a in animals:
            m = ['sky', 'tree'] if a == 'bird' else lives[a]
            if isinstance(m, list):
                m = [x for x in m if x in hs]
            items.append({'id': a, 'match': m, 'art': {'emoji': EMO[a]}, 'speech': S[a]})
        levels.append({
            'prompt': P('小动物迷路啦，送它们回家吧'),
            'targets': [{'id': h, 'frame': 'zone', 'label': homes[h][0], 'color': homes[h][1], 'art': {'emoji': homes[h][2]}} for h in hs],
            'items': items,
        })
    write('animal-home', {'title': '送动物回家', 'rule': 'classify',
                          'wrongHint': hint('animal-home', '想一想，它住在哪里呢？'), 'levels': levels})


# 7. dress-bear --------------------------------------------------------------
def gen_bear():
    P = Prompts('dress-bear')
    zones = {  # percent of scene width / height; size = percent of width
        'shirt': {'x': 50, 'y': 65, 'size': 44},
        'neck': {'x': 50, 'y': 43, 'size': 36},
        'head': {'x': 50, 'y': 8.5, 'size': 38},
        'hands': {'spots': [{'x': 19, 'y': 67}, {'x': 81, 'y': 67}], 'size': 24},
        'feet': {'spots': [{'x': 36, 'y': 94}, {'x': 64, 'y': 94}], 'size': 26},
    }
    clothes = {
        'hat': ('head', '🎩', sp('body_hat', '帽子', 'hat')),
        'scarf': ('neck', '🧣', sp('body_scarf', '围巾', 'scarf')),
        'shirt': ('shirt', '👕', sp('body_shirt', 'T恤', 'T-shirt')),
        'gloves': ('hands', '🧤', sp('body_gloves', '手套', 'gloves')),
        'shoes': ('feet', '👟', sp('body_shoes', '鞋子', 'shoes')),
    }
    order = ['shirt', 'neck', 'head', 'hands', 'feet']  # later zones draw on top
    levels = []
    for group in (['hat', 'shoes'], ['hat', 'scarf', 'shoes'], ['hat', 'scarf', 'gloves', 'shoes'],
                  ['hat', 'scarf', 'shirt', 'gloves', 'shoes']):
        need = [clothes[c][0] for c in group]
        targets = []
        for z in order:
            if z in need:
                t = {'id': z}
                t.update(zones[z])
                targets.append(t)
        levels.append({
            'prompt': P('小熊要出门啦，帮它穿好衣服吧'),
            'targets': targets,
            'items': [{'id': c, 'match': clothes[c][0], 'art': {'emoji': clothes[c][1]}, 'speech': clothes[c][2]} for c in group],
        })
    write('dress-bear', {'title': '给小熊穿衣服', 'rule': 'pair', 'layout': 'scene', 'scene': 'bear', 'pad': 30,
                         'wrongHint': hint('dress-bear', '想一想，它应该穿在哪里呀？'), 'levels': levels})


# 8. color-sort --------------------------------------------------------------
def gen_color():
    P = Prompts('color-sort')
    things = {'🍎': 'red', '🍓': 'red', '🍒': 'red', '🍅': 'red', '❤️': 'red', '🚒': 'red',
              '🍌': 'yellow', '🍋': 'yellow', '🌽': 'yellow', '🐥': 'yellow', '⭐': 'yellow',
              '🐳': 'blue', '💙': 'blue', '👖': 'blue', '🔵': 'blue',
              '🍏': 'green', '🥦': 'green', '🐸': 'green', '🥒': 'green'}
    levels = []
    for cs, emos in ((['red', 'yellow'], ['🍎', '🍌', '🍓', '🍋']),
                     (['red', 'yellow', 'blue'], ['🍒', '🌽', '💙', '🍅', '🐥', '🐳']),
                     (['red', 'yellow', 'blue', 'green'], ['🍎', '🍌', '👖', '🐸', '🍓', '⭐', '🔵', '🥦']),
                     (['red', 'yellow', 'blue', 'green'], ['🚒', '🍋', '🐳', '🍏', '❤️', '🐥', '💙', '🥒'])):
        levels.append({
            'prompt': P('看看是什么颜色，放进一样颜色的篮子里'),
            'targets': [{'id': c, 'frame': 'basket', 'color': COLOR[c][0], 'label': COLOR[c][1]['zh']} for c in cs],
            'items': [{'id': 'i%d' % i, 'match': things[e], 'art': {'emoji': e}, 'speech': COLOR[things[e]][1]}
                      for i, e in enumerate(emos)],
        })
    write('color-sort', {'title': '颜色分类', 'rule': 'classify',
                         'wrongHint': hint('color-sort', '看一看，它是什么颜色的？'), 'levels': levels})


# 9. size-order --------------------------------------------------------------
def gen_size():
    P = Prompts('size-order')
    words = {
        3: [sp('size_small', '小', 'small'), sp('size_medium', '中', 'medium'), sp('size_big', '大', 'big')],
        4: [sp('size_smallest', '最小', 'smallest'), sp('size_small', '小', 'small'), sp('size_big', '大', 'big'),
            sp('size_biggest', '最大', 'biggest')],
        5: [sp('size_smallest', '最小', 'smallest'), sp('size_small', '小', 'small'), sp('size_medium', '中', 'medium'),
            sp('size_big', '大', 'big'), sp('size_biggest', '最大', 'biggest')],
    }
    levels = []
    for emo, scales in (('🐻', [0.5, 0.75, 1.0]), ('🍎', [0.45, 0.63, 0.82, 1.0]), ('⭐', [0.4, 0.55, 0.7, 0.85, 1.0])):
        n = len(scales)
        levels.append({
            'prompt': P('从小到大，排排队'),
            'show': {'text': '小 → 大', 'font': 'cn'},
            'targets': [{'id': 's%d' % i, 'scale': s} for i, s in enumerate(scales)],
            'items': [{'id': 'i%d' % i, 'match': 's%d' % i, 'art': {'emoji': emo, 'scale': s}, 'speech': words[n][i]}
                      for i, s in enumerate(scales)],
        })
    write('size-order', {'title': '大小排序', 'rule': 'sort', 'layout': 'size', 'pad': 30,
                         'wrongHint': hint('size-order', '再比一比，谁更小呢？'), 'levels': levels})


# 10. pattern ----------------------------------------------------------------
def thing(k):
    if k in SHAPE:
        return {'shape': k, 'color': SHAPE[k][0]}, SHAPE[k][1]
    return {'emoji': EMO[k]}, S[k]


def pattern_round(seq, blank, extra):
    """seq: list of element keys, blank: index of the blank, extra: distractor key."""
    targets = []
    for i, k in enumerate(seq):
        if i == blank:
            targets.append({'id': 'blank'})
        else:
            targets.append({'id': 'f%d' % i, 'fixed': True, 'art': thing(k)[0]})
    answer = seq[blank]
    choices = []
    for k in sorted(set(seq)) + [extra]:
        a, s = thing(k)
        choices.append({'id': 'c_' + k, 'match': 'blank' if k == answer else None, 'art': a, 'speech': s})
    return {'targets': targets, 'items': choices}


def gen_pattern():
    P = Prompts('pattern')
    p = P('找找规律，空格里应该放什么？')
    def lv(group, rounds):
        rs = [pattern_round(*r) for r in rounds]
        return {'prompt': p, 'group': group, 'rounds': rs}
    levels = [
        lv(2, [(['apple', 'banana'] * 3, 5, 'grape'), (['dog', 'cat'] * 3, 5, 'rabbit')]),
        lv(3, [(['circle', 'triangle', 'square'] * 2, 5, 'star'), (['sun', 'moon', 'star'] * 2, 5, 'apple')]),
        lv(3, [(['dog', 'dog', 'cat'] * 2, 5, 'rabbit'), (['apple', 'apple', 'grape'] * 2, 5, 'banana'),
               (['star', 'star', 'heart'] * 2, 5, 'circle')]),
        lv(3, [(['car', 'bus', 'bus'] * 2, 5, 'plane'), (['star', 'circle', 'triangle'] * 2, 1, 'heart'),
               (['rabbit', 'carrot', 'carrot'] * 2, 3, 'apple')]),
    ]
    write('pattern', {'title': '找规律', 'rule': 'sort', 'layout': 'seq',
                      'wrongHint': hint('pattern', '再看看前面是怎么排的哦'), 'levels': levels})


# 11. add-basket --------------------------------------------------------------
def gen_add():
    P = Prompts('add-basket')
    p2 = P('一共有几个苹果？把数字放进问号框里吧')
    def rnd(a, b):
        s = a + b
        choices = [s - 1, s, s + 1] if s < 10 else [8, 9, 10]
        choices = [c for c in choices if c >= 1]
        items = [{'id': 'a%d' % i, 'match': 'basket', 'art': {'emoji': '🍎'}, 'speech': S['apple']} for i in range(b)]
        items += [{'id': 'n%d' % c, 'match': 'ans' if c == s else None, 'stage': 1,
                   'art': {'text': str(c), 'color': DIGIT_COLORS[c]}, 'speech': num(c)} for c in choices]
        return {
            'prompt': [P('篮子里有%s个苹果，再放%s个进去吧' % (CN_COUNT[a], CN_COUNT[b])), p2],
            'show': {'text': '%d + %d = ?' % (a, b)},
            'targets': [{'id': 'basket', 'frame': 'basket', 'color': '#D9A066', 'cap': 99, 'place': 'inside', 'count': True,
                         'contents': [{'emoji': '🍎'}] * a},
                        {'id': 'ans', 'frame': 'answer', 'art': {'text': '?'}}],
            'items': items,
        }
    levels = [{'rounds': [rnd(*r) for r in rs]} for rs in (
        [(1, 1), (2, 1)],
        [(2, 2), (3, 1), (1, 3)],
        [(3, 2), (4, 2), (2, 5)],
        [(5, 3), (4, 4), (6, 3)],
        [(6, 4), (7, 3), (5, 5)],
    )]
    write('add-basket', {'title': '加减启蒙', 'rule': 'pair',
                         'wrongHint': hint('add-basket', '再数一数篮子里的苹果哦'), 'levels': levels})


# 12. letter-match -------------------------------------------------------------
def gen_letters():
    P = Prompts('letter-match')
    levels = []
    for group in ('ABCD', 'EFGHI', 'JKLMN', 'OPQRST', 'UVWXYZ'):
        levels.append({
            'prompt': P('把大写字母送给它的小写字母朋友'),
            'shuffleTargets': True,
            'targets': [{'id': c.lower(), 'frame': 'card', 'place': 'stack', 'art': {'text': c.lower(), 'font': 'latin'}} for c in group],
            'items': [{'id': c, 'match': c.lower(), 'art': {'text': c, 'font': 'latin', 'color': DIGIT_COLORS[1 + i % 10]},
                       'speech': letter(c)} for i, c in enumerate(group)],
        })
    write('letter-match', {'title': '大小写字母', 'rule': 'pair',
                           'wrongHint': hint('letter-match', '再看看，它们长得像不像呀？'), 'levels': levels})


# 13. garbage-sort -------------------------------------------------------------
def gen_garbage():
    P = Prompts('garbage-sort')
    bins = {'recycle': ('可回收物', '#2F7FD8'), 'kitchen': ('厨余垃圾', '#3FA35B'),
            'hazard': ('有害垃圾', '#E04848'), 'other': ('其他垃圾', '#6E7781')}
    junk = {
        'newspaper': ('recycle', '📰', '旧报纸', 'newspaper'),
        'box': ('recycle', '📦', '纸箱', 'cardboard box'),
        'bottle': ('recycle', '🍾', '玻璃瓶', 'glass bottle'),
        'clothes': ('recycle', '👕', '旧衣服', 'old clothes'),
        'can': ('recycle', '🥫', '铁罐', 'tin can'),
        'banana_peel': ('kitchen', '🍌', '香蕉皮', 'banana peel'),
        'watermelon_rind': ('kitchen', '🍉', '西瓜皮', 'watermelon rind'),
        'vegetable_leaves': ('kitchen', '🥬', '菜叶', 'vegetable leaves'),
        'leftover_rice': ('kitchen', '🍚', '剩饭', 'leftover rice'),
        'eggshell': ('kitchen', '🥚', '蛋壳', 'eggshell'),
        'rechargeable_battery': ('hazard', '🔋', '充电电池', 'rechargeable battery'),
        'expired_medicine': ('hazard', '💊', '过期药', 'expired medicine'),
        'thermometer': ('hazard', '🌡️', '水银温度计', 'mercury thermometer'),
        'used_tissue': ('other', '🧻', '用过的纸巾', 'used tissue'),
        'chopsticks': ('other', '🥢', '一次性筷子', 'disposable chopsticks'),
    }
    levels = []
    for bs, ks in ((['recycle', 'kitchen'], ['newspaper', 'banana_peel', 'box', 'watermelon_rind']),
                   (['recycle', 'kitchen', 'hazard'], ['bottle', 'vegetable_leaves', 'rechargeable_battery', 'clothes', 'leftover_rice', 'expired_medicine']),
                   (['recycle', 'kitchen', 'hazard', 'other'], ['newspaper', 'banana_peel', 'rechargeable_battery', 'used_tissue', 'box', 'eggshell', 'thermometer', 'chopsticks']),
                   (['recycle', 'kitchen', 'hazard', 'other'], ['can', 'watermelon_rind', 'expired_medicine', 'used_tissue', 'clothes', 'leftover_rice', 'rechargeable_battery', 'chopsticks'])):
        levels.append({
            'prompt': P('垃圾分一分，环境美十分。把垃圾放进对的垃圾桶吧'),
            'targets': [{'id': b, 'frame': 'bin', 'label': bins[b][0], 'color': bins[b][1]} for b in bs],
            'items': [{'id': k, 'match': junk[k][0], 'art': {'emoji': junk[k][1], 'label': junk[k][2]},
                       'speech': sp('item_' + k, junk[k][2], junk[k][3])} for k in ks],
        })
    write('garbage-sort', {'title': '垃圾分类', 'rule': 'classify',
                           'wrongHint': hint('garbage-sort', '想一想，它是哪一类垃圾呢？'), 'levels': levels})


# 14. shadow-match -------------------------------------------------------------
def gen_shadow():
    P = Prompts('shadow-match')
    levels = []
    for group in (['dog', 'apple', 'car'], ['cat', 'banana', 'bus', 'elephant'],
                  ['rabbit', 'turtle', 'plane', 'grape', 'star'], ['dog', 'cat', 'bear', 'rabbit', 'panda']):
        levels.append({
            'prompt': P('帮它们找到自己的影子吧'),
            'shuffleTargets': True,
            'targets': [{'id': k, 'art': {'emoji': EMO[k], 'silhouette': True}} for k in group],
            'items': [{'id': k, 'match': k, 'art': {'emoji': EMO[k]}, 'speech': S[k]} for k in group],
        })
    write('shadow-match', {'title': '影子配对', 'rule': 'pair',
                           'wrongHint': hint('shadow-match', '再看看影子的样子哦'), 'levels': levels})


# 15. puzzle -------------------------------------------------------------------
def gen_puzzle():
    P = Prompts('puzzle')
    levels = [
        {'prompt': P('来拼一拼小狗豆豆吧'), 'puzzle': {'pic': 'dog', 'cols': 2, 'rows': 2, 'speech': S['dog']}},
        {'prompt': P('来拼一座小房子吧'), 'puzzle': {'pic': 'house', 'cols': 3, 'rows': 2, 'speech': S['house']}},
        {'prompt': P('来拼一个大火箭吧'), 'puzzle': {'pic': 'rocket', 'cols': 3, 'rows': 3, 'speech': S['rocket']}},
    ]
    write('puzzle', {'title': '拖拽拼图', 'rule': 'pair', 'layout': 'puzzle', 'pad': 24,
                     'wrongHint': hint('puzzle', '再看看图上的样子哦'), 'levels': levels})


# 16. pinyin-match --------------------------------------------------------------
def gen_pinyin():
    P = Prompts('pinyin-match')
    words = {  # char: (pinyin with tone mark, key syllable+tone, emoji, english)
        '猫': ('māo', 'mao1', '🐱', 'cat'), '狗': ('gǒu', 'gou3', '🐶', 'dog'), '鱼': ('yú', 'yu2', '🐟', 'fish'),
        '牛': ('niú', 'niu2', '🐮', 'cow'), '羊': ('yáng', 'yang2', '🐑', 'sheep'), '马': ('mǎ', 'ma3', '🐴', 'horse'),
        '鸡': ('jī', 'ji1', '🐔', 'chicken'),
        '花': ('huā', 'hua1', '🌸', 'flower'), '草': ('cǎo', 'cao3', '🌿', 'grass'), '树': ('shù', 'shu4', '🌳', 'tree'),
        '山': ('shān', 'shan1', '⛰️', 'mountain'), '水': ('shuǐ', 'shui3', '💧', 'water'),
        '月': ('yuè', 'yue4', '🌙', 'moon'), '星': ('xīng', 'xing1', '⭐', 'star'), '云': ('yún', 'yun2', '☁️', 'cloud'),
        '雨': ('yǔ', 'yu3', '🌧️', 'rain'), '火': ('huǒ', 'huo3', '🔥', 'fire'),
        '书': ('shū', 'shu1', '📖', 'book'), '车': ('chē', 'che1', '🚗', 'car'), '船': ('chuán', 'chuan2', '⛵', 'boat'),
        '伞': ('sǎn', 'san3', '☂️', 'umbrella'), '门': ('mén', 'men2', '🚪', 'door'),
    }
    levels = []
    for group in ('猫狗鱼', '牛羊马鸡', '花草树山水', '月星云雨火', '书车船伞门'):
        levels.append({
            'prompt': P('读一读拼音，把它送到对应的图片下面'),
            'shuffleTargets': True,
            'targets': [{'id': c, 'frame': 'card', 'place': 'stack', 'art': {'emoji': words[c][2], 'char': c, 'row': True}} for c in group],
            'items': [{'id': 'py_' + words[c][1], 'match': c, 'art': {'text': words[c][0], 'font': 'latin', 'small': True},
                       'speech': sp('pinyin_' + words[c][1], c, words[c][3])} for c in group],
        })
    write('pinyin-match', {'title': '拼音配对', 'rule': 'pair',
                           'wrongHint': hint('pinyin-match', '再读一读拼音，听听像哪个字？'), 'levels': levels})


# 17. word-spell -----------------------------------------------------------------
def gen_words():
    P = Prompts('word-spell')
    p = P('看看图片，把字母排成单词吧')
    def rnd(word, k, extra=''):
        return {
            'show': {'emoji': EMO[k]},
            'intro': S[k],
            'complete': S[k],
            'targets': [{'id': 's%d' % i, 'key': ch} for i, ch in enumerate(word)],
            'items': [{'id': 'l%d' % i, 'match': ch, 'art': {'text': ch, 'font': 'latin', 'color': DIGIT_COLORS[1 + i % 10]},
                       'speech': letter(ch)} for i, ch in enumerate(word)]
                     + [{'id': 'x%d' % i, 'match': None, 'art': {'text': ch, 'font': 'latin', 'color': DIGIT_COLORS[6 + i % 4]},
                         'speech': letter(ch)} for i, ch in enumerate(extra)],
        }
    levels = [{'prompt': p, 'shuffle': True, 'rounds': [rnd(*r) for r in rs]} for rs in (
        [('cat', 'cat'), ('dog', 'dog'), ('sun', 'sun')],
        [('pig', 'pig'), ('bus', 'bus'), ('egg', 'egg')],
        [('fish', 'fish'), ('bird', 'bird'), ('cake', 'cake')],
        [('book', 'book'), ('milk', 'milk'), ('star', 'star')],
        [('frog', 'frog', 'e'), ('duck', 'duck', 'a'), ('ship', 'ship', 'o')],
    )]
    write('word-spell', {'title': '英语单词拼写', 'rule': 'sort', 'layout': 'seq',
                         'wrongHint': hint('word-spell', '再听一听，这个位置是哪个字母呢？'), 'levels': levels})


def gen_meta():
    games = [
        ('train', '小火车数字', '把数字送到对应的车厢', 3, 6, '#FF9F43', 'train'),
        ('count-match', '数量配对', '数一数，把数字放到盘子下面', 3, 6, '#3FBF84', 'count'),
        ('feed-animals', '喂小动物', '把好吃的喂给小动物', 2, 4, '#F2678A', 'animal'),
        ('basket', '放进篮子', '把东西放进篮子里', 2, 3, '#FFB020', 'box'),
        ('shape-box', '形状盒', '把形状放进一样的洞洞', 2, 4, '#4AA3EE', 'shape'),
        ('animal-home', '送动物回家', '小动物住在哪里呢', 3, 5, '#7CC47F', 'path'),
        ('dress-bear', '给小熊穿衣服', '帮小熊穿好帽子和鞋子', 2, 4, '#C98A5B', 'star'),
        ('color-sort', '颜色分类', '按颜色放进篮子', 3, 6, '#A27FE6', 'palette'),
        ('size-order', '大小排序', '从小到大排排队', 3, 6, '#FF8A65', 'stack'),
        ('pattern', '找规律', '找找规律，下一个是谁', 4, 6, '#26A69A', 'grid'),
        ('add-basket', '加减启蒙', '放苹果，数一数一共几个', 4, 6, '#FF7043', 'calc'),
        ('letter-match', '大小写字母', '大写字母找小写朋友', 5, 7, '#5C6BC0', 'letter'),
        ('garbage-sort', '垃圾分类', '把垃圾放进对的垃圾桶', 5, 8, '#43A047', 'leaf'),
        ('shadow-match', '影子配对', '帮它们找到影子', 3, 5, '#78909C', 'cards'),
        ('puzzle', '拖拽拼图', '把拼图块拼成一幅画', 3, 6, '#EC407A', 'puzzle'),
        ('pinyin-match', '拼音配对', '读拼音，找图片', 6, 8, '#FFA726', 'quiz'),
        ('word-spell', '英语单词拼写', '把字母排成英语单词', 6, 9, '#29B6F6', 'keyboard'),
    ]
    data = {'games': [{'id': 'drag-' + g[0], 'title': g[1], 'desc': g[2], 'ageMin': g[3], 'ageMax': g[4],
                       'input': ['touch'], 'entry': 'index.html?set=' + g[0], 'color': g[5], 'icon': g[6]} for g in games]}
    with open(os.path.join(ROOT, 'meta.json'), 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
        f.write('\n')


for fn in (gen_train, gen_count, gen_feed, gen_basket, gen_shape, gen_home, gen_bear, gen_color, gen_size,
           gen_pattern, gen_add, gen_letters, gen_garbage, gen_shadow, gen_puzzle, gen_pinyin, gen_words, gen_meta):
    fn()
print('ok')
