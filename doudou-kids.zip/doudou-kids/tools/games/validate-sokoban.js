#!/usr/bin/env node
/*
 * 推箱子关卡校验：node tools/games/validate-sokoban.js [--write]
 * 读取 app/src/main/assets/games/sokoban/levels.json，检查格式（XSB），
 * 用 BFS 求每关的最少步数（移动步数），确认可解。--write 时把最少步数写回 par 字段。
 */
'use strict';
var fs = require('fs');
var path = require('path');
var FILE = path.join(__dirname, '../../app/src/main/assets/games/sokoban/levels.json');
var MAX_STATES = 3000000;

function parse(map) {
  var h = map.length, w = 0, i;
  for (i = 0; i < h; i++) w = Math.max(w, map[i].length);
  var wall = [], goal = [], boxes = [], player = -1, errors = [];
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      var ch = map[y][x] || ' ', k = y * w + x;
      wall[k] = ch === '#';
      goal[k] = ch === '.' || ch === '*' || ch === '+';
      if (ch === '$' || ch === '*') boxes.push(k);
      if (ch === '@' || ch === '+') { if (player >= 0) errors.push('多个玩家'); player = k; }
      if ('# .$*@+-_'.indexOf(ch) < 0) errors.push('非法字符 ' + JSON.stringify(ch));
    }
  }
  var goals = goal.filter(Boolean).length;
  if (player < 0) errors.push('没有玩家');
  if (boxes.length !== goals) errors.push('箱子数 ' + boxes.length + ' ≠ 目标数 ' + goals);
  if (!boxes.length) errors.push('没有箱子');
  // 封闭检查：从玩家出发走不到地图边缘
  if (player >= 0) {
    var seen = {}, q = [player];
    seen[player] = 1;
    while (q.length) {
      var p = q.pop(), px = p % w, py = Math.floor(p / w);
      if (px === 0 || py === 0 || px === w - 1 || py === h - 1) { errors.push('地图没有封闭'); break; }
      [-1, 1, -w, w].forEach(function (d) {
        var np = p + d;
        if (!wall[np] && !seen[np]) { seen[np] = 1; q.push(np); }
      });
    }
    boxes.forEach(function (b) { if (!seen[b]) errors.push('有箱子在玩家走不到的地方'); });
  }
  return { w: w, h: h, wall: wall, goal: goal, boxes: boxes, player: player, errors: errors };
}

/* 死格：非目标的角落（两个相邻方向都是墙），箱子推进去就再也推不出来 */
function deadCells(L) {
  var dead = [], w = L.w;
  for (var k = 0; k < L.w * L.h; k++) {
    if (L.wall[k] || L.goal[k]) { dead[k] = false; continue; }
    var u = L.wall[k - w], d = L.wall[k + w], l = L.wall[k - 1], r = L.wall[k + 1];
    dead[k] = (u && l) || (u && r) || (d && l) || (d && r);
  }
  return dead;
}

function solve(L) {
  var w = L.w, dirs = [-w, w, -1, 1], dead = deadCells(L);
  function key(p, bs) { return p + ':' + bs.join(','); }
  var start = L.boxes.slice().sort(function (a, b) { return a - b; });
  var seen = new Set([key(L.player, start)]);
  var frontier = [[L.player, start]], depth = 0;
  while (frontier.length) {
    var next = [];
    for (var i = 0; i < frontier.length; i++) {
      var p = frontier[i][0], bs = frontier[i][1];
      if (bs.every(function (b) { return L.goal[b]; })) return { moves: depth, states: seen.size };
      for (var di = 0; di < 4; di++) {
        var d = dirs[di], np = p + d;
        if (L.wall[np]) continue;
        var bi = bs.indexOf(np), nbs = bs;
        if (bi >= 0) {
          var nb = np + d;
          if (L.wall[nb] || bs.indexOf(nb) >= 0 || dead[nb]) continue;
          nbs = bs.slice();
          nbs[bi] = nb;
          nbs.sort(function (a, b) { return a - b; });
        }
        var k = key(np, nbs);
        if (seen.has(k)) continue;
        seen.add(k);
        next.push([np, nbs]);
      }
    }
    if (seen.size > MAX_STATES) return { moves: -1, states: seen.size, tooBig: true };
    frontier = next;
    depth++;
  }
  return { moves: -1, states: seen.size };
}

var write = process.argv.indexOf('--write') >= 0;
var data = JSON.parse(fs.readFileSync(FILE, 'utf8'));
var bad = 0;
data.levels.forEach(function (lv, idx) {
  var L = parse(lv.map);
  var tag = '#' + (idx + 1) + ' ' + (lv.name || '');
  if (L.errors.length) { bad++; console.log('✗', tag, L.errors.join('；')); return; }
  var t0 = Date.now(), r = solve(L);
  if (r.moves < 0) { bad++; console.log('✗', tag, r.tooBig ? '状态太多，未能求解' : '无解', r.states + ' 状态'); return; }
  console.log('✓', tag, L.boxes.length + ' 箱', '最少 ' + r.moves + ' 步', r.states + ' 状态', (Date.now() - t0) + 'ms');
  if (write) lv.par = r.moves;
});
console.log(data.levels.length + ' 关，' + (bad ? bad + ' 关有问题' : '全部可解'));
if (write && !bad) {
  var out = '{\n  "levels": [\n' + data.levels.map(function (lv) {
    return '    {"name": ' + JSON.stringify(lv.name) + ', "par": ' + lv.par + ', "map": [\n' +
      lv.map.map(function (row) { return '      ' + JSON.stringify(row); }).join(',\n') + '\n    ]}';
  }).join(',\n') + '\n  ]\n}\n';
  fs.writeFileSync(FILE, out);
  console.log('已写回 par');
}
process.exit(bad ? 1 : 0);
