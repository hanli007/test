#!/usr/bin/env node
/*
 * 编程闯关关卡校验：node tools/games/validate-code-maze.js [levels.json]
 * 对每关的两种模式（方向模式 ↑↓←→ / 转向模式 前进·左转·右转）：
 *   1. BFS 求不用循环的最短程序；
 *   2. 若该关有“重复”积木，对所有最短路径做循环压缩 DP，得到可用的短程序；
 *   3. 用和游戏一致的解释器执行这个程序，确认能走到骨头；
 *   4. 检查 maxBlocks 足够。
 * 有任何问题时退出码为 1。
 */
'use strict';
var fs = require('fs');
var path = require('path');

var file = process.argv[2] || path.join(__dirname, '../../app/src/main/assets/games/code-maze/levels.json');
var data = JSON.parse(fs.readFileSync(file, 'utf8'));

var DIRS = { N: [-1, 0], E: [0, 1], S: [1, 0], W: [0, -1] };
var ORDER = ['N', 'E', 'S', 'W'];
var ABS = { U: 'N', D: 'S', L: 'W', R: 'E' };
var LOOP_MIN = 2, LOOP_MAX = 9;

function findCell(grid, ch) {
  for (var r = 0; r < grid.length; r++) { var c = grid[r].indexOf(ch); if (c >= 0) return [r, c]; }
  return null;
}
function isWall(grid, r, c) { return r < 0 || r >= grid.length || c < 0 || c >= grid[r].length || grid[r][c] === '#'; }

/* 与游戏 code-maze.js 中一致：把积木列表展开成命令序列 */
function flatten(prog) {
  var out = [];
  function run(i, end) {
    while (i < end) {
      var b = prog[i];
      if (b.t === 'loop') {
        var depth = 1, j = i + 1;
        while (j < end && depth) { if (prog[j].t === 'loop') depth++; else if (prog[j].t === 'end') depth--; if (depth) j++; }
        for (var k = 0; k < b.n && out.length < 400; k++) run(i + 1, j);
        i = j + 1;
      } else {
        if (b.t !== 'end') out.push(b.t);
        i++;
      }
    }
  }
  run(0, prog.length);
  return out;
}
function simulate(grid, face, cmds) {
  var p = findCell(grid, 'S'), r = p[0], c = p[1], f = face;
  for (var i = 0; i < cmds.length; i++) {
    var cmd = cmds[i];
    if (cmd === 'TL') { f = ORDER[(ORDER.indexOf(f) + 3) % 4]; continue; }
    if (cmd === 'TR') { f = ORDER[(ORDER.indexOf(f) + 1) % 4]; continue; }
    var d = DIRS[cmd === 'F' ? f : ABS[cmd]];
    var nr = r + d[0], nc = c + d[1];
    if (isWall(grid, nr, nc)) return 'crash@' + i;
    r = nr; c = nc;
    if (grid[r][c] === 'B') return 'win';
  }
  return 'stop';
}

/* BFS，返回所有最短命令序列（最多 limit 条） */
function shortestSeqs(grid, mode, face, limit) {
  var s = findCell(grid, 'S');
  var cmds = mode === 'abs' ? ['U', 'D', 'L', 'R'] : ['F', 'TL', 'TR'];
  function key(st) { return st[0] + ',' + st[1] + ',' + st[2]; }
  function step(st, cmd) {
    var f = st[2];
    if (cmd === 'TL') return [st[0], st[1], ORDER[(ORDER.indexOf(f) + 3) % 4]];
    if (cmd === 'TR') return [st[0], st[1], ORDER[(ORDER.indexOf(f) + 1) % 4]];
    var d = DIRS[cmd === 'F' ? f : ABS[cmd]];
    var nr = st[0] + d[0], nc = st[1] + d[1];
    if (isWall(grid, nr, nc)) return null;
    return [nr, nc, mode === 'abs' ? 'E' : f];
  }
  var start = [s[0], s[1], mode === 'abs' ? 'E' : face];
  var dist = {}; dist[key(start)] = 0;
  var preds = {}; preds[key(start)] = [];
  var q = [start], goalKeys = [], goalDist = Infinity;
  while (q.length) {
    var st = q.shift(), k = key(st), d0 = dist[k];
    if (d0 >= goalDist) continue;
    if (grid[st[0]][st[1]] === 'B') continue;
    cmds.forEach(function (cmd) {
      var ns = step(st, cmd); if (!ns) return;
      var nk = key(ns);
      if (dist[nk] === undefined) {
        dist[nk] = d0 + 1; preds[nk] = []; q.push(ns);
        if (grid[ns[0]][ns[1]] === 'B') { if (d0 + 1 < goalDist) { goalDist = d0 + 1; goalKeys = []; } goalKeys.push(nk); }
      }
      if (dist[nk] === d0 + 1) preds[nk].push([k, cmd]);
    });
  }
  if (!goalKeys.length) return [];
  var out = [];
  function back(k, suffix) {
    if (out.length >= limit) return;
    if (dist[k] === 0) { out.push(suffix.slice()); return; }
    preds[k].forEach(function (pr) { suffix.unshift(pr[1]); back(pr[0], suffix); suffix.shift(); });
  }
  goalKeys.forEach(function (gk) { back(gk, []); });
  return out;
}

/* 循环压缩：DP 求覆盖命令序列的最少积木数，末尾允许多余命令（走到骨头即通关） */
function compress(seq) {
  var n = seq.length, memo = {};
  function same(a, b, len) { for (var i = 0; i < len; i++) if (seq[a + i] !== seq[b + i]) return false; return true; }
  function best(i, j) { // 精确覆盖 seq[i..j)
    var k0 = i + ',' + j; if (memo[k0]) return memo[k0];
    var res;
    if (j - i === 1) res = { cost: 1, prog: [{ t: seq[i] }] };
    else {
      res = null;
      for (var m = i + 1; m < j; m++) {
        var a = best(i, m), b = best(m, j);
        if (!res || a.cost + b.cost < res.cost) res = { cost: a.cost + b.cost, prog: a.prog.concat(b.prog) };
      }
      var L = j - i;
      for (var p = 1; p <= L / 2; p++) {
        if (L % p) continue;
        var reps = L / p; if (reps < LOOP_MIN || reps > LOOP_MAX) continue;
        var ok = true;
        for (var r = 1; r < reps && ok; r++) ok = same(i, i + r * p, p);
        if (!ok) continue;
        var body = best(i, i + p);
        if (body.cost + 2 < res.cost) res = { cost: body.cost + 2, prog: [{ t: 'loop', n: reps }].concat(body.prog, [{ t: 'end' }]) };
      }
    }
    memo[k0] = res; return res;
  }
  // 末段允许超出：seq[i..n) 是 body^reps 的前缀
  var tail = [];
  for (var i = 0; i <= n; i++) {
    var t = i === n ? { cost: 0, prog: [] } : best(i, n);
    for (var p = 1; i < n && p < n - i; p++) {
      var reps = Math.ceil((n - i) / p);
      if (reps < LOOP_MIN || reps > LOOP_MAX) continue;
      var ok = true;
      for (var x = i + p; x < n && ok; x++) ok = seq[x] === seq[i + ((x - i) % p)];
      if (!ok) continue;
      var body = best(i, i + p);
      if (body.cost + 2 < t.cost) t = { cost: body.cost + 2, prog: [{ t: 'loop', n: reps }].concat(body.prog, [{ t: 'end' }]) };
    }
    tail[i] = t;
  }
  var bestAll = tail[0];
  for (var s = 1; s < n; s++) {
    var head = best(0, s);
    if (head.cost + tail[s].cost < bestAll.cost) bestAll = { cost: head.cost + tail[s].cost, prog: head.prog.concat(tail[s].prog) };
  }
  return bestAll;
}

function show(prog) {
  return prog.map(function (b) { return b.t === 'loop' ? '重复' + b.n + '[' : b.t === 'end' ? ']' : b.t; }).join(' ');
}

var failed = false;
var ids = {};
data.levels.forEach(function (lv, idx) {
  var g = lv.grid, errs = [];
  if (ids[lv.id]) errs.push('重复的 id'); ids[lv.id] = 1;
  if (!g.every(function (row) { return row.length === g[0].length; })) errs.push('行长度不一致');
  var cnt = g.join('').split('');
  if (cnt.filter(function (c) { return c === 'S'; }).length !== 1) errs.push('起点 S 必须恰好一个');
  if (cnt.filter(function (c) { return c === 'B'; }).length !== 1) errs.push('骨头 B 必须恰好一个');
  if (cnt.some(function (c) { return '#.SB'.indexOf(c) < 0; })) errs.push('含未知字符');
  if (!DIRS[lv.face || 'E']) errs.push('face 不合法');
  if (errs.length) { console.log('第 ' + lv.id + ' 关 ✗ ' + errs.join('；')); failed = true; return; }

  var line = '第 ' + lv.id + ' 关「' + lv.name + '」 maxBlocks=' + lv.maxBlocks;
  var need = 0;
  ['abs', 'rel'].forEach(function (mode) {
    var seqs = shortestSeqs(g, mode, lv.face || 'E', 20000);
    if (!seqs.length) { line += '\n   ' + mode + ' ✗ 无解'; failed = true; return; }
    var plain = seqs[0].length, best = { cost: plain, prog: seqs[0].map(function (c) { return { t: c }; }) };
    if (lv.loop) seqs.forEach(function (sq) { var c = compress(sq); if (c.cost < best.cost) best = c; });
    var res = simulate(g, lv.face || 'E', flatten(best.prog));
    if (res !== 'win') { line += '\n   ' + mode + ' ✗ 程序没走到骨头：' + res; failed = true; }
    need = Math.max(need, best.cost);
    line += '\n   ' + mode + ' 不用循环 ' + plain + ' 块' + (lv.loop ? '，用循环 ' + best.cost + ' 块' : '') + '  例：' + show(best.prog);
  });
  if (need > lv.maxBlocks) { line += '\n   ✗ maxBlocks 太小，至少需要 ' + need; failed = true; }
  console.log(line);
  if (idx > 0 && data.levels[idx - 1].id >= lv.id) { console.log('   ✗ id 未递增'); failed = true; }
});
console.log(failed ? '\n有问题，请修正。' : '\n全部 ' + data.levels.length + ' 关可解。');
process.exit(failed ? 1 : 0);
