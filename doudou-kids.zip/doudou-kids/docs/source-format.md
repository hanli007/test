# 视频源格式

豆豆乐园支持两种源格式（解析代码见 `app/src/main/java/com/doudou/kids/core/SourceParser.kt`）。
只添加合法来源；豆豆乐园不提供、不内置影视资源站或 TVBox 接口。

## 1. 豆豆乐园 JSON

```json
{
  "name": "示例源",
  "version": 1,
  "categories": [
    { "id": "science", "name": "科普", "ageMin": 6, "ageMax": 15 }
  ],
  "items": [
    {
      "id": "v001",
      "title": "太阳系的八大行星",
      "cover": "https://example.com/cover.jpg",
      "type": "video",
      "url": "https://example.com/video.mp4",
      "categoryId": "science",
      "ageMin": 6,
      "ageMax": 12,
      "tags": ["天文"],
      "duration": 360
    }
  ]
}
```

| 字段 | 说明 |
|---|---|
| `items[].id` | 条目唯一标识；缺省时用 `url`。刷新源时按它保留审核状态 |
| `items[].type` | `video`：原生播放器播放（mp4、m3u8）；`webpage`：在受限网页里打开，只放行该网址所在的域名 |
| `items[].categoryId` | 对应 `categories[].id`；没有时可以直接写 `category`（分类名） |
| `ageMin` / `ageMax` | 条目没写时继承分类的；都没写表示不限年龄 |
| `duration` | 秒，可选 |

## 2. M3U 播放列表

```
#EXTM3U
#EXTINF:-1 tvg-logo="https://example.com/logo.png" group-title="儿歌",小星星
https://example.com/twinkle.m3u8
```

`group-title` 作为分类名，没有时归入「未分类」。

## 过滤

添加源后，家长在「家长设置 → 视频源」里确认保留哪些分类（名字带「教育、科普、儿歌……」等词的默认勾选），
再经过关键词黑名单、年龄、审核模式、单条屏蔽共五层过滤（方案 3.4.3）。过滤只看标题和分类，识别不了画面内容。
