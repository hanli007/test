# 豆豆乐园

给 0–15 岁孩子用的学习内容 app（Kotlin + Jetpack Compose），一个 apk 同时支持手机/平板和 Android TV。
视频、互动小游戏、StoryWeaver 绘本、PhET 实验，按年龄分三档界面（启蒙版 0–5、童趣版 6–11、少年版 12–15），
自带计时、休息提醒、护眼滤镜和距离提醒。家长锁定后，设备固定在豆豆乐园里，孩子只能用其中的内容和家长允许的 app。

设计细节见方案文档 `kids-app-plan.md`（v2.1）。

## 构建

需要 JDK 17、Android SDK 35。

```bash
# 激活码密钥（不提交到仓库），正式包必须设置；调试包跳过激活
echo "doudou.licenseSecret=换成一串足够长的随机字符" >> local.properties

./gradlew testStandardDebugUnitTest     # 单元测试（core 纯逻辑 + 游戏 meta.json 检查）
./gradlew assembleStandardDebug         # 调试包
./gradlew assembleStandardRelease assembleGuardRelease
```

### 两个构建变体

| 变体 | 区别 | 什么时候用 |
|---|---|---|
| `standard` | 声明桌面（HOME）入口，可设为默认桌面 | 先装这个 |
| `guard` | 不声明 HOME 入口，靠无障碍服务把厂商桌面挡回去 | 安装报 `INSTALL_FAILED_USER_RESTRICTED`、`INSTALL_FAILED_VERIFICATION_FAILURE` 或 "install apk has be disabled from pm"（部分 TCL、海信）时改装这个 |

两个变体包名相同，不能同时安装。guard 版按 Home 键时可能先闪一下电视自带的桌面。

## 安装与授权

1. 安装 apk，打开后按向导：激活 → 家长密码 + 密保 → 创建孩子档案。
2. 「家长设置 → 权限与锁定」里逐项开启：默认桌面（standard）、悬浮窗、防卸载、电池优化白名单。
3. 「家长设置 → 白名单 app」勾选孩子可以打开的 app。
4. 点「锁定并进入孩子模式」，按提示开启「豆豆乐园 · 儿童锁定」无障碍服务，开启后自动锁定。

**电视建议用电脑 adb 授权**（权限页上也会列出这些命令）：

```bash
PKG=com.doudou.kids
adb shell pm grant $PKG android.permission.WRITE_SECURE_SETTINGS   # 锁定、解锁、被杀后恢复都自动完成
adb shell appops set $PKG SYSTEM_ALERT_WINDOW allow                 # 电视上常没有悬浮窗设置页
adb shell appops set $PKG ACCESS_RESTRICTED_SETTINGS allow          # Android 13+ 侧载 apk 开无障碍
adb shell cmd notification allow_listener $PKG/com.doudou.kids.lock.RevivalListener   # 守护恢复
adb shell cmd package set-home-activity $PKG/.lock.HomeActivity      # 电视设置里不能换桌面时（standard）
```

验证守护服务真的在运行（不只是「已开启」）：`adb shell dumpsys accessibility | grep -i doudou`

解锁：手机长按右上角 3 秒，电视长按遥控器确认键 5 秒，输入家长密码。

## 激活码

```bash
python3 tools/license/gen_code.py ABCDE-12345            # 密钥从 local.properties 读取
python3 tools/license/gen_code.py --verify ABCDE-12345 XXXX-XXXX-XXXX-XXXX
```

算法与 `core/LicenseCodec.kt` 一致，`CoreTest.kt` 里有两边对拍的测试样例。

## 代码结构

```
app/src/main/java/com/doudou/kids/
├── core/      纯逻辑（JVM 单元测试覆盖）：档位、时间规则、过滤、源解析、激活码、密码、锁定放行规则、
│              按键过滤规则、计时累加、护眼、游戏目录、域名放行
├── data/      Prefs 设置项、Room 数据库
├── lock/      锁定：Home 入口、无障碍守护服务、无障碍浮层（滤镜/提示条）、守护恢复、开机、防卸载
├── timer/     计时（含白名单 app 时间）
├── eyecare/   距离提醒（CameraX + ML Kit 离线人脸检测）
├── media/     语音 TTS
├── games/     游戏目录、KidsBridge
├── web/       WebView 配置（本地资源 / 受限域名）、电视虚拟光标
├── content/   视频源仓库、内置内容清单
├── parent/    家长密码与密保、激活
└── ui/        孩子端（三档 × 手机/电视）、家长端、通用组件
```

H5 游戏在 `app/src/main/assets/games/`，原生桥接口见 `_shared/kids-game.js` 文件开头。
视频源格式见 `docs/source-format.md`。

## 致谢

电视锁定部分的若干做法（guard 变体、Home 键处理、按键过滤的开关时机、手柄识别、被杀后的恢复）参考了
[PlanYourTV](https://github.com/heimi51168/planyourtv) 与其上游 [Aerial](https://github.com/pengchujin/aerial-tv)
（MIT 协议，© pengchujin 与 PlanYourTV contributors）。代码为重新编写，对应位置的注释里有说明。
